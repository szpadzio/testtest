const path = require('path');
const dir = './client_packages/LSOnline/browser';

module.exports = {
  chainWebpack: config => {
    config.resolve
      .alias
      .set('@@', path.resolve(path.join(dir, 'src/assets')));
    config.resolve
      .alias
      .set('@', path.resolve(path.join(dir, 'src')));
  },
  publicPath: './',
  outputDir: path.join(dir, 'dist'),
  pages: {
    index: {
      title: 'gtav-roleplay-clientside',
      entry: path.join(dir, 'src/main.js')
    }
  }
};
