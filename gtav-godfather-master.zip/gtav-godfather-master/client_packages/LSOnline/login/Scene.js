const scenes = require('./LSOnline/login/scenes');
const misc = require('./LSOnline/util/misc');

class Scene {
  constructor (id = null) {
    id ? this.getScene(id) : this.pickRandomScene();
    mp.events.add('destroyScene', () => this.destroy());
  }

  pickRandomScene () {
    const id = Math.floor(Math.random() * Object.keys(scenes).length);
    this.getScene(id);
  }

  getScene (id) {
    this.scene = scenes[Object.keys(scenes)[id]];
    this.startPosition = new mp.Vector3(...this.scene.startCamera);
    if (this.scene.endCamera) this.endPosition = new mp.Vector3(...this.scene.endCamera);
    this.peds = this.scene.peds;
    this.fov = this.scene.fov;
    this.direction = this.scene.direction;
    this.transitionTime = this.scene.transitionTime;
    this.selectionPosition = this.scene.selectionPosition;
  }

  setupScene () {
    mp.game.graphics.transitionToBlurred(1);
    mp.players.local.setAlpha(0);
    mp.players.local.position = this.startPosition;
    mp.events.call('toggleFreeze', true);
    this.cameras = {
      start: mp.cameras.new('default', this.startPosition, new mp.Vector3(0, 0, this.direction[0]), this.fov),
      end: this.endPosition ? mp.cameras.new('default', this.endPosition, new mp.Vector3(0, 0, this.direction[1]), this.fov) : null,
      selection: mp.cameras.new('default', new mp.Vector3(this.selectionPosition[0] - 3, this.selectionPosition[1] - 0.5, this.selectionPosition[2] + 0.5), new mp.Vector3(0, 15, 0), 60)
    };
    this.cameras.start.setActive(true);
    mp.game.cam.renderScriptCams(true, false, 2000, false, false);
  }

  run () {
    if (this.cameras.end) this.cameras.end.setActiveWithInterp(this.cameras.start.handle, this.transitionTime, 1, 1);

    misc.showPeds();
    this.interval = setInterval(() => {
      if (this.cameras.end) mp.players.local.position = this.cameras.end.getCoord();
    }, 2000);
  }

  destroy () {
    misc.disablePeds();
    mp.game.graphics.transitionFromBlurred(1);
    clearInterval(this.interval);
    const position = mp.players.local.position;
    mp.game.cam.renderScriptCams(false, false, 2000, false, false);

    return position;
  }

  moveToSelection () {
    clearInterval(this.interval);
    mp.game.graphics.transitionFromBlurred(1500);

    if (this.cameras.selection) this.cameras.selection.setActiveWithInterp(this.cameras.start.handle, 3000, 100, 100);
    mp.players.local.position = new mp.Vector3(...this.selectionPosition);
    mp.players.local.setAlpha(255);

    this.cameras.selection.pointAtPedBone(mp.players.local.handle, 10706, 0, 0, 0, true);
    mp.players.local.setHeading(135);
  }
}

exports = Scene;
