'use strict';
const { toggleCursor } = require('./LSOnline/util/cursor');

const Overlay = require('./LSOnline/util/overlay');
const Scene = new (require('./LSOnline/login/Scene'))();
/**
 * Events.
 */
mp.events.add({
  playerReady: () => {
    Scene.setupScene();
    mp.events.call('hideHud', true);
    mp.events.call('chatShow', false);
    mp.events.call('chatActive', false);
  },
  showBrowser: () => {
    Scene.run();
    setTimeout(() => {
      mp.gui.cursor.show(true, true);
      mp.events.call('chatShow', false);
      mp.events.call('chatActive', false);
      Overlay.push('login');
    }, 500);
  },
  moveToSelection: () => {
    Scene.moveToSelection();
  },
  destroyLogin: () => {
    Scene.destroy();
  },
  characterSelected: characterId => {
    mp.players.local.position = Scene.destroy();
    mp.game.invoke(rp.natives.SWITCH_OUT_PLAYER, mp.players.local.handle, 0, 1);

    Overlay.push('overlay');
    setTimeout(() => {
      mp.events.callRemote('loginPlayer', characterId);

      setTimeout(() => {
        mp.game.invoke(rp.natives.SWITCH_IN_PLAYER, mp.players.local.handle);
        const interval = setInterval(() => {
          const state = mp.game.invoke(rp.natives.IS_PLAYER_SWITCH_IN_PROGRESS);
          if (!state) {
            mp.events.callRemote('proceedToGame');
            toggleCursor(false);
            clearInterval(interval);
            mp.game.ui.displayRadar(true);
            mp.players.local.transitionFinished = true;
          }
        }, 500);
      }, 1500);
    }, 2000);
  }
});
