const DrawText = require('/LSOnline/util/drawText');
const globals = require('/LSOnline/util/globals');

mp.events.add({
  playerEnterColshape: colshape => {
    const name = colshape.getVariable('name');

    if (name) {
      globals.door = colshape;
      const price = colshape.getVariable('price');
      const locked = colshape.getVariable('locked');

      DrawText.drawText(
        'doorLabel',
        name + `${price ? ' ($' + price + ')' : ''}`,
        [0.5, 0.81],
        {
          font: 4,
          scale: [0.7, 0.7],
          outline: true,
          color: [255, 255, 255, 250]
        }
      );
      DrawText.drawText(
        'doorLabelState',
        locked ? 'Zamknięte' : 'Otwarte',
        [0.5, 0.85],
        {
          font: 4,
          scale: [0.7, 0.7],
          outline: true,
          color: locked ? [255, 0, 0, 200] : [0, 255, 0, 200]
        }
      );
    }
  },
  playerExitColshape: colshape => {
    globals.door = null;
    DrawText.destroyText('doorLabel');
    DrawText.destroyText('doorLabelState');
  },
  destroyDoorLabel: () => {
    globals.door = null;
    DrawText.destroyText('doorLabel');
    DrawText.destroyText('doorLabelState');
  },
  propertyBought: () => {
    mp.events.call('playAudio', 'PROPERTY_PURCHASE', 'HUD_AWARDS');
    mp.game.ui.messages.showShard('ZAKUPIŁEŚ NIERUCHOMOŚĆ', '', 20, 2, 3000);
  }
});
