const DrawText = require('/LSOnline/util/drawText');
const globals = require('/LSOnline/util/globals');

mp.events.addDataHandler({
  locked: (entity, value) => {
    if (entity.type == 'colshape' && globals.door && entity.id === globals.door.id) {
      DrawText.destroyText('doorLabelState');
      DrawText.drawText(
        'doorLabelState',
        value ? 'Zamknięte' : 'Otwarte',
        [0.5, 0.85],
        {
          font: 4,
          scale: [0.7, 0.7],
          outline: true,
          color: value ? [255, 0, 0, 200] : [0, 255, 0, 200]
        }
      );
    }
  }
});
