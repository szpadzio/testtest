mp.events.addProc({
  'client:getNearbyPlayers': async () => {
    const players = [];
    mp.players.forEachInStreamRange((player) => {
      // if (player.handle === mp.players.local.handle || player.dimension !== mp.players.local.dimension) { return 0; }
      // if (mp.players.local.distSquared(player) > 3) return 0;
      return players.push({ name: player.name, id: player.remoteId, localId: player.id });
    });

    return JSON.stringify(players);
  }
});

mp.events.add({
  'client:exitGame': () => {
    mp.console.logInfo('xd');
    mp.console.execute('xd');
  }
});
