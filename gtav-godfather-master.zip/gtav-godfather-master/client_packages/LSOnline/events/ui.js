mp.events.add({
  'client:popNotification': (text, time = 5000, beep = false, loop = false) => {
    mp.game.ui.addTextComponentSubstringPlayerName(text); // pastebin.com/nqNYWMSB
    mp.game.ui.displayHelpTextFromStringLabel(0, loop, beep, time); // p0, looop, beep,time
  }
});
