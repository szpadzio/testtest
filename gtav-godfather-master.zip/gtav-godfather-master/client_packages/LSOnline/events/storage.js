mp.events.addProc('client:getStorage', (key) => {
  if (mp.storage.data[key]) {
    return mp.storage.data[key];
  } else {
    return null;
  }
});

mp.events.add('client:setStorage', (key, value) => {
  mp.storage[key] = value;
  mp.storage.flush();

  return 1;
});
