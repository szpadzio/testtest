mp.events.add({
  'client:chatInputEnabled': (status) => {
    mp.gui.chat.typing = status;
  }
});

mp.events.add({
  chatShow: value => toggleChat(value),
  chatActive: value => disableChat(value)
});

const toggleChat = value => {
  // false to hide
  mp.gui.chat.show(value);
  mp.events.call('chat:show', value);
};

exports.toggleChat = toggleChat;

const disableChat = (value = true) => {
  // false to deactive
  mp.gui.chat.activate(value);
  mp.events.call('chat:active', value);
};

exports.disableChat = disableChat;
