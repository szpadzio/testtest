mp.events.addProc({
  'client:getGroundCoords': async (x, y, z) => {
    return mp.game.gameplay.getGroundZFor3dCoord(x, y, z, 0, false);
  }
});
