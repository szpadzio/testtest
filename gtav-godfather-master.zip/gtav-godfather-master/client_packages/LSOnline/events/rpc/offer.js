mp.events.add({
  'server:createOffer:item': (data) => {
    mp.events.callRemote('server:createOffer:item', data);
  }
});
