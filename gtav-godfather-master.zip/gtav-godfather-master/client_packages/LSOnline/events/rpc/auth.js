const Overlay = require('LSOnline/util/overlay');

mp.events.add({
  'server:authorizePlayer': data => {
    mp.events.callRemote('server:authorizePlayer', data);
  },
  'response:server:authorizePlayer': data => {
    Overlay.triggerEvent('response:server:authorizePlayer', data);
  }
});
