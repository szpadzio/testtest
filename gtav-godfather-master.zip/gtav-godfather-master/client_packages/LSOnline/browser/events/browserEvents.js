'use strict';

const Overlay = require('./LSOnline/util/overlay');

mp.events.add({
  browserCreated: browser => {
    console.log(`Browser ${browser} has been created ingame.`);
  },

  browserLoadingFailed: browser => {
    Overlay.notify(
      'Wystąpił błąd',
      `Przeglądarka ${browser} nie załadowała się poprawnie. Spróbuj ponownie.`,
      'info',
      5000
    );
  },
  'client:callServer': (event, ...args) => {
    return mp.events.callRemote(event, ...args);
  }
});

mp.events.addProc({
  'client:callServerRpc': async (procedure, ...args) => {
    const result = await mp.events.callRemoteProc(procedure, ...args);

    return JSON.stringify(result);
  }
});
