<template>
  <div class="master_wrap">
    <div class="master_content">

      <div class="wrap">
        <div class="logo-section">
          <a></a>
        </div>
        <div
          class="error-alert mb-8"
          v-if="error"
        >
          <p>
            {{ $t(`login.error[${error}]`) }}
          </p>
        </div>
        <div class="login">
          <h1 class="text-2xl text-gray-700 font-bold">{{ $t("login.welcome") }}</h1>
          <form
            class="form_wrapper"
            @submit="submitForm($event)"
          >
            <input-text
              id="username"
              :label="$t('login.username')"
              type="text"
              v-model="data.username"
            />
            <input-text
              id="password"
              :label="$t('login.password')"
              type="password"
              v-model="data.password"
            />
            <checkbox
              id="remember"
              :label="$t('login.remember')"
              v-model="data.remember"
            />

            <div class="pt-6 input_container flex justify-between items-center active:border-0 active:outline-none">
              <p class="text-light text-rockstar hover-upper">{{ $t("login.lostpassword") }}</p>
              <button-input
                :disabled="disabled"
                :loading="disabled"
                type="submit"
                class="hover-upper"
              >
                {{ $t('login.signin') }}
              </button-input>
            </div>
          </form>
        </div>
      </div>
      <div class="footer h-full text-xs flex items-center justify-between">
        <p class="text-center font-normal w-1/3">
          MADE BY ARDULA &amp; FRIENDS

        </p>
        <p class="text-center w-1/3 leading-snug">

          <span class="font-normal"> ALL RIGHT BELONGS TO<br> </span>
          ROCKSTAR GAMES<br>
          © <span class="font-normal"> 2020</span>

        </p>
        <p class="text-center font-normal w-1/3">
          MAKE RP GREAT AGAIN
        </p>
      </div>
    </div>
  </div>
</template>

<script>
import { library } from '@fortawesome/fontawesome-svg-core';
import InputText from '@/components/elements/Input';
import Checkbox from '@/components/elements/Checkbox';
import ButtonInput from '@/components/elements/Button';
import store from '../store';

import { faKey, faUser, faSpinner } from '@fortawesome/free-solid-svg-icons';
library.add(faKey, faUser, faSpinner);

export default {
  components: {
    InputText,
    Checkbox,
    ButtonInput
  },
  data () {
    return {
      error: null,
      disabled: false,
      data: {
        username: '',
        password: '',
        remember: false
      }
    };
  },
  async mounted () {
    const result = await mp.events.callProc('client:getStorage', 'login_username');

    this.data.username = result;
    if (result) {
      this.data.remember = true;
    }

    window.rageEvents['response:server:authorizePlayer'] = (data) => {

      if (!data) {
        return window.alert('this should not happen at all');
      }

      if (data.type === 'error') {
        this.error = data.code;
        this.disabled = false;

        switch (data.code) {
          case 1101:
          case 1102:
            this.error = 1101;
            break;
          default:
            this.error = 1000;
            break;
        }
      } else if (data.type === 'characters') {
        if (this.data.remember) {
          mp.events.call('client:setStorage', 'login_username', this.data.username);
        } else {
          mp.events.call('client:setStorage', 'login_username', null);
        }

        store.commit('player/setData', { key: 'characters', data: data.characters }, { root: true });
        mp.trigger('moveToSelection');
        this.$router.push('characters');
      }
    };
  },
  methods: {
    async submitForm (ev) {
      ev.preventDefault();
      if (this.disabled) {
        return 1;
      }

      this.error = null;
      this.disabled = true;
      mp.trigger('server:authorizePlayer', JSON.stringify(this.data));
    }
  }
};
</script>

<style lang="scss">
.footer {
  @apply w-full text-white font-semibold text-center;
  background: url("https://signin-s.rsg.sc/images/bg-repeat.png") repeat;
}
</style>
