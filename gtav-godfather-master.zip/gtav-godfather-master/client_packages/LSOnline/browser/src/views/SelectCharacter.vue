<template>
  <div class="text-white mx-auto flex flex-col flex-nowrap items-end font-sans pt-16 pr-16">
    <div class="rounded-sm text-black bg-white min-w-1/3 lg:min-w-1/5">
      <div class="p-4 flex flex-wrap justify-between">
        <h1 class="font-semibold w-full text-center  xl:w-auto">
          {{ $t("login.selector.chooseCharacter") }}
        </h1>
        <a
          class="font-semibold text-rockstar text-center cursor-pointer w-full xl:w-auto"
          @click="goCreator"
        >
          {{ $t("login.selector.createCharacter") }}
        </a>

      </div>
      <div
        class="overflow-y-auto"
        style="max-height: 50vh"
      >
        <div
          v-for="(character, index) in characters"
          class="p-4 hover:bg-gray-200 flex cursor-pointer border-solid border border-gray-200"
          :key="index"
          :class="[ selected == index ? 'bg-gray-200' : '']"
          @click="selectCharacter(index)"
        >
          <div class="w-full font-medium">
            <h1 class="font-semibold">{{ character.name }}</h1>
            <div class="leading-snug flex font-normal justify-between w-full">
              <p class="text-sm">ID: {{ character.id }}</p>
              <p class="text-sm text-green-700">${{ character.bank + character.money }}</p>
            </div>
            <p class="leading-snug text-sm font-normal">
              {{ $t("login.selector.timePlayed") }}: {{ calculatePlayed(character.played) }}</p>
          </div>
        </div>
        <div
          class="p-4 shadow hover:bg-gray-200 flex cursor-pointer bg-rockstar-orange"
          style="text-shadow: 0 1px 1px rgba(26,26,26,.2)"
          @click="goGame(characters[selected].id)"
        >
          <p class="w-full text-white font-bold text-center ">
            {{ $t("login.selector.joinGame") }}

          </p>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
import moment from 'moment';

export default {
  data () {
    return {
      selected: null,
      disabled: false
    };
  },
  computed: {
    characters () {
      return this.$store.state.player.characters;
    }
  },
  mounted () {
    if (this.characters.length > 0) this.selectCharacter(0);
  },
  methods: {
    calculatePlayed (ms) {
      const duration = parseInt(moment.duration(ms).asMinutes());

      const minutes = duration % 60;
      const hours = (duration - minutes) / 60;

      return `${hours}h ${minutes}m`;
    },
    goCreator () {
      return this.$router.push({ name: 'creator' });
    },
    selectCharacter (index) {
      this.selected = index;
      const outfit = this.characters[index].outfit;

      mp.trigger('setOutfit', JSON.stringify({ model: outfit.model, outfit: outfit.data }));
    },
    goGame (id) {
      mp.trigger('characterSelected', id);
    }

  }

};
</script>

<style lang="scss">
</style>
