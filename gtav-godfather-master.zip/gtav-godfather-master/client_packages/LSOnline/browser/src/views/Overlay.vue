<template>
  <div>
    <router-view style="z-index: 9999" />
    <interaction-menu style="z-index: -2;" />
    <inventory
      v-show="store.ui.inventory"
      @offer="handleOffer"
    />
    <modal
      v-show="currentModal"
      :is="currentModal"
      :data="data"
      @offerCanceled="currentModal = null; data = {}"
    />
    <search-items-dialog v-show="store.ui.nearbyItems" />
  </div>

</template>

<script>
import InteractionMenu from '@/components/overlay/InteractionMenu.vue';
import Inventory from '@/components/overlay/Inventory.vue';
import OfferDialog from '@/components/overlay/OfferDialog.vue';
import SearchItemsDialog from '@/components/overlay/SearchItemsDialog.vue';

export default {
  name: 'OverlayParent',
  components: {
    InteractionMenu,
    Inventory,
    OfferDialog,
    SearchItemsDialog
  },
  data () {
    return {
      currentModal: null,
      data: {}
    };
  },
  computed: {
    store () {
      return this.$store.state;
    }
  },
  methods: {
    handleOffer (player, item) {
      this.currentModal = 'OfferDialog';
      this.data = { player, item };
    }
  }
};
</script>

<style lang="scss">
.slither-enter-active,
.slither-leave-active {
  transition: transform 0.5s;
}
.slither-enter,
.slither-leave-to {
  transform: translateY(150%);
}

.slither-enter-to,
.slither-leave {
  transform: translateY(0%);
}

.slideDown-enter-active,
.slideDown-leave-active {
  transition: transform 0.5s;
}
.slideDown-enter,
.slideDown-leave-to {
  transform: translateY(-150%);
}

.slideDown-enter-to,
.slideDown-leave {
  transform: translateY(0%);
}
</style>
