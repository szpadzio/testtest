<template>
  <div class="container flex min-w-full max-w-full h-screen font-sans p-6">
    <div
      id="left-panel"
      class="w-1/3 transform-left flex flex-col justify-start items-start"
      v-if="step === 1"
    >
      <div class="header flex flex-row justify-around items-center pt-4">
        <div class="font-bold w-2/5">
          <p><span class="uppercase">Kreator</span><br /> <span class="text-4xl leading-normal uppercase">postaci</span></p>
        </div>
        <div class="flex flex-row ml-8">
          <a
            class="icon-color mx-8"
            :class="[ character.gender === 'male' ? 'icon-color-active' : null ]"
            @click="setGender('male')"
          >
            <font-awesome-icon
              icon="male"
              size="3x"
            ></font-awesome-icon>
          </a>
          <a
            class="icon-color mx-8"
            :class="[ character.gender === 'female' ? 'icon-color-active' : null ]"
            @click="setGender('female')"
          >
            <font-awesome-icon
              icon="female"
              size="3x"
            ></font-awesome-icon>
          </a>
        </div>
      </div>
      <div class="mt-4 flex flex-row justify-start flex-no-grow flex-no-shrink font-bold w-full">
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeLeft === 'parents' ? 'menu-square-active' : null"
          @click="activeLeft = 'parents'"
        >
          <a class="theme-color mx-auto mb-1 text-center">
            <font-awesome-icon
              icon="user-friends"
              size="2x"
            ></font-awesome-icon>
          </a>
          <p class="text-xs text-center leading-loose">Rodzice</p>
        </div>
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeLeft === 'eyes' ? 'menu-square-active' : null"
          @click="activeLeft = 'eyes'"
        >
          <a class="theme-color mx-auto mb-1 text-center">
            <font-awesome-icon
              icon="eye"
              size="2x"
            ></font-awesome-icon>
          </a>
          <p class="text-xs text-center leading-loose">Oczy</p>
        </div>
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeLeft === 'nose' ? 'menu-square-active' : null"
          @click="activeLeft = 'nose'"
        >
          <a class="theme-color mx-auto mb-1 text-center"><svg
              xmlns="http://www.w3.org/2000/svg"
              xmlns:xlink="http://www.w3.org/1999/xlink"
              version="1.1"
              id="Capa_1"
              x="0px"
              y="0px"
              viewBox="0 0 194.286 194.286"
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              xml:space="preserve"
            >
              <path d="M147.357,110.798c-2.204-6.012-10.344-28.585-21.889-64.867C111.908,3.312,100.359,0,97.143,0S82.378,3.312,68.818,45.931  c-11.539,36.263-19.684,58.852-21.889,64.867c-8.143,3.51-42.044,19.644-42.524,45.11c-0.123,6.515,1.975,12.019,6.233,16.358  c8.896,9.066,25.008,10.419,33.82,10.419c2.973,0,4.891-0.157,4.971-0.164c1.9-0.159,3.422-1.636,3.64-3.53  s-0.933-3.679-2.748-4.264c-5.605-1.808-15.154-6.423-16.914-11.111c-0.301-0.802-0.517-1.937,0.489-3.614  c0.838-1.396,2.4-3.252,6.275-3.252c7.57,0,17.499,6.769,20.242,11.159c1.128,1.804,2.092,3.558,3.025,5.253  c3.112,5.657,6.052,11,13.561,15.641c8.008,4.949,16.273,5.483,19.455,5.483c0.304,0,0.536-0.005,0.69-0.01  c0.153,0.005,0.386,0.01,0.69,0.01c3.182,0,11.447-0.534,19.455-5.483c7.509-4.64,10.449-9.984,13.561-15.641  c0.933-1.695,1.897-3.449,3.025-5.253c2.743-4.39,12.671-11.159,20.242-11.159c3.875,0,5.437,1.856,6.274,3.252  c1.007,1.677,0.79,2.813,0.489,3.615c-1.76,4.688-11.309,9.303-16.911,11.109c-1.816,0.583-2.969,2.367-2.752,4.263  s1.741,3.375,3.642,3.533c0.081,0.006,2,0.164,4.971,0.164c0.001,0,0.001,0,0.002,0c8.813,0,24.922-1.354,33.818-10.419  c4.259-4.34,6.356-9.844,6.233-16.359C189.401,130.442,155.5,114.308,147.357,110.798z" />
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
            </svg></a>
          <p class="text-xs text-center leading-loose">Nos</p>
        </div>
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeLeft === 'chin' ? 'menu-square-active' : null"
          @click="activeLeft = 'chin'"
        >
          <a class="theme-color mx-auto mb-1 text-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              xmlns:xlink="http://www.w3.org/1999/xlink"
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              version="1.1"
              id="Capa_1"
              x="0px"
              y="0px"
              viewBox="0 0 512 512"
              style="enable-background:new 0 0 512 512;"
              xml:space="preserve"
            >
              <g>
                <g>
                  <g>
                    <path
                      d="M480,0v105.104c0.145,72.436-32.566,141.03-88.944,186.512l-97.728,79.168c-21.956,17.077-52.7,17.077-74.656,0     l-97.728-79.168C64.567,246.134,31.855,177.54,32,105.104V0H0v105.104c-0.086,79.786,35.044,155.544,96,207.024V448h32V338.512     l70.544,57.152c33.505,27.117,81.407,27.117,114.912,0L384,338.512V448h32V312.128c60.956-51.48,96.086-127.238,96-207.024V0H480     z"
                      fill="#f0f0f0"
                    />
                    <path
                      d="M176.272,214.704C193.254,242.06,223.859,257.912,256,256c32.07,1.906,62.616-13.876,79.616-41.136     c9.896,2.576,20.078,3.893,30.304,3.92H368v-32h-2.08c-15.032-0.019-29.82-3.792-43.024-10.976L299.2,163.2l-2.592-1.104     c-12.587-4.124-26.392-1.893-37.04,5.984c-1.263,0.915-2.476,1.897-3.632,2.944c-1.156-1.047-2.369-2.029-3.632-2.944     c-10.645-7.885-24.454-10.116-37.04-5.984l-27.504,14.176c-13.49,7.077-28.527,10.695-43.76,10.528l1.6,32     C155.958,218.757,166.266,217.38,176.272,214.704z M226.272,192.192c2.575-0.503,5.241,0.133,7.312,1.744     c4.246,3.407,6.626,8.624,6.416,14.064h32c-0.219-5.442,2.156-10.666,6.4-14.08c2.048-1.619,4.704-2.257,7.264-1.744     l19.632,10.512C293.407,217.516,274.947,225.497,256,224c-19.05,1.633-37.642-6.439-49.456-21.472L226.272,192.192z"
                      fill="#f0f0f0"
                    />
                    <path
                      d="M272,96h48V64h-48c-8.837,0-16-7.163-16-16V0h-32v48C224,74.51,245.491,96,272,96z"
                      fill="#f0f0f0"
                    />
                    <rect
                      x="96"
                      y="480"
                      width="32"
                      height="32"
                      fill="#f0f0f0"
                    />
                    <rect
                      x="384"
                      y="480"
                      width="32"
                      height="32"
                      fill="#f0f0f0"
                    />
                  </g>
                </g>
              </g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
            </svg></a>
          <p class="text-xs text-center leading-loose">Podbródek</p>
        </div>
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeLeft === 'cheeks' ? 'menu-square-active' : null"
          @click="activeLeft = 'cheeks'"
        >
          <a class="theme-color mx-auto mb-1 text-center">
            <font-awesome-icon
              icon="user-friends"
              size="2x"
            ></font-awesome-icon>
          </a>
          <p class="text-xs text-center leading-loose">Policzki</p>
        </div>
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeLeft === 'lips' ? 'menu-square-active' : null"
          @click="activeLeft = 'lips'"
        >
          <a class="theme-color mx-auto mb-1 text-center"><svg
              xmlns="http://www.w3.org/2000/svg"
              xmlns:xlink="http://www.w3.org/1999/xlink"
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              version="1.1"
              id="Capa_1"
              x="0px"
              y="0px"
              width="512px"
              height="512px"
              viewBox="0 0 380.731 380.731"
              style="enable-background:new 0 0 380.731 380.731;"
              xml:space="preserve"
            >
              <g>
                <path
                  d="M378.27,174.512c-8.783-3.561-21.691-20.321-35.391-38.051c-24.84-32.23-53.004-68.753-83.352-68.753   c-40.097,0-61.975,24.353-69.544,34.862c-8.47-9.521-31.644-31.603-64.223-31.603c-25.578,0-56.763,36.611-84.247,68.911   c-15.871,18.63-30.859,36.227-38.864,38.952c-1.51,0.523-2.55,1.905-2.643,3.485c-0.093,1.586,0.784,3.085,2.237,3.765   c13.442,6.338,27.222,23.446,43.175,43.245c22.319,27.722,47.625,59.139,81.238,72.035c20.466,7.843,42.46,11.666,67.266,11.666   c23.731,0,46.725-3.626,64.095-6.763c29.86-5.415,74.511-64.763,101.175-100.234c8.517-11.34,17.336-23.057,19.555-24.486   c1.289-0.738,2.08-2.167,1.975-3.666C380.629,176.376,379.688,175.069,378.27,174.512z M337.047,186.101   c-17.742,11.729-62.102,35.599-133.15,38.865c-73.424,3.322-127.648-22.621-150.874-36.401   c15.812-3.689,29.221-11.125,41.281-17.823c13.675-7.581,25.497-14.134,37.824-14.134c15.244,0,30.267,4.938,42.333,8.911   c9.684,3.189,17.369,5.688,23.011,5.27c5.077-0.337,11.805-2.324,19.589-4.642c11.84-3.509,26.584-7.877,40.793-7.877   c10.213,0,23.308,6.083,37.168,12.531C308.779,177.225,322.918,183.801,337.047,186.101z"
                  fill="#FFFFFF"
                />
              </g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
            </svg></a>
          <p class="text-xs text-center leading-loose">Usta</p>
        </div>
        <div
          class="menu-square flex-initial p-2 w-16 h-24 flex justify-center flex-col"
          :class="activeLeft === 'neck' ? 'menu-square-active' : null"
          @click="activeLeft = 'neck'"
        >
          <a class="theme-color mx-auto mb-1 text-center"><svg
              xmlns="http://www.w3.org/2000/svg"
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              xmlns:xlink="http://www.w3.org/1999/xlink"
              version="1.1"
              id="Capa_1"
              x="0px"
              y="0px"
              viewBox="0 0 507.312 507.312"
              style="enable-background:new 0 0 507.312 507.312;"
              xml:space="preserve"
              width="512px"
              height="512px"
            >
              <g>
                <g>
                  <g>
                    <path
                      d="M413.144,120c0,56.768-74.496,109.616-118.896,136c-25.323,15.096-56.885,15.096-82.208,0     c-44.4-26.384-118.896-79.232-118.896-136V0h-32v120c0,42.704,28.064,81.2,64,113.024v131.68l-57.2,20.288l10.688,30.144     l78.512-27.84V258.384c12.8,9.232,25.92,17.68,38.512,25.184c35.421,21.099,79.555,21.099,114.976,0     c12.592-7.504,25.6-16,38.512-25.184v128.912l78.512,27.84l10.688-30.144l-57.2-20.288v-131.68     c35.936-31.824,64-70.32,64-113.024V0h-32V120z"
                      fill="#FFFFFF"
                    />
                    <rect
                      x="462.306"
                      y="400.11"
                      transform="matrix(0.3345 -0.9424 0.9424 0.3345 -73.8209 727.6859)"
                      width="32"
                      height="32"
                      fill="#FFFFFF"
                    />
                    <rect
                      x="12.523"
                      y="400.443"
                      transform="matrix(-0.3345 -0.9424 0.9424 -0.3345 -353.9111 581.933)"
                      width="32"
                      height="30.976"
                      fill="#FFFFFF"
                    />
                    <polygon
                      points="289.832,484.688 312.456,507.312 339.768,480 429.144,480 429.144,448 326.52,448    "
                      fill="#FFFFFF"
                    />
                    <polygon
                      points="77.144,448 77.144,480 166.52,480 193.832,507.312 216.456,484.688 179.768,448    "
                      fill="#FFFFFF"
                    />
                  </g>
                </g>
              </g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
            </svg>
          </a>
          <p class="text-xs text-center leading-loose">Szyja</p>
        </div>
      </div>
      <div
        style="align-self: flex-start"
        class="overflow-y-scroll flex px-2 mt-6 justify-end w-5/6 opacity-75"
      >
        <transition
          name="fade"
          mode="out-in"
        >
          <keep-alive>
            <div
              class="w-full"
              :is="activeLeft"
              ref="currentView"
            ></div>
          </keep-alive>
        </transition>
      </div>
    </div>
    <div
      class="w-1/3 transform-left"
      v-if="step === 2"
    >
      <div class="header flex flex-row items-center pt-4">
        <div class="font-bold w-2/5">
          <p><span class="uppercase">Postać</span><br /> <span class="text-4xl leading-normal uppercase">dane</span></p>
        </div>
      </div>
      <div class="mt-4 flex flex-row flex-grow flex-no-shrink font-bold w-full">
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeLeftSecond === 'id' ? 'menu-square-active' : null"
          @click="activeLeftSecond = 'id'"
        >
          <a class="theme-color mx-auto mb-1 text-center"><img
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              src="@@/icons/id-icon.svg"
            /></a>
          <p class="text-xs text-center leading-loose">Dane</p>
        </div>
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeLeftSecond === 'suit' ? 'menu-square-active' : null"
          @click="activeLeftSecond = 'suit'"
        >
          <a class="theme-color mx-auto mb-1 text-center">
            <img
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              src="@@/icons/suit-icon.svg"
            /></a>
          <p class="text-xs text-center leading-loose">Odzież</p>
        </div>
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeLeftSecond === 'undershirt' ? 'menu-square-active' : null"
          @click="activeLeftSecond = 'undershirt'"
        >
          <a class="theme-color mx-auto mb-1 text-center"><img
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              src="@@/icons/shirt-icon.svg"
            /></a>
          <p class="text-xs text-center leading-loose">Podkoszulki</p>
        </div>
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeLeftSecond === 'torsos' ? 'menu-square-active' : null"
          @click="activeLeftSecond = 'torsos'"
        >
          <a class="theme-color mx-auto mb-1 text-center"><img
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              src="@@/icons/chest-icon.svg"
            /></a>
          <p class="text-xs text-center leading-loose">Torsy</p>
        </div>
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeLeftSecond === 'legs' ? 'menu-square-active' : null"
          @click="activeLeftSecond = 'legs'"
        >
          <a class="theme-color mx-auto mb-1 text-center"><img
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              src="@@/icons/leg-icon.svg"
            /></a>
          <p class="text-xs text-center leading-loose">Spodnie</p>
        </div>
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeLeftSecond === 'shoes' ? 'menu-square-active' : null"
          @click="activeLeftSecond = 'shoes'"
        >
          <a class="theme-color mx-auto mb-1 text-center"><img
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              src="@@/icons/shoes-icon.svg"
            /></a>
          <p class="text-xs text-center leading-loose">Buty</p>
        </div>
        <div
          class="menu-square flex-initial p-2 w-16 h-24 flex justify-center flex-col"
          :class="activeLeftSecond === 'accesories' ? 'menu-square-active' : null"
          @click="activeLeftSecond = 'accesories'"
        >
          <a class="theme-color mx-auto mb-1 text-center"><img
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              src="@@/icons/accesories-icon.svg"
            /></a>
          <p class="text-xs text-center leading-loose">Akcesoria</p>
        </div>
      </div>
      <div class="flex px-2 mt-6 justify-center w-5/6 opacity-75">
        <transition
          name="fade"
          mode="out-in"
        >
          <keep-alive>
            <div
              class="w-full px-4"
              :is="activeLeftSecond"
              ref="currentView"
            ></div>
          </keep-alive>
        </transition>
      </div>
    </div>
    <div class="w-1/3">
    </div>
    <div
      id="right-panel"
      class="w-1/3 transform-right flex flex-col align-end"
      v-if="step == 1"
    >
      <div class="header pl-32 flex flex-row justify-start items-center pt-4">
        <div class="font-bold w-2/5">
          <p><span class="uppercase">Postać</span><br /><span class="text-4xl leading-normal uppercase">stylowanie</span> </p>
        </div>
        <div class="flex flex-row w-1/3">
        </div>
      </div>
      <div class="mt-4 flex flex-row justify-end flex-no-grow flex-no-shrink font-bold w-full">
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeRight === 'face' ? 'menu-square-active' : null"
          @click="activeRight = 'face'"
        >
          <a class="theme-color mx-auto mb-1 text-center"><img
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              src="@@/icons/face-scan.svg"
            /></a>
          <p class="text-xs text-center leading-loose">Twarz</p>
        </div>
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeRight === 'hair' ? 'menu-square-active' : null"
          @click="activeRight = 'hair'"
        >
          <a class="theme-color mx-auto mb-1 text-center"><svg
              xmlns="http://www.w3.org/2000/svg"
              xmlns:xlink="http://www.w3.org/1999/xlink"
              version="1.1"
              id="Capa_1"
              x="0px"
              y="0px"
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              width="379.075px"
              height="379.075px"
              viewBox="0 0 379.075 379.075"
              style="enable-background:new 0 0 379.075 379.075;"
              xml:space="preserve"
            >
              <g>
                <path d="M335.91,140.862c0,0,30.243,11.455,35.731,13.738c-0.911-16.944-40.31-33.899-40.31-33.899s21.533-3.667,29.321,1.845   c0-17.422-47.631-27.488-47.631-27.488s37.11-5.506,47.631,0c0-21.994-70.541-11.006-70.541-11.006s28.398-23.804,42.131-21.977   c-10.521-16.488-58.619,7.316-58.619,7.316s16.488-27.943,31.154-28.399c-11.011-15.122-57.72,10.083-57.72,10.083   s21.065-17.866,36.631-20.161c-15.775-11-58.607,12.821-58.607,12.821s5.488-20.604,22.888-29.31   c-17.399-10.533-48.565,23.816-48.565,23.816s12.821-22.905,31.154-37.554c-27.499-7.8-69.619,53.125-69.619,53.125   s-8.717-27.955,5.488-39.398c-28.399-5.045-30.226,32.976-30.226,32.976s-24.727-11.409-29.31-22.864   c-15.11,19.693,16.488,34.809,16.488,34.809s-35.271-3.672-38.465-20.16C67.039,56.133,85.839,95.07,85.839,95.07   S58.8,94.147,61.095,81.326c-12.827,5.033-6.417,30.232-6.417,30.232s-6.411,1.816-10.083-11   c-7.315,21.533,6.411,34.815,6.411,34.815s-15.116-5.512-21.071-15.577c-6.86,16.021,14.66,40.309,14.66,40.309   s-21.065-13.744-24.271-22.449c-6.866,17.399,17.86,46.265,17.86,46.265s-22.893-16.044-25.661-22.91   c-9.155,14.672,25.661,47.648,25.661,47.648s-27.395-3.947-30.227-18.327c-4.122,14.672,17.411,29.327,17.411,29.327   S17.131,265.9,7.958,251.712c-0.455,26.111,34.81,23.822,34.81,23.822s-3.661,19.688-14.661,22.91   c15.116,16.033,26.571-12.821,26.571-12.821s-3.217,34.343-15.571,40.403c14.205,10.193,24.726-14.761,24.726-14.761   s7.321,26.612-5.5,29.31c11,6.878,15.583-8.232,15.583-8.232s4.122,18.766,0,24.721c12.366,4.146,13.727-17.398,13.727-17.398   s25.193,26.588,26.583,39.41c15.84-12.693-0.695-46.09-18.023-76.988c-3.229-18.636-4.986-48.553,6.329-53.41   c6.072-2.604,12.996,2.498,23.628,11.21c12.395,10.183,27.833,22.829,46.679,14.409c12.757-5.698,15.939-17.247,19.285-29.496   c5.623-20.436,13.33-48.086,66.437-76.672c8.162,22.887,6.422,48.074-11.514,57.043c35.709,10.065,32.381-76.871,32.381-76.871   s25.853,42.51,7.929,64.959c37.565-4.192,9.446-68.142,9.446-68.142s15.729,7.222,16.196,34.237   c17.399-11.455,3.655-43.06,3.655-43.06s25.666,19.682,25.666,34.81C355.609,156.445,335.91,140.862,335.91,140.862z" />
              </g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
              <g></g>
            </svg></a>
          <p class="text-xs text-center leading-loose">Włosy</p>
        </div>
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeRight === 'beard' ? 'menu-square-active' : null"
          @click="goBeard"
        >
          <a class="theme-color mx-auto mb-1 text-center"><img
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              src="@@/icons/beard-icon.svg"
              style="fill: white!important"
            /></a>
          <p class="text-xs text-center leading-loose">Broda</p>
        </div>
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeRight === 'makeup' ? 'menu-square-active' : null"
          @click="activeRight = 'makeup'"
        >
          <a class="theme-color mx-auto mb-1 text-center"><img
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              src="@@/icons/lipstick-icon.svg"
            /></a>
          <p class="text-xs text-center leading-loose">Makijaż</p>
        </div>
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeRight === 'age' ? 'menu-square-active' : null"
          @click="activeRight = 'age'"
        >
          <a class="theme-color mx-auto mb-1 text-center"><img
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              src="@@/icons/ageing-icon.svg"
            ></a>
          <p class="text-xs text-center leading-loose">Wiek</p>
        </div>
        <div
          class="menu-square flex-initial p-2 h-24 flex justify-center flex-col"
          :class="activeRight === 'torso' ? 'menu-square-active' : null"
          @click="goTorso"
        >
          <a class="theme-color mx-auto mb-1 text-center"><img
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              src="@@/icons/chest-icon.svg"
            /></a>
          <p class="text-xs text-center leading-loose">Tors</p>
        </div>
        <div
          class="menu-square flex-initial p-2 w-16 h-24 flex justify-center flex-col"
          :class="activeRight === 'chest' ? 'menu-square-active' : null"
          @click="activeRight = 'chest'"
        >
          <a class="theme-color mx-auto mb-1 text-center"><img
              class="svg-inline--fa fa-eye fa-w-18 fa-2x"
              src="@@/icons/body-icon.svg"
            /></a>
          <p class="text-xs text-center leading-loose">Ciało</p>
        </div>
      </div>
      <div
        style="align-self: flex-end"
        class="overflow-y-scroll flex px-2 mt-6 justify-end w-5/6 opacity-75"
      >
        <transition
          name="fade"
          mode="out-in"
        >
          <keep-alive>
            <div
              class="w-full"
              :is="activeRight"
              ref="currentView"
            ></div>
          </keep-alive>
        </transition>
      </div>
    </div>
    <button
      style="position: absolute; right: 2rem; bottom: 2rem;"
      class="transform-right bg-green hover:bg-green-dark text-white font-bold py-2 px-4 rounded"
      @click="step++"
      v-if="step === 1"
    >
      Dalej
    </button>
    <button
      style="position: absolute; right: 2rem; bottom: 2rem;"
      class="transform-right bg-green hover:bg-green-dark text-white font-bold py-2 px-4 rounded"
      @click="joinGame()"
      v-if="step === 2"
    >
      Wejdź do gry
    </button>
    <button
      style="position: absolute; left: 2rem; bottom: 2rem;"
      class="transform-left bg-red hover:bg-red-dark text-white font-bold py-2 px-4 rounded"
      @click="step--"
      v-if="step === 2"
    >
      Cofnij
    </button>

  </div>
</template>

<script>
import pedService from '@/services';
import updatePed from '@/components/creator/updatePed';
import { library } from '@fortawesome/fontawesome-svg-core';

import {
  faUserFriends, faEye, faMale, faFemale, faVenus, faMars
} from '@fortawesome/free-solid-svg-icons';

library.add(faUserFriends, faEye, faMale, faFemale, faVenus, faMars);
export default {
  name: 'creationParent',
  data () {
    return {
      activeLeft: 'parents',
      activeRight: 'face',
      activeLeftSecond: 'id',
      view: 'parents',
      step: 1,
      alerts: null
    };
  },
  computed: {
    character () {
      return this.$store.state.creator.character;
    }
  },
  watch: {
    activeLeft (newValue) {
      this.switchCamera(newValue);
    },
    activeRight (newValue) {
      this.switchCamera(newValue);
    },
    activeLeftSecond (newValue) {
      this.switchCamera(newValue);
    }
  },
  async mounted () {
    const result = await pedService.getVariations(this.character.model);
    this.character.maxDrawables = result.drawables;
    this.character.maxTextures = result.textures;
  },
  methods: {
    rotatePed () {
      mp.trigger('rotatePed', this.rotation);
    },
    savePed () {
      mp.trigger('saveOutfit', JSON.stringify(this.character));
    },
    goBeard () {
      if (this.character.gender !== 'female') this.activeRight = 'beard';
    },
    goTorso () {
      if (this.character.gender !== 'female') this.activeRight = 'torso';
    },
    async setGender (gender) {
      this.character.gender = gender;
      this.character.gender === 'male' ? this.character.model = 'mp_m_freemode_01' : this.character.model = 'mp_f_freemode_01';

      const result = await pedService.changeGender(this.character.model);
      this.character.maxDrawables = result.drawables;
      this.character.maxTextures = result.textures;
    },
    switchCamera (value) {
      if (['eyes', 'nose', 'chin', 'lips', 'neck', 'face', 'hair', 'cheeks', 'beard', 'makeup', 'age'].includes(value)) {
        mp.trigger('switchCamera', 'head');
      } else if (['tops', 'torso', 'chest', 'undershirt'].includes(value)) {
        mp.trigger('switchCamera', 'torso');
      } else if (['legs', 'shoes'].includes(value)) {
        mp.trigger('switchCamera', 'legs');
      } else {
        mp.trigger('switchCamera', 'start');
      }
    },
    joinGame () {
      if (this.character.identify.name.length < 2 || this.character.identify.secondName.length < 3 || this.character.identify.secondName.length < 3 || this.character.identify.name.match(/\d+/) || this.character.identify.secondName.match(/\d+/)) {
        // this.sendNotify('Dane postaci są wypełnione nieprawidłowo', 'error');
      } else {
        this.$router.push({ name: 'home' });
        mp.trigger('characterCreated', JSON.stringify(this.character));
      }
    },
    sendNotify (message, type = 'info') {
      this.alerts = {
        type,
        message
      };
    },
    updatePed
  },
  components: {
    'parents': () => import('@/components/creator/Parents.vue'),
    'eyes': () => import('@/components/creator/Eyes.vue'),
    'hair': () => import('@/components/creator/Hair.vue'),
    'cheeks': () => import('@/components/creator/Cheeks.vue'),
    'chin': () => import('@/components/creator/Chin.vue'),
    'lips': () => import('@/components/creator/Lips.vue'),
    'neck': () => import('@/components/creator/Neck.vue'),
    'nose': () => import('@/components/creator/Nose.vue'),
    'face': () => import('@/components/creator/Face.vue'),
    'beard': () => import('@/components/creator/Beard.vue'),
    'makeup': () => import('@/components/creator/Makeup.vue'),
    'torso': () => import('@/components/creator/Torso.vue'),
    'chest': () => import('@/components/creator/Chest.vue'),
    'age': () => import('@/components/creator/Ageing.vue'),
    'id': () => import('@/components/creator/Identify.vue'),
    'suit': () => import('@/components/creator/Tops.vue'),
    'undershirt': () => import('@/components/creator/Undershirt.vue'),
    'legs': () => import('@/components/creator/Legs.vue'),
    'shoes': () => import('@/components/creator/Shoes.vue'),
    'accesories': () => import('@/components/creator/Accesories.vue'),
    'torsos': () => import('@/components/creator/Torsos.vue')

  }

};
</script>

<style lang="scss">
html,
body {
  overflow: hidden;
  padding: 0;
  margin: 0;
  background: linear-gradient(
      to right,
      rgba(0, 0, 0, 0.9),
      rgba(255, 255, 255, 0) 40%
    ),
    linear-gradient(to left, rgba(0, 0, 0, 0.9), rgba(255, 255, 255, 0) 40%);
  color: #f0f0f0;
  user-select: none;
}
.transform-left {
  transform: perspective(1000px) rotateY(5deg);
  > div:not(:last-child) {
    min-height: min-content;
  }
}
.transform-right {
  transform: perspective(1000px) rotateY(-5deg);
  > div:not(:last-child) {
    min-height: min-content;
  }
}
.theme-color {
  color: #f0f0f0;
}
.menu-square {
  min-width: 4.5rem;
  border: 1px rgba(#f0f0f0, 0.2) solid;
  transition: ease-in-out 0.5s;
  flex-initial: 1;
  &:hover,
  &-active {
    background-color: rgba(rgb(99, 180, 247), 0.3);
  }
}
svg {
  fill: #f0f0f0;
}
a {
  display: block;
}
.fa-2x {
  width: 2rem;
  height: 2rem;
}
</style>
