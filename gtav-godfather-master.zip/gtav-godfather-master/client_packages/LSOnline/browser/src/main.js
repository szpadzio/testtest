import './mock';

import Vue from 'vue';
import VueI18n from 'vue-i18n';

import App from './App.vue';
import router from './router';
import store from './store/index';
import './plugins/fontawesome';
import locales from '../../lang/locales';

Vue.use(VueI18n);
Vue.config.productionTip = false;

const i18n = new VueI18n({
  locale: 'en', // set locale
  messages: locales.messages // set locale messages
});
const app = new Vue({
  router,
  store,
  i18n,
  render: h => h(App)
}).$mount('#app');

Vue.mixin({
  methods: {
  }
});

window.vm = app;
window.rageEvents = {};
