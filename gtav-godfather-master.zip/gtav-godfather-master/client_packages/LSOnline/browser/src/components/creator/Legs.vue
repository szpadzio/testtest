<template>
<div @input="updatePed()">
  <slider class="pb-4" header="Spodnie" :min="0" :max="state.creator.character.maxDrawables[4]" :step="1" v-model="state.creator.character.drawables[4]"></slider>
  <slider class="pb-4" header="Tekstura" :min="0" :max="state.creator.character.maxTextures[4][state.creator.character.drawables[4]]" :step="1" v-model="state.creator.character.textures[4]"></slider>
</div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';

export default {
  computed: {
    state () {
      return this.$store.state;
    },
    max () {
      return this.state.creator.character.maxTextures[4][this.state.creator.character.drawables[4]];
    }
  },
  watch: {
    max () {
      this.state.creator.character.textures[4] = 0;
    }
  },
  data () {
    return {
    };
  },
  methods: {
    updatePed
  },
  components: {
    slider
  }
};
</script>

<style>

</style>
