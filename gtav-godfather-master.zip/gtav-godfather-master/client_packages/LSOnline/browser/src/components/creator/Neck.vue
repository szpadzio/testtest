<template>
  <div @input="updatePed()">
    <slider
      :min="-1"
      :max="1"
      :step="0.05"
      v-model="state.creator.character.features[19]"
      class="pb-4 green"
      header="Wielkość szyi"/>
  </div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';

export default {
  components: {
    slider
  },
  data () {
    return {
    };
  },
  computed: {
    state () {
      return this.$store.state;
    }
  },
  methods: {
    updatePed
  }
};
</script>

<style>

</style>
