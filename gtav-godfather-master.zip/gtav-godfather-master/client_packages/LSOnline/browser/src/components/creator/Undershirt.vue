<template>
  <div @input="updatePed()">
    <slider
      :min="0"
      :max="state.creator.character.maxDrawables[8]"
      :step="1"
      v-model="state.creator.character.drawables[8]"
      class="pb-4"
      header="Podkoszulki"/>
    <slider
      :min="0"
      :max="state.creator.character.maxTextures[8][state.creator.character.drawables[8]]"
      :step="1"
      v-model="state.creator.character.textures[8]"
      class="pb-4"
      header="Tekstura"/>
  </div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';

export default {
  components: {
    slider
  },
  data () {
    return {
    };
  },
  computed: {
    state () {
      return this.$store.state;
    },
    max () {
      return this.state.creator.character.maxTextures[8][this.state.creator.character.drawables[8]];
    }
  },
  watch: {
    max () {
      this.state.creator.character.textures[8] = 0;
    }
  },
  methods: {
    updatePed
  }
};
</script>

<style>

</style>
