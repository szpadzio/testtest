<template>
<div @input="updatePed()">
  <slider class="pb-4" header="Twarz ojca" :min="0" :max="fathers.length-1" v-model="father" @input="updateFather()"></slider>
  <slider class="pb-4" header="Przodkowie ojca" :min="0" :max="fathers.length-1" v-model="state.creator.character.skinSecondID"></slider>
  <slider class="pb-4" header="Twarz matki" :min="0" :max="mothers.length-1" v-model="mother" @input="updateMother()"></slider>
  <slider class="pb-4" header="Przodkowie matki" :min="0" :max="mothers.length-1"  v-model="state.creator.character.skinFirstID"></slider>
  <slider class="pb-4" header="Dominacja kształtu twarzy" :label_min="'Matka'" icon_min="mars" label_max="Ojciec" icon_max="venus"  :min="0" :max="1" :step="0.05" v-model="state.creator.character.shapeMix"></slider>
  <slider class="pb-4" header="Dominacja koloru skóry" :label_min="'Matka'" icon_min="mars" label_max="Ojciec" icon_max="venus" :min="0" :max="1" :step="0.05" v-model="state.creator.character.skinMix"></slider>
</div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';
export default {
  name: 'parents',
  data () {
    return {
      mother: 0,
      father: 0,
      fathers: [{ name: 'Benjamin', value: 0 }, { name: 'Daniel', value: 1 }, { name: 'Joshua', value: 2 }, { name: 'Noah', value: 3 }, { name: 'Andrew', value: 4 }, { name: 'Juan', value: 5 }, { name: 'Alex', value: 6 }, { name: 'Isaac', value: 7 }, { name: 'Evan', value: 8 }, { name: 'Ethan', value: 9 }, { name: 'Vincent', value: 10 }, { name: 'Angel', value: 11 }, { name: 'Diego', value: 12 }, { name: 'Adrian', value: 13 }, { name: 'Gabriel', value: 14 }, { name: 'Michael', value: 15 }, { name: 'Santiago', value: 16 }, { name: 'Kevin', value: 17 }, { name: 'Louis', value: 18 }, { name: 'Samuel', value: 19 }, { name: 'Anthony', value: 20 }, { name: 'Claude', value: 42 }, { name: 'Niko', value: 43 }, { name: 'John', value: 44 }],
      mothers: [{ name: 'Hannah', value: 21 }, { name: 'Audrey', value: 22 }, { name: 'Jasmine', value: 23 }, { name: 'Giselle', value: 24 }, { name: 'Amelia', value: 25 }, { name: 'Isabella', value: 26 }, { name: 'Zoe', value: 27 }, { name: 'Ava', value: 28 }, { name: 'Camila', value: 29 }, { name: 'Violet', value: 30 }, { name: 'Sophia', value: 31 }, { name: 'Evelyn', value: 32 }, { name: 'Nicole', value: 33 }, { name: 'Ashley', value: 34 }, { name: 'Grace', value: 35 }, { name: 'Brianna', value: 36 }, { name: 'Natalie', value: 37 }, { name: 'Olivia', value: 38 }, { name: 'Elizabeth', value: 39 }, { name: 'Charlotte', value: 40 }, { name: 'Emma', value: 41 }, { name: 'Misty', value: 45 }]
    };
  },
  computed: {
    state () {
      return this.$store.state;
    }
  },
  watch: {
  },
  methods: {
    updateFather () {
      this.state.creator.character.shapeSecondID = this.fathers[this.father].value;
      this.updatePed();
    },
    updateMother () {
      this.state.creator.character.shapeFirstID = this.mothers[this.mother].value;
      this.updatePed();
    },
    updatePed
  },
  components: {
    slider
  }
};
</script>

<style lang="scss">

</style>
