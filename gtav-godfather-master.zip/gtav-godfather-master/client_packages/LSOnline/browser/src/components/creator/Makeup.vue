<template>
  <div @input="updatePed()">
    <transition-group name="fade-list">
      <slider
        :key="1"
        :switcher="true"
        :min="-1"
        :max="74"
        :step="1"
        v-model="state.creator.character.overlays[4]"
        class="pb-4 orange"
        header="Makijaż"/>
      <slider
        v-if="state.creator.character.overlays[4] > -1"
        :key="2"
        :min="0"
        :max="1"
        :step="0.05"
        v-model="state.creator.character.overlaysOpacity[4]"
        class="pb-4 orange"
        header="Moc makijażu"/>
      <slider
        :key="3"
        :switcher="true"
        :min="-1"
        :max="9"
        :step="1"
        v-model="state.creator.character.overlays[8]"
        class="pb-4 orange"
        header="Szminka"/>
      <slider
        v-if="state.creator.character.overlays[8] > -1"
        :key="4"
        :min="0"
        :max="1"
        :step="0.05"
        v-model="state.creator.character.overlaysOpacity[8]"
        class="pb-4 orange"
        header="Nasycenie szminki"/>
      <slider
        :key="5"
        :min="0"
        :max="63"
        :step="1"
        v-model="state.creator.character.overlaysColor1[8]"
        class="pb-4 orange"
        header="Kolor szminki"/>
    </transition-group>
  </div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';

export default {
  components: {
    slider
  },
  data () {
    return {
    };
  },
  computed: {
    state () {
      return this.$store.state;
    }
  },
  methods: {
    updatePed
  }
};

</script>

<style>

</style>
