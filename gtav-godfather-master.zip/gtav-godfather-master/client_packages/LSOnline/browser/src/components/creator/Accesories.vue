<template>
  <div @input="updatePed()">
    <slider
      :min="0"
      :max="state.creator.character.maxDrawables[7]"
      :step="1"
      v-model="state.creator.character.drawables[7]"
      class="pb-4"
      header="Akcesoria"/>
    <slider
      :min="0"
      :max="max"
      :step="1"
      v-model="state.creator.character.textures[7]"
      class="pb-4"
      header="Tekstura"/>
  </div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';

export default {
  components: {
    slider
  },
  data () {
    return {
    };
  },
  computed: {
    state () {
      return this.$store.state;
    },
    max () {
      return this.state.creator.character.maxTextures[7][this.state.creator.character.drawables[7]];
    }
  },
  watch: {
    max () {
      this.state.creator.character.textures[7] = 0;
    }
  },
  methods: {
    updatePed
  }
};
</script>

<style>

</style>
