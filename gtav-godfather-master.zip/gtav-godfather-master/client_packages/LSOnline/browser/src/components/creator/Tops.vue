<template>
  <div>
    <slider
      :min="0"
      :max="state.creator.character.maxDrawables[11]"
      :step="1"
      v-model="top"
      class="pb-4"
      header="Odzież wierzchnia"
      @input="handleTorso()"/>
    <slider
      :min="0"
      :max="max"
      :step="1"
      v-model="texture"
      class="pb-4"
      header="Tekstura"
      @input="handleTexture()"/>
  </div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';
import topCombinations from './topCombinations';

export default {
  components: {
    slider
  },
  data () {
    return {
      top: 0,
      texture: 0
    };
  },
  computed: {
    state () {
      return this.$store.state;
    },
    max () {
      const top = this.top;
      return this.topCombinations.filter(value => value.id === top)[0].texture.length - 1;
    },
    topCombinations () {
      return topCombinations[this.state.creator.character.gender];
    }
  },
  watch: {
    max () {
      this.texture = 0;
    }
  },
  methods: {
    updatePed,
    handleTorso () {
      this.state.creator.character.drawables[11] = this.top;
      const object = this.topCombinations.filter(value => value.id === this.top)[0] || 0;
      this.state.creator.character.drawables[3] = object.tors;
      this.handleTexture();
    },
    handleTexture () {
      const object = this.topCombinations.filter(value => value.id === this.top)[0] || 0;
      this.state.creator.character.textures[11] = object.texture[this.texture];
      this.updatePed();
    }
  }
};
</script>

<style>

</style>
