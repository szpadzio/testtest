<template>
<div @input="updatePed()">
  <slider class="pb-4 green" header="Długość podbródka" :min="-1" :max="1" :step="0.05" v-model="state.creator.character.features[15]"></slider>
  <slider class="pb-4 green" header="Pozycja podbródka" :min="-1" :max="1" :step="0.05" v-model="state.creator.character.features[16]"></slider>
  <slider class="pb-4 green" header="Szerokość podbródka" :min="-1" :max="1" :step="0.05" v-model="state.creator.character.features[17]"></slider>
  <slider class="pb-4 green" header="Kształt podbródka" :min="-1" :max="1" :step="0.05" v-model="state.creator.character.features[18]"></slider>
  <slider class="pb-4 green" header="Szerokość szczęki" :min="-1" :max="1" :step="0.05" v-model="state.creator.character.features[13]"></slider>
  <slider class="pb-4 green" header="Wysokość szczęki" :min="-1" :max="1" :step="0.05" v-model="state.creator.character.features[14]"></slider>
</div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';

export default {
  computed: {
    state () {
      return this.$store.state;
    }
  },
  data () {
    return {
    };
  },
  methods: {
    updatePed
  },
  components: {
    slider
  }
};
</script>

<style>

</style>
