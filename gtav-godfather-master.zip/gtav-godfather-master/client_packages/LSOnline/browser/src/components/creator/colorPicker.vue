<template>
  <div>
    <transition
      name="fade"
      mode="out-in">
      <div
        v-if="step === 1"
        :key="1">
        <div class="text">
          <h3 class="text-center block pb-6">{{ header }}</h3>
        </div>
        <div class="inline-flex flex-wrap justify-end">
          <div
            v-for="color in colors"
            :color-id="color.id"
            :key="color.id"
            :style="'background-color: ' + color.color"
            class="color-box"
            @click="updateValue"/>
        </div>
      </div>
      <div
        v-else
        :key="2">
        <div class="text">
          <h3 class="text-center block pb-6">Kolor rozjaśnienia / końcówek</h3>
        </div>
        <div class="inline-flex flex-wrap justify-center">
          <div
            class="color-box cross"
            @click="updateValue"/>
          <div
            v-for="color in colors"
            :color-id="color.id"
            :key="color.id"
            :style="'background-color: ' + color.color"
            class="color-box"
            @click="updateValue"/>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
export default {
  components: {
  },
  props: {
    steps: {
      type: Boolean,
      default: false
    },
    header: {
      type: String,
      default: null
    }
  },
  data () {
    return {
      step: 1,
      colors: [{ id: 0, color: '#0f0e0f' }, { id: 1, color: '#2f2a25' }, { id: 2, color: '#574234' }, { id: 3, color: '#4d291b' }, { id: 4, color: '#72341c' },
        { id: 5, color: '#964623' }, { id: 6, color: '#ae643a' }, { id: 7, color: '#a06340' }, { id: 8, color: '#b78259' }, { id: 9, color: '#b48156' },
        { id: 10, color: '#c29566' }, { id: 11, color: '#d6b37d' }, { id: 12, color: '#d9b681' }, { id: 13, color: '#d8af69' }, { id: 14, color: '#e4bb76' },
        { id: 15, color: '#f4d59c' }, { id: 16, color: '#cd9c6a' }, { id: 17, color: '#9b5438' }, { id: 18, color: '#9c3d29' }, { id: 19, color: '#7d1210' },
        { id: 20, color: '#8c1a14' }, { id: 21, color: '#ae1d15' }, { id: 22, color: '#d64e2d' }, { id: 23, color: '#e65021' }, { id: 24, color: '#ce6333' },
        { id: 25, color: '#d64d22' }, { id: 26, color: '#9f8470' }, { id: 27, color: '#b99e88' }, { id: 28, color: '#d3bba4' }, { id: 29, color: '#eed9c5' },
        { id: 30, color: '#684551' }, { id: 31, color: '#844f67' }, { id: 32, color: '#ae516c' }, { id: 33, color: '#ee3aba' }, { id: 34, color: '#fe5897' },
        { id: 35, color: '#f9a3a9' }, { id: 36, color: '#0c9b8c' }, { id: 37, color: '#0e787e' }, { id: 38, color: '#084d79' }, { id: 39, color: '#6ba35d' },
        { id: 40, color: '#318a5a' }, { id: 41, color: '#1a594b' }, { id: 42, color: '#b5bb30' }, { id: 43, color: '#9eb81a' }, { id: 44, color: '#57942a' },
        { id: 45, color: '#eec45f' }, { id: 46, color: '#f2be0e' }, { id: 47, color: '#f4a111' }, { id: 48, color: '#f87d11' }, { id: 49, color: '#f87d11' },
        { id: 50, color: '#fe882e' }, { id: 51, color: '#f55722' }, { id: 52, color: '#ea3f1b' }, { id: 53, color: '#c61918' }, { id: 54, color: '#7e0b0e' },
        { id: 55, color: '#201511' }, { id: 56, color: '#3a221a' }, { id: 57, color: '#542d1d' }, { id: 58, color: '#593628' }, { id: 59, color: '#663e26' },
        { id: 60, color: '#2d1c16' }, { id: 61, color: '#171413' }, { id: 62, color: '#d5b079' }, { id: 63, color: '#ebcba7' }],
      selectedColor: [0, 0]
    };
  },
  methods: {
    updateValue (e) {
      const value = e.target.getAttribute('color-id') || null;

      if (this.disabled) return false;
      if (this.steps) this.step === 2 ? this.step = 1 : this.step++;
      if (value === null) {
        this.step = 1;
      }
      this.selectedColor = Number(value);
      this.disabled = true;
      this.$emit('input', this.selectedColor);
      setTimeout(() => {
        this.disabled = false;
      }, 600);
    }
  }
};
</script>

<style lang="scss" scoped>
.color-box {
  margin: .25rem;
  height: 2rem;
  width: 2rem;
  &:hover {
    outline: 3px rgba(255, 255, 255, 1) solid;
  }
}
.active-box {
  outline: 3px rgba(255, 255, 255, 1) solid;
}
.cross {
  background-image: url('../../assets/icons/cross.png');
  background-size: contain;
}
</style>
