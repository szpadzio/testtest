<template>
  <div>
    <div class="flex-row flex-wrap flex">
      <h3 class="text-center block pb-6 w-full">Imię i nazwisko</h3>
      <div class="flex flex-row flex-shrink flex-nowrap justify-between w-full ">
        <input
          v-model.trim="state.creator.character.identify.name"
          class=" shadow appearance-none border  w-5/12 flex flex-shrink border-gray-600 text-black text-center rounded py-2 px-3 mb-3 leading-tight focus:outline-none focus:shadow-outline"
          placeholder="John"
        />
        <input
          v-model.trim="state.creator.character.identify.secondName"
          class="shadow appearance-none border  w-5/12 flexflex-shrinkborder-gray-600 text-black text-center rounded py-2 px-3 mb-3 leading-tight focus:outline-none focus:shadow-outline"
          placeholder="Junior Doe"
        />
      </div>
    </div>
    <div class="flex-col">
      <h3 class="text-center block pb-3">Data urodzenia</h3>
      <h5 class="text-center text-grey block pb-3"> {{ age }} lat</h5>

      <!--
        eslint-disable
        -->
      <date-picker
        :disabledDates="disabledDates"
        :language="pl"
        v-model="state.creator.character.identify.birthday"
        :value="new Date('12-12-2000')"
        :input-class="'w-full text-black shadow appearance-none border border-gray-600 text-center rounded py-2 px-3 mb-3 leading-tight focus:outline-none focus:shadow-outline'"
      />
    </div>
    <div class="flex-row flex-wrap flex">
      <h3 class="text-center block pb-6 w-full">Kraj pochodzenia</h3>
      <div class="flex flex-row w-full">
        <input
          v-model.trim="state.creator.character.identify.ethinicity"
          class="w-full shadow appearance-none border border-gray-600 text-black text-center rounded py-2 px-3 mb-3 leading-tight focus:outline-none focus:shadow-outline"
          placeholder="Stany Zjednoczone"
        />
      </div>
    </div>
  </div>
</template>

<script>
import updatePed from './updatePed';
import datePicker from 'vuejs-datepicker';
import { pl } from 'vuejs-datepicker/dist/locale/';

export default {
  components: {
    datePicker
  },
  data () {
    return {
      pl,
      disabledDates: {
        customPredictor: (date) => {
          const now = new Date().getFullYear();
          const endYear = now - 15;
          const startYear = now - 90;
          date = date.getFullYear();

          return date > endYear || date < startYear;
        }
      }
    };
  },
  computed: {
    age () {
      return new Date().getFullYear() - this.state.creator.character.identify.birthday.getFullYear();
    },
    state () {
      return this.$store.state;
    }
  },
  methods: {
    updatePed
  }
};
</script>

<style lang="scss">
::-webkit-input-placeholder {
  text-align: center;
}
select {
  width: 400px;
  text-align-last: center;
}
$accent: rgba(rgb(99, 180, 247), 0.3) !important;
.vdp-datepicker__calendar {
  background: #333;
  border: 1px solid $accent;
  margin-left: 4.5rem;
  .prev::after {
    border-right-color: #f0f0f0 !important;
  }
  .next::after {
    border-left-color: #f0f0f0 !important;
  }
  .cell:not(.blank):hover {
    border: 1px solid $accent;
  }
  header {
    *:hover {
      background-color: $accent;
    }
  }
  .selected {
    background-color: $accent;
  }
}
</style>
