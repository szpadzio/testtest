<template>
  <div class="range-slider flex-col">
    <h3 class="text-center block pb-6">{{ header }}</h3>
    <div class="flex flex-col justify-center">
      <div class="flex justify-center">
        <input
          :class="theme"
          :min="min"
          :step="step"
          :max="max"
          :value="value"
          class="range-slider__range"
          type="range"
          @input="updateValue" />
        <span class="range-slider__value">
          <span v-if="switcher && value === -1">OFF</span>
          <span v-else>{{ value }}</span>
        </span>
      </div>
      <div
        v-if="label_min || label_mid || label_max"
        class="flex flex-row pl-2 pr-4 mt-4 text-xs font-sans">
        <div class="w-1/3">
          <font-awesome-icon
            v-if="icon_min"
            :icon="icon_min"
            style="font-size: 1.25em"
            class="mr-1"/>{{ label_min }}
        </div>
        <div class="w-1/3 text-center">
          {{ label_mid }}
        </div>
        <div class="w-1/3">
          <span style="float: right">{{ label_max }}<font-awesome-icon
            v-if="icon_max"
            :icon="icon_max"
            style="font-size: 1.25em"
            class="ml-1"/></span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome';
export default {
  components: {
    FontAwesomeIcon
  },
  props: {
    header: {
      type: String,
      default: ''
    },
    value: {
      type: Number,
      default: 0
    },
    min: {
      type: Number,
      default: 0
    },
    max: {
      type: Number,
      default: 0
    },
    step: {
      default: 1
    },
    switcher: {
      type: Boolean,
      default: false
    },
    theme: {
      type: String,
      default: null
    },
    label_min: {
      default: null
    },
    label_max: {
      default: null
    },
    label_mid: {
      default: null
    },
    icon_max: null,
    icon_min: null
  },
  methods: {
    updateValue (e) {
      this.$emit('input', Number(e.target.value));
    }
  }
};
</script>

<style lang="scss">
.range-slider {
  display: flex;

  &__range {
      -webkit-appearance: none;
      width: 80%;
      background: transparent;
      float: left;
      &::-webkit-slider-thumb {
      -webkit-appearance: none;
      height: 1.75rem;
      width: .75rem;
      border-radius: 3px;
      background-color: #3490DC;
      cursor: pointer;
    }

    &::-webkit-slider-runnable-track {
      width: 90%;
      height: 1.75rem;
      cursor: pointer;
      background: #3D4852;
      border-radius: .5rem 0 0 .5rem;
    }
  }
  &__value {
    display: inline-block;
    line-height: 1.75rem;
    background-color: #3490DC;
    margin-left: -1px;
    min-width: 2.5rem;
    text-align: center;
    border-radius: 0 .5rem .5rem 0;
  }
}
.orange {
    input {
      &::-webkit-slider-thumb, ~span {
        background-color: rgb(219, 168, 56) !important;
    }
  }
}
.green {
    input {
      &::-webkit-slider-thumb, ~span {
        background-color: rgb(56, 219, 105) !important;
    }
  }
}
</style>
