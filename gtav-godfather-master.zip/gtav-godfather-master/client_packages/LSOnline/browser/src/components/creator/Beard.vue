<template>
  <div @input="updatePed()">
    <transition-group
      v-if="state.creator.character.gender != 'female'"
      name="fade-list">
      <slider
        :key="1"
        :switcher="true"
        :min="-1"
        :max="23"
        :step="1"
        v-model="state.creator.character.overlays[1]"
        class="pb-4 orange"
        header="Zarost"/>
      <slider
        v-if="state.creator.character.overlays[1] > -1"
        :key="2"
        :min="0.05"
        :max="1"
        :step="0.05"
        v-model="state.creator.character.overlaysOpacity[1]"
        class="pb-4 orange"
        header="Gęstość zarostu"/>
      <color-picker
        :key="3"
        v-model="state.creator.character.overlaysColor1[1]"
        :steps="false"
        header="Kolor zarostu"
        @input="updatePed()"/>
    </transition-group>
    <div v-else>
      <div class="text">
        <h3 class="text-center block pb-6">Zmień płeć</h3>
      </div>
    </div>
  </div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';
import colorPicker from './colorPicker.vue';

export default {
  components: {
    slider,
    colorPicker
  },
  data () {
    return {};
  },
  computed: {
    state () {
      return this.$store.state;
    }
  },
  methods: {
    updatePed
  }
};
</script>

<style>
</style>
