<template>
  <div @input="updatePed()">
    <slider
      :switcher="true"
      :min="-1"
      :max="11"
      :step="1"
      v-model="state.creator.character.overlays[11]"
      class="pb-4 green"
      header="Skazy na ciele"/>
    <slider
      :switcher="true"
      :min="-1"
      :max="1"
      :step="1"
      v-model="state.creator.character.overlays[12]"
      class="pb-4 green"
      header="Skazy 2"/>
    <transition-group name="fade">
      <slider
        v-if="state.creator.character.overlays[11] >= 0"
        :key="1"
        :min="0"
        :max="1"
        :step="0.05"
        v-model="state.creator.character.overlaysOpacity[11]"
        class="pb-4 green"
        header="Widoczność skaz na ciele"/>
      <slider
        v-if="state.creator.character.overlays[12] >= 0"
        :key="1"
        :min="0"
        :max="1"
        :step="0.05"
        v-model="state.creator.character.overlaysOpacity[12]"
        class="pb-4 green"
        header="Widoczność skaz 2"/>
      />
    </transition-group>
  </div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';

export default {
  components: {
    slider
  },
  data () {
    return {
    };
  },
  computed: {
    state () {
      return this.$store.state;
    }
  },
  methods: {
    updatePed
  }
};
</script>

<style>

</style>
