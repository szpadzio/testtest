<template>
  <div @input="updatePed">
    <slider
      :min="0"
      :max="max"
      :step="1"
      v-model="selectedHair"
      class="pb-4 green"
      header="Fryzura"
      @input="handleHairChange"/>
    <transition
      name="fade"
      mode="out-in">
      <div
        v-if="step === 1"
        :key="1">
        <div class="text">
          <h3 class="text-center block pb-6">Kolor włosów</h3>
        </div>
        <div class="inline-flex flex-wrap justify-end">
          <div
            v-for="color in colors"
            :key="color.id"
            :color-id="color.id"
            :style="'background-color: ' + color.color"
            class="color-box"
            @click="updateHair"/>
        </div>
      </div>
      <div
        v-else
        :key="2">
        <div class="text">
          <h3 class="text-center block pb-6">Kolor rozjaśnienia / końcówek</h3>
        </div>
        <div class="inline-flex flex-wrap justify-end">
          <div
            class="color-box cross"
            @click="updateHair(null)"/>
          <div
            v-for="color in colors"
            :color-id="color.id"
            :key="color.id"
            :style="'background-color: ' + color.color"
            class="color-box"
            @click="updateHair"/>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';

export default {
  name: 'Hair',
  components: {
    slider
  },
  data () {
    return {
      selectedHair: 0,
      step: 1,
      colors: [{ id: 0, color: '#0f0e0f' }, { id: 1, color: '#2f2a25' }, { id: 2, color: '#574234' }, { id: 3, color: '#4d291b' }, { id: 4, color: '#72341c' },
        { id: 5, color: '#964623' }, { id: 6, color: '#ae643a' }, { id: 7, color: '#a06340' }, { id: 8, color: '#b78259' }, { id: 9, color: '#b48156' },
        { id: 10, color: '#c29566' }, { id: 11, color: '#d6b37d' }, { id: 12, color: '#d9b681' }, { id: 13, color: '#d8af69' }, { id: 14, color: '#e4bb76' },
        { id: 15, color: '#f4d59c' }, { id: 16, color: '#cd9c6a' }, { id: 17, color: '#9b5438' }, { id: 18, color: '#9c3d29' }, { id: 19, color: '#7d1210' },
        { id: 20, color: '#8c1a14' }, { id: 21, color: '#ae1d15' }, { id: 22, color: '#d64e2d' }, { id: 23, color: '#e65021' }, { id: 24, color: '#ce6333' },
        { id: 25, color: '#d64d22' }, { id: 26, color: '#9f8470' }, { id: 27, color: '#b99e88' }, { id: 28, color: '#d3bba4' }, { id: 29, color: '#eed9c5' },
        { id: 30, color: '#684551' }, { id: 31, color: '#844f67' }, { id: 32, color: '#ae516c' }, { id: 33, color: '#ee3aba' }, { id: 34, color: '#fe5897' },
        { id: 35, color: '#f9a3a9' }, { id: 36, color: '#0c9b8c' }, { id: 37, color: '#0e787e' }, { id: 38, color: '#084d79' }, { id: 39, color: '#6ba35d' },
        { id: 40, color: '#318a5a' }, { id: 41, color: '#1a594b' }, { id: 42, color: '#b5bb30' }, { id: 43, color: '#9eb81a' }, { id: 44, color: '#57942a' },
        { id: 45, color: '#eec45f' }, { id: 46, color: '#f2be0e' }, { id: 47, color: '#f4a111' }, { id: 48, color: '#f87d11' }, { id: 49, color: '#f87d11' },
        { id: 50, color: '#fe882e' }, { id: 51, color: '#f55722' }, { id: 52, color: '#ea3f1b' }, { id: 53, color: '#c61918' }, { id: 54, color: '#7e0b0e' },
        { id: 55, color: '#201511' }, { id: 56, color: '#3a221a' }, { id: 57, color: '#542d1d' }, { id: 58, color: '#593628' }, { id: 59, color: '#663e26' },
        { id: 60, color: '#2d1c16' }, { id: 61, color: '#171413' }, { id: 62, color: '#d5b079' }, { id: 63, color: '#ebcba7' }],
      hairList: [
        [
          { ID: 0, Collection: 'mpbeach_overlays', Overlay: 'FM_Hair_Fuzz' },
          { ID: 1, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_001' },
          { ID: 2, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_002' },
          { ID: 3, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_003' },
          { ID: 4, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_004' },
          { ID: 5, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_005' },
          { ID: 6, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_006' },
          { ID: 7, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_007' },
          { ID: 8, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_008' },
          { ID: 9, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_009' },
          { ID: 10, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_013' },
          { ID: 11, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_002' },
          { ID: 12, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_011' },
          { ID: 13, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_012' },
          { ID: 14, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_014' },
          { ID: 15, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_015' },
          { ID: 16, Collection: 'multiplayer_overlays', Overlay: 'NGBea_M_Hair_000' },
          { ID: 17, Collection: 'multiplayer_overlays', Overlay: 'NGBea_M_Hair_001' },
          { ID: 18, Collection: 'multiplayer_overlays', Overlay: 'NGBus_M_Hair_000' },
          { ID: 19, Collection: 'multiplayer_overlays', Overlay: 'NGBus_M_Hair_001' },
          { ID: 20, Collection: 'multiplayer_overlays', Overlay: 'NGHip_M_Hair_000' },
          { ID: 21, Collection: 'multiplayer_overlays', Overlay: 'NGHip_M_Hair_001' },
          { ID: 22, Collection: 'multiplayer_overlays', Overlay: 'NGInd_M_Hair_000' },
          { ID: 24, Collection: 'mplowrider_overlays', Overlay: 'LR_M_Hair_000' },
          { ID: 25, Collection: 'mplowrider_overlays', Overlay: 'LR_M_Hair_001' },
          { ID: 26, Collection: 'mplowrider_overlays', Overlay: 'LR_M_Hair_002' },
          { ID: 27, Collection: 'mplowrider_overlays', Overlay: 'LR_M_Hair_003' },
          { ID: 28, Collection: 'mplowrider2_overlays', Overlay: 'LR_M_Hair_004' },
          { ID: 29, Collection: 'mplowrider2_overlays', Overlay: 'LR_M_Hair_005' },
          { ID: 30, Collection: 'mplowrider2_overlays', Overlay: 'LR_M_Hair_006' },
          { ID: 31, Collection: 'mpbiker_overlays', Overlay: 'MP_Biker_Hair_000_M' },
          { ID: 32, Collection: 'mpbiker_overlays', Overlay: 'MP_Biker_Hair_001_M' },
          { ID: 33, Collection: 'mpbiker_overlays', Overlay: 'MP_Biker_Hair_002_M' },
          { ID: 34, Collection: 'mpbiker_overlays', Overlay: 'MP_Biker_Hair_003_M' },
          { ID: 35, Collection: 'mpbiker_overlays', Overlay: 'MP_Biker_Hair_004_M' },
          { ID: 36, Collection: 'mpbiker_overlays', Overlay: 'MP_Biker_Hair_005_M' },
          { ID: 72, Collection: 'mpgunrunning_overlays', Overlay: 'MP_Gunrunning_Hair_M_000_M' },
          { ID: 73, Collection: 'mpgunrunning_overlays', Overlay: 'MP_Gunrunning_Hair_M_001_M' }
        ],
        // female
        [
          { ID: 0, Collection: 'mpbeach_overlays', Overlay: 'FM_Hair_Fuzz' },
          { ID: 1, Collection: 'multiplayer_overlays', Overlay: 'NG_F_Hair_001' },
          { ID: 2, Collection: 'multiplayer_overlays', Overlay: 'NG_F_Hair_002' },
          { ID: 3, Collection: 'multiplayer_overlays', Overlay: 'NG_F_Hair_003' },
          { ID: 4, Collection: 'multiplayer_overlays', Overlay: 'NG_F_Hair_004' },
          { ID: 5, Collection: 'multiplayer_overlays', Overlay: 'NG_F_Hair_005' },
          { ID: 6, Collection: 'multiplayer_overlays', Overlay: 'NG_F_Hair_006' },
          { ID: 7, Collection: 'multiplayer_overlays', Overlay: 'NG_F_Hair_007' },
          { ID: 8, Collection: 'multiplayer_overlays', Overlay: 'NG_F_Hair_008' },
          { ID: 9, Collection: 'multiplayer_overlays', Overlay: 'NG_F_Hair_009' },
          { ID: 10, Collection: 'multiplayer_overlays', Overlay: 'NG_F_Hair_010' },
          { ID: 11, Collection: 'multiplayer_overlays', Overlay: 'NG_F_Hair_011' },
          { ID: 12, Collection: 'multiplayer_overlays', Overlay: 'NG_F_Hair_012' },
          { ID: 13, Collection: 'multiplayer_overlays', Overlay: 'NG_F_Hair_013' },
          { ID: 14, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_014' },
          { ID: 15, Collection: 'multiplayer_overlays', Overlay: 'NG_M_Hair_015' },
          { ID: 16, Collection: 'multiplayer_overlays', Overlay: 'NGBea_F_Hair_000' },
          { ID: 17, Collection: 'multiplayer_overlays', Overlay: 'NGBea_F_Hair_001' },
          { ID: 18, Collection: 'multiplayer_overlays', Overlay: 'NG_F_Hair_007' },
          { ID: 19, Collection: 'multiplayer_overlays', Overlay: 'NGBus_F_Hair_000' },
          { ID: 20, Collection: 'multiplayer_overlays', Overlay: 'NGBus_F_Hair_001' },
          { ID: 21, Collection: 'multiplayer_overlays', Overlay: 'NGBea_F_Hair_001' },
          { ID: 22, Collection: 'multiplayer_overlays', Overlay: 'NGHip_F_Hair_000' },
          { ID: 23, Collection: 'multiplayer_overlays', Overlay: 'NGInd_F_Hair_000' },
          { ID: 25, Collection: 'mplowrider_overlays', Overlay: 'LR_F_Hair_000' },
          { ID: 26, Collection: 'mplowrider_overlays', Overlay: 'LR_F_Hair_001' },
          { ID: 27, Collection: 'mplowrider_overlays', Overlay: 'LR_F_Hair_002' },
          { ID: 28, Collection: 'mplowrider2_overlays', Overlay: 'LR_F_Hair_003' },
          { ID: 29, Collection: 'mplowrider2_overlays', Overlay: 'LR_F_Hair_003' },
          { ID: 30, Collection: 'mplowrider2_overlays', Overlay: 'LR_F_Hair_004' },
          { ID: 31, Collection: 'mplowrider2_overlays', Overlay: 'LR_F_Hair_006' },
          { ID: 32, Collection: 'mpbiker_overlays', Overlay: 'MP_Biker_Hair_000_F' },
          { ID: 33, Collection: 'mpbiker_overlays', Overlay: 'MP_Biker_Hair_001_F' },
          { ID: 34, Collection: 'mpbiker_overlays', Overlay: 'MP_Biker_Hair_002_F' },
          { ID: 35, Collection: 'mpbiker_overlays', Overlay: 'MP_Biker_Hair_003_F' },
          { ID: 36, Collection: 'multiplayer_overlays', Overlay: 'NG_F_Hair_003' },
          { ID: 37, Collection: 'mpbiker_overlays', Overlay: 'MP_Biker_Hair_006_F' },
          { ID: 38, Collection: 'mpbiker_overlays', Overlay: 'MP_Biker_Hair_004_F' },
          { ID: 76, Collection: 'mpgunrunning_overlays', Overlay: 'MP_Gunrunning_Hair_F_000_F' },
          { ID: 77, Collection: 'mpgunrunning_overlays', Overlay: 'MP_Gunrunning_Hair_F_001_F' }
        ]
      ]
    };
  },
  computed: {
    state () {
      return this.$store.state;
    },
    hairCollection () {
      return this.state.creator.character.gender === 'male' ? this.hairList[0] : this.hairList[1];
    },
    max () {
      return this.hairCollection.length - 1;
    }
  },
  watch: {
    max () {
      this.selectedHair = 0;
    }
  },
  methods: {
    updateHair (e) {
      if (this.disabled) return false;
      if (e === null) {
      } else if (this.step === 1) {
        this.state.creator.character.hairColor[0] = Number(e.target.getAttribute('color-id'));
        this.state.creator.character.hairColor[1] = Number(e.target.getAttribute('color-id'));
      } else {
        this.state.creator.character.hairColor[1] = Number(e.target.getAttribute('color-id'));
      }
      this.disabled = true;
      setTimeout(() => {
        this.disabled = false;
      }, 600);
      if (this.step === 2) { this.step = 1; } else this.step++;

      this.updatePed();
    },
    updatePed,
    handleHairChange () {
      this.state.creator.character.drawables[2] = this.hairCollection[this.selectedHair].ID;
      this.state.creator.character.decorations[0] = { collection: this.hairCollection[this.selectedHair].Collection, overlay: this.hairCollection[this.selectedHair].Overlay };
    }
  }
};
</script>

<style lang="scss">
.color-box {
  margin: .25rem;
  height: 2rem;
  width: 2rem;
  &:hover {
    outline: 3px rgba(255, 255, 255, 1) solid;
  }
}
.active-box {
  outline: 3px rgba(255, 255, 255, 1) solid;
}
.cross {
  background-image: url('../../assets/icons/cross.png');
  background-size: contain;
}
</style>
