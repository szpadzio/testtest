<template>
<div @input="updatePed()">
  <slider class="pb-4" header="Buty" :min="0" :max="state.creator.character.maxDrawables[6]" :step="1" v-model="state.creator.character.drawables[6]"></slider>
  <slider class="pb-4" header="Tekstura" :min="0" :max="state.creator.character.maxTextures[6][state.creator.character.drawables[6]]" :step="1" v-model="state.creator.character.textures[6]"></slider>
</div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';

export default {
  computed: {
    state () {
      return this.$store.state;
    },
    max () {
      return this.state.creator.character.maxTextures[6][this.state.creator.character.drawables[6]];
    }
  },
  watch: {
    max () {
      this.state.creator.character.textures[6] = 0;
    }
  },
  data () {
    return {
    };
  },
  methods: {
    updatePed
  },
  components: {
    slider
  }
};
</script>

<style>

</style>
