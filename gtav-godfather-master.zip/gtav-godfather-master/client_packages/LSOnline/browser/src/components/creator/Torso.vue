<template>
  <div @input="updatePed()">
    <slider
      :min="-1"
      :switcher="true"
      :max="16"
      :step="1"
      v-model="state.creator.character.overlays[10]"
      class="pb-4 green"
      header="Owłosienie"/>
    <transition-group name="fade">
      <slider
        v-if="state.creator.character.overlays[10] >= 0"
        :key="1"
        :min="0"
        :max="1"
        :step="0.05"
        v-model="state.creator.character.overlaysOpacity[10]"
        class="pb-4 green"
        header="Natężenie owłosienia"/>
      <color-picker
        v-if="state.creator.character.overlays[10] >= 0"
        :key="2"
        v-model="state.creator.character.overlaysColor1[10]"
        :steps="false"
        header="Kolor owłosienia"
        @input="updatePed()"/>
      />
    </transition-group>
  </div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';
import colorPicker from './colorPicker.vue';

export default {
  components: {
    slider,
    colorPicker
  },
  data () {
    return {
    };
  },
  computed: {
    state () {
      return this.$store.state;
    }
  },
  methods: {
    updatePed
  }
};
</script>

<style>

</style>
