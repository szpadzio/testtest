<template>
  <div @input="updatePed()">
    <transition-group name="fade">
      <slider
        :key="1"
        :switcher="true"
        :min="-1"
        :max="23"
        :step="1"
        v-model="state.character.overlays[0]"
        class="pb-4 orange"
        header="Skazy"/>
      <slider
        v-if="state.character.overlays[0] >= 0"
        :key="9"
        :min="0"
        :max="1"
        :step="0.05"
        v-model="state.character.overlaysOpacity[0]"
        class="pb-4 orange"
        header="Natężenie skaz"/>
      <slider
        :key="2"
        :min="-1"
        :switcher="true"
        :max="17"
        :step="1"
        v-model="state.character.overlays[9]"
        class="pb-4 orange"
        header="Piegi"/>
      <slider
        v-if="state.character.overlays[9] >= 0"
        :key="7"
        :min="0"
        :max="1"
        :step="0.05"
        v-model="state.character.overlaysOpacity[9]"
        class="pb-4 orange"
        header="Natężenie piegów"/>
      <slider
        :key="3"
        :switcher="true"
        :min="-1"
        :max="11"
        :step="1"
        v-model="state.character.overlays[6]"
        class="pb-4 orange"
        header="Cera"/>
      <slider
        v-if="state.character.overlays[6] >= 0"
        :key="8"
        :min="0"
        :max="1"
        :step="0.05"
        v-model="state.character.overlaysOpacity[6]"
        class="pb-4 orange"
        header="Nątężenie cery"/>
      <slider
        :key="4"
        :switcher="true"
        :min="-1"
        :max="6"
        :step="1"
        v-model="state.character.overlays[5]"
        class="pb-4 orange"
        header="Rumieńce"/>
      <slider
        v-if="state.character.overlays[5] != -1"
        :key="5"
        :min="0"
        :max="17"
        :step="1"
        v-model="state.character.overlaysColor1[5]"
        class="pb-4 orange"
        header="Kolor rumieńców"/>
      <slider
        v-if="state.character.overlays[5] != -1"
        :key="6"
        :min="0.05"
        :max="1"
        :step="0.05"
        v-model="state.character.overlaysOpacity[5]"
        class="pb-4 orange"
        header="Nasycenie rumieńców"/>
    </transition-group>
  </div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';

export default {
  components: {
    slider
  },
  data () {
    return {
      selectedEyesColor: 0,
      variations: [{ id: 0, name: 'Zielone' }, { id: 1, name: 'Szmaragdowe' }, { id: 2, name: 'Lazurowe' }, { id: 3, name: 'Niebieskie' }, { id: 4, name: 'Jasnobrązowe' },
        { id: 5, name: 'Ciemnobrązowe' }, { id: 6, name: 'Piwne' }, { id: 7, name: 'Ciemnoszare' }, { id: 8, name: 'Jasnoszare' }, { id: 9, name: 'Różowe' },
        { id: 10, name: 'Żółte' }, { id: 11, name: 'Fioletowe' }, { id: 12, name: 'Czarne' }, { id: 13, name: 'Odcień szarości' }, { id: 14, name: 'Tequila Sunrise' },
        { id: 21, name: 'Jaszczurze' }, { id: 26, name: 'Wytatuowane' }, { id: 30, name: 'Białe' }, { id: 31, name: 'Niewidome' }]
    };
  },
  computed: {
    state () {
      return this.$store.state.creator;
    },
    label_mid () {
      return this.variations[this.selectedEyesColor].name;
    }
  },
  methods: {
    updateEyeColor () {
      this.state.character.eyeColor = this.variations[this.selectedEyesColor].id;
      updatePed();
    },
    updatePed
  }
};
</script>

<style>

</style>
