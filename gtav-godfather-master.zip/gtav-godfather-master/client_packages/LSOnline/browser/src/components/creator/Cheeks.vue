<template>
<div @input="updatePed()">
  <slider class="pb-4 green" header="Kość policzkowa (szerokość)" :min="-1" :max="1" :step="0.05" v-model="state.creator.character.features[9]"></slider>
  <slider class="pb-4 green" header="Kość policzkowa (wysokość)" :min="-1" :max="1" :step="0.05" v-model="state.creator.character.features[8]"></slider>
  <slider class="pb-4 green" header="Policzki" :min="-1" :max="1" :step="0.05" v-model="state.creator.character.features[10]"></slider>
</div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';

export default {
  computed: {
    state () {
      return this.$store.state;
    }
  },
  data () {
    return {
    };
  },
  methods: {
    updatePed
  },
  components: {
    slider
  }
};
</script>

<style>

</style>
