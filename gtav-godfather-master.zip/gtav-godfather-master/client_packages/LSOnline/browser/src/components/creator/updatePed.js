import store from '@/store';

export default () => {
  mp.trigger('updatePed', JSON.stringify(store.state.creator.character));
};
