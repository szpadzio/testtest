<template>
  <div @input="updatePed()">
    <slider
      :switcher="true"
      :min="-1"
      :max="14"
      :step="1"
      v-model="state.creator.character.overlays[3]"
      class="pb-4 green"
      header="Zmarszczki"/>
    <slider
      :min="0.05"
      :max="1"
      :step="0.05"
      v-model="state.creator.character.overlaysOpacity[3]"
      class="pb-4 green"
      header="Stopień zmarszczek"/>
  </div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';

export default {
  components: {
    slider
  },
  data () {
    return {
    };
  },
  computed: {
    state () {
      return this.$store.state;
    }
  },
  methods: {
    updatePed
  }
};
</script>

<style>

</style>
