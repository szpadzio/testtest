<template>
  <div @input="updatePed()">
    <transition-group name="fade-list">
      <slider
        :key="1"
        :min="-1"
        :max="1"
        :step="0.05"
        v-model="state.creator.character.features[11]"
        class="pb-4 orange"
        header="Kształt oczu"
        label_max="Zamknięte"
        label_min="Otwarte"/>
      <slider
        :key="2"
        :min="0"
        :max="variations.length-1"
        :step="1"
        :label_mid="label_mid"
        v-model="selectedEyesColor"
        class="pb-4 orange"
        header="Kolor oczu"
        @input="updateEyeColor()"/>
      <slider
        :key="3"
        :switcher="true"
        :min="-1"
        :max="33"
        :step="1"
        v-model="state.creator.character.overlays[2]"
        class="pb-4 orange"
        header="Wygląd brwi"/>
      <slider
        v-if="state.creator.character.overlays[2] > -1"
        :key="4"
        :min="0"
        :max="1"
        :step="0.05"
        v-model="state.creator.character.overlaysOpacity[2]"
        class="pb-4 orange"
        header="Gęstość brwi" />
      <slider
        :key="5"
        :min="0"
        :max="31"
        :step="1"
        v-model="state.creator.character.overlaysColor1[2]"
        class="pb-4 orange"
        header="Kolor brwi"/>
      <slider
        :key="6"
        :min="-1"
        :max="1"
        :step="0.05"
        v-model="state.creator.character.features[6]"
        class="pb-4 orange"
        header="Kształt brwi"/>
      <slider
        :key="7"
        :min="-1"
        :max="1"
        :step="0.05"
        v-model="state.creator.character.features[7]"
        class="pb-4 orange"
        header="Szerokość brwi"/>
    </transition-group>
  </div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';

export default {
  components: {
    slider
  },
  data () {
    return {
      selectedEyesColor: 0,
      variations: [{ id: 0, name: 'Zielone' }, { id: 1, name: 'Szmaragdowe' }, { id: 2, name: 'Lazurowe' }, { id: 3, name: 'Niebieskie' }, { id: 4, name: 'Jasnobrązowe' },
        { id: 5, name: 'Ciemnobrązowe' }, { id: 6, name: 'Piwne' }, { id: 7, name: 'Ciemnoszare' }, { id: 8, name: 'Jasnoszare' }, { id: 9, name: 'Różowe' },
        { id: 10, name: 'Żółte' }, { id: 11, name: 'Fioletowe' }, { id: 12, name: 'Czarne' }, { id: 13, name: 'Odcień szarości' }, { id: 14, name: 'Tequila Sunrise' },
        { id: 21, name: 'Jaszczurze' }, { id: 26, name: 'Wytatuowane' }, { id: 30, name: 'Białe' }, { id: 31, name: 'Niewidome' }]
    };
  },
  computed: {
    state () {
      return this.$store.state;
    },
    label_mid () {
      return this.variations[this.selectedEyesColor].name;
    }
  },
  methods: {
    updateEyeColor () {
      this.state.creator.character.eyeColor = this.variations[this.selectedEyesColor].id;
      updatePed();
    },
    updatePed
  }
};
</script>

<style>

</style>
