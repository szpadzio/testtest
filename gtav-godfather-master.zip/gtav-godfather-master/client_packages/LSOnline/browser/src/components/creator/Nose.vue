<template>
<div @input="updatePed">
  <slider class="pb-4 green" header="Szerokość nosa" :min="-1" :max="1" :step="0.05" v-model="state.creator.character.features[0]"></slider>
  <slider class="pb-4 green" header="Wysokość nosa" :min="-1" :max="1" :step="0.05" v-model="state.creator.character.features[1]"></slider>
  <slider class="pb-4 green" header="Długość nosa" :min="-1" :max="1" :step="0.05" v-model="state.creator.character.features[2]"></slider>
  <slider class="pb-4 green" header="Kość nosowa" :min="-1" :max="1" :step="0.05" v-model="state.creator.character.features[3]"></slider>
  <slider class="pb-4 green" header="Czubek nosa" :min="-1" :max="1" :step="0.05" v-model="state.creator.character.features[4]"></slider>
  <slider class="pb-4 green" header="Skrzywienie nosa" :min="-1" :max="1" :step="0.05" v-model="state.creator.character.features[5]"></slider>
</div>
</template>

<script>
import updatePed from './updatePed';
import slider from './slider.vue';
export default {
  data () {
    return {

    };
  },
  computed: {
    state () {
      return this.$store.state;
    }
  },
  methods: {
    updatePed
  },
  components: {
    slider
  }
};
</script>

<style lang="scss">

</style>
