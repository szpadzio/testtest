<template>
  <div
    id="#dialog"
    class="center min-w-1/2 sm:min-w-1/3 lg:min-w-1/5 bg-white"
  >
    <div class="header-bg">
      <h1 class="text-lg  ">{{  $t("ui.inventory.nearbyItems") }}</h1>

    </div>
    <r-list :items="nearbyItems">
      <template
        slot="item"
        slot-scope="{ item }"
      >
        <div
          class="w-full"
          @click="atClick(item)"
        >
          <p class="flex w-full justify-between">{{ item.name }} <span
              class="badge text-xs"
              v-show="item.inUse"
            > {{ $t("ui.inventory.inUse") }}
            </span></p>
          <p class="font-normal leading-snug text-sm">UID: {{ item.id }}</p>
          <p class="font-normal leading-snug text-sm">{{ item.type ? $t(`ui.inventory.${item.type}`) : '' }}</p>

        </div>
      </template>
      <p class="p-4 border-t border-b  border-gray-200">{{  $t("ui.inventory.noNearby") }}</p>
    </r-list>

  </div>
</template>

<script>
import RList from '@/components/elements/List';

export default {
  components: {
    RList
  },
  computed: {
    nearbyItems () {
      return [...new Set(this.$store.state.game.nearbyItems)];
    },
    visible () {
      return this.$store.state.ui.nearbyItems;
    }
  },
  mounted () {
    window.addEventListener('keydown', this.cb);
  },
  destroyed () {
    window.removeEventListener('keydown', this.cb);
  },
  methods: {
    cb (ev) {
      if (ev.key == 'Escape' && this.visible) {
        mp.trigger('client:item:toggleNearbyItems');
      }
    },
    atClick (item) {
      mp.trigger('server:item:pickupItem', JSON.stringify({ id: item.entityId, type: item.world }));
      if (this.nearbyItems.length - 1 < 1) mp.trigger('client:item:toggleNearbyItems');
      else {
        const newArray = this.nearbyItems.filter(_item => _item.id !== item.id);
        this.$store.commit('game/setData', { key: 'nearbyItems', data: newArray });
      }
    }
  }
};
</script>

<style>
.header-bg {
  background: url("https://s.rsg.sc/sc/images/react/headers/sc_pattern_new.png"),
    linear-gradient(180deg, #f7931e 0, #fcaf17);
  @apply p-4 text-white font-semibold;
}
</style>
