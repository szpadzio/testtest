<template>
  <div
    style="position: absolute;     left: 50%;
    transform: translate(-50%, 0); height: 100vh;"
    class="flex justify-content items-center"
  >
    <svg
      ref="canvas"
      :class="options.length > 0 ? 'shown' : ''"
      version="3"
      baseProfile="full"
      width="500"
      height="500"
      xmlns="http://www.w3.org/2000/svg"
    >

      <g
        id="container"
        transform="translate(100, 150)"
      >
        <g
          id="outsider-side"
          ref="nav"
        >
          <template v-for="(option, index) in options">
            <g
              :key="index"
              :heh="index"
              class="svg-buttons"
            >
              <path
                :transform="transformString(index)"
                :d="path"
                class="svg-button"
                fill="rgba(0, 0, 0)"
                @click="handleClick(option)"
              />
              <a :transform="iconString(index)">
                <font-awesome-icon
                  ref="buttons"
                  :icon="option.action"
                  class="fa-lock"
                  height="50"
                  text-anchor="middle"
                />
              </a>
            </g>
          </template>
        </g>
        <g id="inner-side">
          <circle
            cx="150"
            cy="100"
            r="50"
            fill="rgba(0, 0, 0, 1)"
          />
          <font-awesome-icon
            x="125"
            y="75"
            icon="list"
            width="50"
            height="50"
            text-anchor="middle"
          />
        </g>
      </g>
    </svg>
  </div>
</template>

<script>
import { library } from '@fortawesome/fontawesome-svg-core';
import { faList, faCar, faUnlock, faLock } from '@fortawesome/free-solid-svg-icons';
import { mapMutations } from 'vuex';

library.add(faList, faCar, faUnlock, faLock);
export default {
  components: {
  },
  data () {
    return {

      radius: 150,
      centerX: 150,
      centerY: 100,
      angleInDegrees: 0,
      angleInRadians: -this.angleInDegrees * Math.PI / 180.0,
      x: this.centerX + this.radius * Math.cos(this.angleInRadians),
      y: this.centerY + this.radius * Math.sin(this.angleInRadians)

    };
  },
  computed: {
    options () {
      return this.$store.state.game.interactions;
    },
    path () {
      return `M${this.centerX},${this.centerY} l${this.radius},0 A${this.radius},${this.radius} 0 0,0 ${this.x},${this.y} z`;
    },
    slices () {
      return this.options.length;
    }
  },
  watch: {
    options () {
      this.calculate();
      setTimeout(() => this.setRotation(), 500);
    }
  },
  created () {
    this.calculate();
  },
  mounted () {
    this.setRotation();
  },
  methods: {
    ...mapMutations('game', [
      'clearInteractions'
    ]),
    transformString (index) {
      return `rotate(${this.angleInDegrees * index}, ${this.centerX}, ${this.centerY})`;
    },
    iconString (index) {
      return `rotate(${(this.angleInDegrees * index) - (this.angleInDegrees / 2 - 36)}, ${this.centerX}, ${this.centerY})`;
    },
    calculate () {
      this.radius = 180;
      this.centerX = 150; this.centerY = 100;
      this.angleInDegrees = (360 / this.slices);
      this.angleInRadians = -this.angleInDegrees * Math.PI / 180.0;
      this.x = this.centerX + this.radius * Math.cos(this.angleInRadians);
      this.y = this.centerY + this.radius * Math.sin(this.angleInRadians);
    },
    setRotation () {
      const elements = this.$refs['buttons'];
      if (elements) {
        elements.forEach((element, index) => {
          element.children[0].style.transformOrigin = '50% 50%';
          const diff = elements.length <= 4 && index === 0 ? Math.abs((this.angleInDegrees * index) - (this.angleInDegrees / 2 - 36)) : -((this.angleInDegrees * index) - (this.angleInDegrees / 2 - 36));
          element.children[0].setAttribute('style', `transform-origin: 50% 50%; transform: rotate(${diff}deg)!important`);
        });
      }
    },
    handleClick (option) {
      console.log(option);
      this.clearInteractions();
      mp.trigger('handleInteraction', JSON.stringify(option));
    }
  }
};
</script>

<style lang="scss" scoped>
.svg-button {
  transition: 1s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}
#inner-side {
  color: white;
}
#outsider-side {
  color: rgba(white, 0.6);
}
.svg-buttons {
  fill-opacity: 0.3;
  :hover,
  :hover ~ * {
    fill-opacity: 1;
    cursor: pointer;
    color: rgba(255, 255, 255, 1) !important;
  }
}
a {
  pointer-events: none;
}
svg.shown,
svg.shown svg {
  animation: rotate 1s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
}
svg {
  animation: rotate-back 1s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
}
@keyframes rotate {
  0% {
    opacity: 0;
    transform: rotate(0deg) scale(0.2);
  }
  100% {
    opacity: 1;
    transform: rotate(360deg) scale(1);
  }
}
@keyframes rotate-back {
  0% {
    opacity: 1;
    transform: rotate(360deg) scale(1);
  }
  100% {
    opacity: 0;
    transform: rotate(0deg) scale(0.2);
  }
}
</style>
