<template>
  <div
    id="inventory"
    ref="inv"
    class="rounded-sm text-black bg-white sm:min-w-1/3 lg:min-w-1/5"
    :style="{ right: `${posX}px`, top: `${posY}px`}"
  >
    <div
      class="p-2 lg:p-4 flex flex-wrap justify-between cursor-move"
      @mousedown="drag=true; mouseDown($event)"
      @mouseup="drag=false; "
    >
      <h1 class="font-semibold pointer-events-none">
        {{ $t("ui.inventory.yourInventory") }}
      </h1>
    </div>
    <div
      class="sm:p-2 lg:p-4"
      v-show="items.length === 0"
    >
      <p> {{ $t("ui.inventory.empty") }} </p>
    </div>
    <div class="">

      <list :items="items">
        <template
          slot="item"
          class="border-t border-b border-gray-200"
          slot-scope="{ item, index }"
        >
          <div
            class="w-full"
            @contextmenu.prevent="$refs.menu.open($event, { item: item, index })"
          >
            <p class="flex w-full justify-between">{{ item.name }} <span
                class="badge text-xs"
                v-show="item.inUse"
              > {{ $t("ui.inventory.inUse") }}
              </span></p>
            <p class="font-normal text-sm">UID: {{ item.id }}</p>
          </div>
        </template>
      </list>
    </div>
    <vue-context
      class="text-sm"
      ref="menu"
      v-slot="{ data }"
    >
      <template v-if="data">
        <li>
          <a
            href="#"
            @click.prevent="trigger('client:callServer', 'server:player:useItem', data.index)"
          >{{ data.item.inUse ? $t("ui.inventory.unuse") : $t("ui.inventory.use")  }} </a>
        </li>
        <li>
          <a
            href="#"
            @click.prevent="trigger('client:callServer', 'server:player:dropItem', data.index)"
          >{{ $t("ui.inventory.drop") }}</a>
        </li>
        <li class="v-context__sub">
          <a
            href="#"
            @click.prevent="onClick($event.target.innerText)"
            @mouseover="$store.dispatch('game/getNearbyPlayers')"
          >

            {{ $t("ui.inventory.offer") }}</a>
          <ul class="v-context">
            <li
              v-for="(player, index) in nearbyPlayers"
              :key="index"
            >
              <a @click="makeOffer(player, data.item)">{{ player.name }}</a>
            </li>
            <li v-show="nearbyPlayers.length === 0">
              <a> {{ $t("ui.inventory.noPlayers") }}</a>
            </li>
          </ul>
        </li>
      </template>
    </vue-context>
  </div>
</template>

<script>

import List from '@/components/elements/List';
import VueContext from 'vue-context';

export default {
  components: {
    List,
    VueContext
  },
  computed: {
    items () {
      return this.$store.state.character.items;
    },
    nearbyPlayers () {
      return this.$store.state.game.nearbyPlayers || [];
    }
  },
  data () {
    return {
      posX: 100,
      posY: 100,
      drag: false,
      startX: 0,
      startY: 0
    };
  },
  mounted () {
    window.addEventListener('mousemove', this.cb);
  },
  destroyed () {
    window.removeEventListener('mousemove', this.cb);
  },
  methods: {
    trigger (...data) {
      console.log(data);
      mp.trigger(...data);
    },
    mouseDown (me) {
      console.log(me);
      this.startX = me.srcElement.clientWidth - me.offsetX;
      this.startY = me.offsetY;
    },
    makeOffer (player, item) {
      mp.trigger('client:item:toggleInventory', false);
      this.$emit('offer', player, item);
    },
    cb (ev) {
      if (this.drag) {
        this.posX = (window.innerWidth - ev.pageX) - this.startX;
        this.posY = ev.pageY - this.startY;
        console.log(this.posX);
      }
    }
  }
};
</script>

<style lang="scss">
@import "~vue-context/dist/css/vue-context.css";

#inventory {
  position: absolute;
  top: 4rem;
  overflow-x: hidden;
}
.badge {
  color: white;
  @apply p-1;
  text-transform: uppercase;
  background-image: linear-gradient(-135deg, #fcaf17, #f7931e);
}
.v-context,
.v-context ul {
  overflow-y: visible !important;
}
</style>
