
<template>
  <transition
    mode="out-in"
    name="fade"
  >
    <div
      id="container"
      class="flex pt-12 pl-20 font-white text-white h-screen"
      v-show="show"
    >
      <div
        style="min-width: 520px; width:35%;"
        class="flex flex-col"
      >
        <div
          :style="{ background: 'linear-gradient(to right, rgba(0,0,0, 0.8), rgba(0,0, 0, 0.2)), url(' + account.coverPhotoUrl +')' }"
          style="min-height: 160px"
          class="flex w-full shadow-md h-auto player-summarize"
        >
          <div class="w-1/3 p-8 flex justify-center items-center">
            <div
              :style="{ background: 'url(' + account.photoUrl +')' }"
              class="w-24 h-24 rounded-full avatar"
            />
          </div>
          <div class="w-2/3 pt-8 text-xl font-sans">
            <p>
              <span
                v-if="account"
                style="vertical-align: sub"
              > {{ account.name }} </span>
              <span class="uppercase text-xs border-solid patreon border rounded-full ml-4 py-1 px-4">Patron</span>
            </p>
            <div class="mt-6 font-sans flex text-shadow">
              <div class="w-1/3 flex flex-col">
                <p class="text-left w-full">
                  ${{ formatNumber(character.money || 0) }}
                </p>
                <p class="text-left text-sm">
                  GOTÓWKA
                </p>
              </div>
              <div class="w-1/3 flex flex-col">
                <p class="text-left w-full">
                  ${{ formatNumber(character.bank || 0) }}
                </p>
                <p class="text-left text-sm">
                  BANK
                </p>
              </div>
              <div class="w-1/3 flex flex-col">
                <p class="text-left w-full">
                  {{ formatNumber(account.gamescore || 0) }}
                </p>
                <p class="text-left text-sm">
                  GAMESCORE
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="flex flex-col mt-8">
          <p class="ml-10 font-sans text-shadow text-sm">GRACZE ONLINE {{ players.length }}<span class="ml-8">ADMINISTRACJA 0</span></p>
        </div>
        <div class="flex flex-col mt-8">
          <table
            class="font-sans w-full"
            style="overflow-y: scroll;"
          >
            <thead class="flex text-white w-full">
              <tr class="text-xl text-darkest-grey opacity-50 flex w-full">
                <th class="text-sm w-16 py-2">ID</th>
                <th class="text-sm w-3/5 py-2">Nazwa gracza</th>
                <th class="text-sm w-1/5 py-2">Game score</th>
                <th class="text-sm w-1/5 py-2">Ping</th>
              </tr>
            </thead>
            <tbody
              class="flex flex-col w-full items-center overflow-y-auto justify-between"
              style="margin-bottom: 5rem; max-height: 50vh;"
            >
              <tr
                v-for="(player, index) in players"
                :key="index"
                class="spacer-row mt-1 flex h-auto w-full items-center justify-between"
              >
                <td class="w-16 flex items-center text-sm opacity-50">{{ player.id }}</td>
                <td class="flex w-3/5">
                  <div class="flex justify-center items-center">
                    <div
                      :style="`background: url('${player.photoUrl}'); background-size: cover; border: ${getGroupBorder(player.primaryGroup)}`"
                      class="h-12 w-12 rounded-full avatar"
                    />
                  </div>
                  <div class="flex text-lg flex-col  justify-center pl-4">
                    <p class="leading-tight">{{ player.name }}</p>
                    <span class="text-xs text-gray-300">Czas w grze: {{ calculatePlayedTime(player.joinedAt) }}</span>
                  </div>

                </td>
                <td class="flex w-1/5 justify-center">{{ formatNumber(player.gamescore) }}</td>
                <td class="flex w-1/5">{{ player.ping }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
import { mapState } from 'vuex';
import moment from 'moment';
import { setTimeout } from 'timers';

export default {
  data () {
    return {
      interval: null
    };
  },
  computed: {
    ...mapState({ players: state => state.game.playersList, account: state => state.game.account, character: state => state.game.character, show: state => state.hud.scoreboard })

  },
  methods: {
    calculatePlayedTime (joinedAt) {
      moment.locale('pl');
      joinedAt = moment.duration(moment().diff(joinedAt)).asMilliseconds();
      return moment.duration(joinedAt, 'milliseconds').humanize();
    },
    formatNumber (number = 0) {
      let numstring = number.toString();

      if (numstring.length > 3) {
        let thpos = -3;
        let strgnum = numstring.slice(0, numstring.length + thpos);
        let strgspace = (' ' + numstring.slice(thpos));
        numstring = strgnum + strgspace;
      }
      return numstring;
    }
  },
  mounted () {
    setTimeout(() => {
      this.$store.dispatch('game/fetchPlayersList');
    }, 1000);
    this.interval = setInterval(async () => {
      if (this.show) {
        this.$store.dispatch('game/fetchPlayersList');
      }
    }, 5000);
  }

};
</script>

<style lang="scss" scoped>
table {
  border-collapse: collapse;
}
tr {
  > th {
    text-align: left;
    border-bottom: 2px solid rgba(white, 0.1);
    font-weight: 400;
  }
  > th:first-of-type,
  td:first-of-type {
    padding-left: 2rem;
  }
}
tbody {
  tr {
    min-height: 60px;
  }
}
#container {
  background: linear-gradient(
    to right,
    rgba(0, 0, 0, 0.9),
    rgba(255, 255, 255, 0)
  );
}
.player-summarize {
  background-size: cover !important;
  background-position: 50% !important;
}
img {
  object-fit: contain;
}
.avatar {
  background-size: cover !important;
}
.patreon {
  color: #f96854;
  border-color: #f96854;
}
</style>
