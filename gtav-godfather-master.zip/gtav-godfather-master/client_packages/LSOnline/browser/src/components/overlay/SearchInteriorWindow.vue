<template>
  <div
    class="w-1/3 bg-black-trans"
    style="position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%);"
    v-if="searchList"
  >
    <div
      class="p-2 flex"
      style="color: #ccc"
    >
      <div class="flex-shrink-0 flex-grow-1 w-8 bg-input">
        <span class="flex-shrink-0">
          <font-awesome-icon
            class="ml-2"
            icon="search"
          /></span>
      </div>
      <input
        type="text"
        class="w-full bg-input"
        placeholder="Nazwa interioru którego szukasz"
        v-model.trim="queryString"
      >
    </div>
    <div
      class="text-white p-2  overflow-y-auto"
      style="height: 50vh"
    >
      <table class="w-full crossed2">
        <thead>
          <th>ID</th>
          <th>Nazwa</th>
          <th>Interior / IPL</th>
        </thead>
        <tbody style="margin-bottom: 5rem; max-height: 10vh;">
          <tr
            class="h-8"
            v-for="(entry, index) in searchListMatches"
            :key="index"
            @click="handleClick(entry)"
          >
            <td class="text-center">{{ entry.id }}</td>
            <td class="text-center">{{ entry.name }}</td>
            <td class="text-center">{{ entry.interior || entry.ipl }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { library } from '@fortawesome/fontawesome-svg-core';
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import { doorService } from '@/services';

library.add(faSearch);

export default {
  data () {
    return {
      queryString: null
    };
  },
  computed: {
    searchListMatches () {
      if (!this.queryString) return this.searchList;
      return this.searchList.filter(item => item.name.toLowerCase().search(this.queryString.toLowerCase()) !== -1);
    },
    searchList () {
      return this.$store.state.utils.interiors ? this.$store.state.utils.interiors[0] : null;
    }
  },
  watch: {
    searchList (newList, oldList) {
      if (newList == null) return mp.trigger('cursorVisible', false);
      if (typeof newList === 'object') return mp.trigger('cursorVisible', true);
    }
  },
  mounted () {
    window.addEventListener('keyup', this.handleExit);
  },
  destroyed () {
    window.removeEventListener('keyup', this.handleExit);
  },
  methods: {
    handleClick (entry) {
      doorService.createInteriorWithPreset([entry, this.$store.state.utils.interiors[1], this.$store.state.utils.interiors[2]]);
      this.$store.commit('utils/setProperty', ['interiors', null]);
    },
    handleExit (event) {
      if (event.key !== 'Escape') return;
      if (this.searchList === null) return;

      this.$store.commit('utils/setProperty', ['interiors', null]);
    }
  }
};
</script>

<style lang="scss">
.bg-black-trans {
  background-color: rgba(0, 0, 0, 0.8);
}
.bg-input {
  background-color: rgb(35, 35, 35);
}
table.crossed2 tr:nth-child(even) {
  background-color: rgba(black, 0.1);
}
table.crossed2 tr:hover {
  background-color: rgba(black, 0.3);
}
</style>
