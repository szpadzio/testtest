<template>
  <r-modal>
    <template v-slot:header>
      {{ $t("ui.offer.howMuch") + ' ' + data.item.name }}?
    </template>

    <template v-slot:body>
      <input
        ref="input"
        class="p-1 font-medium focus:outline-none"
        type="number"
        min="0"
        v-model="value"
        step="1"
      > </template>
    <template v-slot:footer>
      <r-button
        :black="true"
        @click="accept"
      >{{  $t("ui.accept") }}</r-button>

      <r-button
        :bg="'white'"
        :black="true"
        @click="cancel()"
      >{{  $t("ui.deny") }}</r-button>
    </template>
  </r-modal>
</template>

<script>
import RButton from '@/components/elements/Button.vue';
import RModal from '@/components/elements/Modal.vue';

export default {
  components: {
    RButton,
    RModal
  },
  data () {
    return {
      value: 0
    };
  },
  mounted () {
    this.$refs.input.focus();
  },
  methods: {
    accept () {
      const offer = {
        price: this.value,
        recipient: this.data.player,
        item: this.data.item
      };
      console.log(offer);
      mp.trigger('server:createOffer:item', JSON.stringify(offer));
      mp.trigger('client:item:toggleInventory');
      return this.$emit('offerCanceled');
    },
    cancel () {
      mp.trigger('client:item:toggleInventory');
      return this.$emit('offerCanceled');
    }
  },
  props: {
    data: {
      type: Object,
      required: false,
      default: () => { }
    }
  }
};
</script>

<style>
</style>
