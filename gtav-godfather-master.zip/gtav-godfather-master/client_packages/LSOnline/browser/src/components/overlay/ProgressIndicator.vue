<template>
  <div style="position: absolute;     left: 50%;
    transform: translate(-50%, 50%); height: 100vh;">
    <radial-progress-bar
      :diameter="60"
      :completed-steps="completedSteps"
      :total-steps="totalSteps"
      :strokeWidth="6"
      :animateSpeed="1000"
      innerStrokeColor="rgba(51, 51, 51, 0.5)"
      startColor="#ccc"
      stopColor="#ccc"
      v-if="totalSteps > 0"
    >
    </radial-progress-bar>
  </div>
</template>

<script>
import RadialProgressBar from 'vue-radial-progress';
import { setTimeout } from 'timers';

export default {
  components: {
    RadialProgressBar
  },
  data () {
    return {
      completedSteps: 0,
      timer: null,
      show: false
    };
  },
  watch: {
    totalSteps (newValue, oldValue) {
      this.setTimeout();
    }
  },
  computed: {
    totalSteps () {
      return (this.$store.state.hud.interactionTime - 1000) / 1000;
    }

  },
  methods: {
    clear () {
      this.$store.commit('hud/setProperty', ['interactionTime', 0]);
      this.show = false;
      this.completedSteps = 0;
    },
    setTimeout () {
      this.tiemr = setTimeout(() => {
        this.completedSteps++;
        if (this.completedSteps <= this.totalSteps) {
          return this.setTimeout();
        }
        this.clear();
      }, 1000);
    }
  }
};
</script>

<style>
</style>
