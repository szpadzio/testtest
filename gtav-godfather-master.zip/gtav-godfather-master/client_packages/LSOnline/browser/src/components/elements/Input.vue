<template>
  <div class="input_container font-light">
    <input
      class="w-full placeholder-gray-700 text-black border border-solid border-gray-400 rounded-sm px-4 py-3 outline-none focus:border-orange-400 active:border-4 "
      :id="id"
      :placeholder="placeholder"
      :type="type"
      v-model="data"
      @input="$emit('input', data);"
    >
    <label
      class="text-label"
      :class="[data ? 'active' : '']"
    > {{ label }} </label>

  </div>
</template>

<script>
export default {
  data () {
    return {
      data: ''
    };
  },
  props: {
    id: { type: String, required: true, default: '' },
    value: { type: String, required: false, default: '' },
    label: { type: String, required: false, default: '' },
    icon: { type: String, required: false, default: '' },
    placeholder: { type: String, required: false, default: '' },
    type: { type: String, required: false, default: 'text' }
  }
};
</script>

<style lang="scss">
</style>
