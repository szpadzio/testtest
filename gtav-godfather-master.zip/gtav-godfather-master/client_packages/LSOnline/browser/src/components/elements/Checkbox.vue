<template>
  <div class="input_container">
    <div class="flex items-center font-light">

      <label class="text-black font-normal">
        <input
          class="input_checkbox"
          :checked="checked"
          @change="$emit('change', $event.target.checked);"
          type="checkbox"
        />
        <span>{{ label }}</span>
      </label>
    </div>
  </div>
</template>

<script>
export default {
  model: {
    prop: 'checked',
    event: 'change'
  },
  props: {
    checked: { type: Boolean, required: false, default: false },
    label: { type: String, required: false, default: '' }
  }
};
</script>

<style lang="scss" scoped>
span {
  position: absolute;
  bottom: 0.3rem;
}
</style>
