<template>
  <div class="center bg-white p-4 min-w-1/5">
    <h1 class="font-semibold text-lg">
      <slot name="header"></slot>
    </h1>
    <div class="p-4 flex justify-center">
      <slot name="body"></slot>

    </div>
    <div class="flex justify-between pt-2">
      <slot name="footer"></slot>

    </div>
  </div>
</template>

<script>
export default {

};
</script>

<style>
</style>
