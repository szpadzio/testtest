<template>
  <div
    style="max-height: 40vh; overflow-y: auto;"
    class="border-b border-gray-200"
  >
    <slot v-if="items.length < 1">
    </slot>
    <div
      v-for="(item, index) in items"
      class="p-2 lg:p-4 font-medium border-t transition duration-500 linear flex cursor-pointer border-solid border-l-4 border-r hover-border-rockstar-orange border-gray-200"
      :key="index"
      :class="[ active == index ? 'bg-gray-200' : '']"
    >
      <slot
        name="item"
        v-bind:item="item"
        v-bind:index="index"
      >
      </slot>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    items: { type: Array, required: false, default: () => [] },
    active: { type: Number, required: false, default: -1 }
  },
  computed: {}
};
</script>

<style lang="scss">
</style>
