<template>
  <div
    class=" flex items-center font-light"
    style="transition: 1s linear"
  >
    <button
      class="px-6 shadow py-2 focus:outline-none"
      :type="type"
      @click="$emit('click')"
      style="min-width: 8rem;"
      :class="{'btn-disabled': disabled, 'text-black': black, 'text-white': !black, 'bg-white': bg === 'white', 'bg-rockstar-orange': bg === '' } "
      :disabled="disabled"
    >
      <span v-if="!loading">
        <slot></slot>
      </span>
      <span v-else>
        <font-awesome-icon
          spin
          size="1x"
          icon="spinner"
        />
      </span>
    </button>
  </div>
</template>

<script>
import { library } from '@fortawesome/fontawesome-svg-core';
import { faSpinner } from '@fortawesome/free-solid-svg-icons';

library.add(faSpinner);

export default {
  data () {
    return {
      data: ''
    };
  },
  props: {
    type: { type: String, required: false, default: 'click' },
    label: { type: String, required: false, default: '' },
    disabled: { type: Boolean, required: false, default: false },
    loading: { type: Boolean, required: false, default: false },
    black: { type: Boolean, required: false, default: false },
    bg: { type: String, required: false, default: '' }

  }
};
</script>

<style lang="scss" scoped>
button {
  font-weight: bold;
  outline: none;
  border: none;
  transition: 1s linear;
  padding: 0.5rem 1rem;
  border-color: #fcaf17;
  border-radius: 3px;
  text-shadow: 0 1px 1px rgba(26, 26, 26, 0.2);
}
</style>
