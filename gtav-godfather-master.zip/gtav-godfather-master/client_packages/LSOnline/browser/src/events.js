import store from '@/store';

const events = {
  toggleScoreboard: state => {
    if (state == undefined) state = !store.state.hud.scoreboard;
    store.commit('hud/setProperty', ['scoreboard', state]);
    return true;
  }
};
