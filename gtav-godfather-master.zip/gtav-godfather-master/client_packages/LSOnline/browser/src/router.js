import Vue from 'vue';
import Router from 'vue-router';
import Login from './views/Login.vue';

import proceedToCreator from './middleware/proceedToCreator';

Vue.use(Router);

export default new Router({
  routes: [
    {
      path: '/',
      name: 'home',
      component: null
    },
    {
      path: '/login',
      name: 'login',
      component: Login
    },
    {
      path: '/characters',
      name: 'characters',
      component: () => import(/* webpackChunkName: "SelectCharacter" */ './views/SelectCharacter.vue')
    },
    {
      path: '/creator',
      name: 'creator',
      beforeEnter: proceedToCreator,
      component: () => import(/* webpackChunkName: "CreateCharacter" */ './views/CreateCharacter.vue')
    },
    {
      path: '/overlay',
      name: 'overlay',
      component: () => import(/* webpackChunkName: "Overlay" */ './views/Overlay.vue'),
      children: [
        {
          path: 'job/:job',
          name: 'job-popup',
          component: () => import('./components/overlay/JobPopup.vue')

        }
      ]
    }
  ]
});
