import Vue from 'vue';
import Vuex from 'vuex';
import creator from './modules/creator';
import game from './modules/game';
import utils from './modules/utils';
import player from './modules/player';
import ui from './modules/ui';
import character from './modules/character';

Vue.use(Vuex);

const store = new Vuex.Store({
  modules: {
    creator,
    game,
    utils,
    player,
    ui,
    character
  },
  state: {
  },
  getters: {
  },
  mutations: {
    setData (state, module, { key, value }) {
      state[module][key] = value;
    }
  },
  actions: {}
});

export default store;
