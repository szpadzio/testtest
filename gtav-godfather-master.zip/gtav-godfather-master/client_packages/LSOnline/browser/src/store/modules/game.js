export default {
  namespaced: true,
  state: {
    interactions: [],
    nearbyPlayers: [],
    nearbyItems: []
  },
  mutations: {
    setData (state, { key, data }) {
      state[key] = data;
    },
    setInteractions (state, interactions) {
      state.interactions = interactions;
    },
    setNearbyPlayers (state, players) {
      state.nearbyPlayers = players;
    }
  },
  actions: {
    async getNearbyPlayers (context) {
      const result = await mp.events.callProc('client:getNearbyPlayers');

      context.commit('setNearbyPlayers', JSON.parse(result));
    }
  },
  getters: {
  }

};
