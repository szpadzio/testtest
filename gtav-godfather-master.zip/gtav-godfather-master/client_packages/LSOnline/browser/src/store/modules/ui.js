export default {
  namespaced: true,
  state: {
    inventory: false,
    nearbyItems: false
  },
  mutations: {
    setData (state, { key, data }) {
      state[key] = data;
    }
  },
  actions: {},
  getters: {}
};
