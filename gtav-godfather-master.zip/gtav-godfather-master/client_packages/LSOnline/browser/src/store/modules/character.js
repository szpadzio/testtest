export default {
  namespaced: true,
  state: {
    items: [{ id: 200, name: 'Dupa' }]
  },
  mutations: {
    setData (state, { key, data }) {
      state[key] = data;
    }
  },
  actions: {},
  getters: {}
};
