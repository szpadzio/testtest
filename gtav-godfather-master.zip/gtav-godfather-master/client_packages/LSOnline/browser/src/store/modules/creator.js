export default {
  namespaced: true,
  state: {
    character: {
      model: 'mp_m_freemode_01',
      gender: 'male',
      shapeSecondID: 0,
      shapeFirstID: 0,
      skinSecondID: 0,
      skinFirstID: 0,
      shapeMix: 0.5,
      skinMix: 0.5,
      features: new Array(20).fill(0),
      overlays: new Array(13).fill(-1),
      overlaysOpacity: new Array(13).fill(0),
      overlaysColor1: new Array(13).fill(0),
      overlaysColor2: new Array(13).fill(0),
      hairColor: [0, 0],
      drawables: [0, 0, 0, 15, 14, 0, 5, 0, 40, 0, 0, 105],
      textures: [0, 0, 0, 0, 1, 0, 0, 0, 25, 0, 0, 24],
      eyeColor: 0,
      identify: {
        name: '',
        secondName: '',
        birthday: new Date('12-12-2000'),
        ethinicity: ''
      },
      decorations: [],
      maxDrawables: new Array(12).fill(0),
      maxTextures: new Array(12).fill(0)
    }
  },
  mutations: {},
  actions: {},
  getters: {}
};
