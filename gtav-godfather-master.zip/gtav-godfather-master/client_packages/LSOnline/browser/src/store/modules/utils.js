export default {
  namespaced: true,
  state: {
    interiors: []
  },
  mutations: {
    setProperty (state, [key, data]) {
      state[key] = data;
    }
  },
  actions: {},
  getters: {}
};
