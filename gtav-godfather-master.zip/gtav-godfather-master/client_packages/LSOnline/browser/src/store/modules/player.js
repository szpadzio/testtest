export default {
  namespaced: true,
  state: {
    characters: []
  },
  mutations: {
    setData (state, { key, data }) {
      state[key] = data;
    }
  },
  actions: {},
  getters: {}
};
