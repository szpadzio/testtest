module.exports = {
  root: true,
  env: {
    node: true
  },
  'extends': [
    'plugin:vue/essential',
    '@vue/standard'
  ],
  rules: {
    'no-console': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    'semi': ['error', 'always'],
    'no-unneeded-ternary': 'off',
    'eqeqeq': 'off',
    'no-extra-semi': 'off'
  },
  globals: {
    mp: "readonly"
  },
  parserOptions: {
    parser: 'babel-eslint'
  }
};
