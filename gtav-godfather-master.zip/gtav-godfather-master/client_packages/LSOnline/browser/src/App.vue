<template>
  <div id="app">
    <transition
      name="fade"
      mode="out-in"
    >
      <router-view />
    </transition>
  </div>
</template>

<script>
import '@@/styles/main.scss';

export default {
  components: {},
  data () {
    return {};
  }
};
</script>

<style lang="scss">
@import url("https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap");

/* shared across components */
html,
body {
  user-select: none;
  background: transparent;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}

@tailwind base;

@tailwind components;

@tailwind utilities;
</style>
