if (process.env.NODE_ENV === 'development' && typeof mp === 'undefined') {
  // eslint-disable-next-line
  mp = {
    trigger (...args) {
      console.info('mp.trigger has been called');
      console.table(args);
    },
    events: {
      callProc (...args) {
        console.info('mp.events.callProc has been called');
        console.table(args);
      },
      call (...args) {
        console.info('mp.events.callProc has been called');
        console.table(args);
      }
    }
  };
}
