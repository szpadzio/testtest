
exports.init = () => {
  mp.discord.update('Tworzy postać', `@ ${rp.globals.serverName}`);
  mp.game.streaming.requestIpl('Motel');
  mp.players.local.position = new mp.Vector3(152, -1001.4180297851562, -98.99999237060547);
  mp.players.local.setHeading(180);
  mp.players.local.freezePosition(true);
  mp.players.local.dimension = Math.floor(Math.random() * 999999) + 9999;
  mp.players.local.clearTasksImmediately();
  mp.players.local.model = mp.game.joaat('mp_m_freemode_01');
};

exports.getPlayerNaked = () => {
  mp.players.local.setComponentVariation(6, 5, 0, 0);
  mp.players.local.setComponentVariation(4, 14, 1, 0);
  mp.players.local.setComponentVariation(11, 105, 24, 0);
  mp.players.local.setComponentVariation(3, 15, 0, 0);
  mp.players.local.setComponentVariation(8, 40, 25, 0);
};

exports.getVariations = () => {
  let drawables = [];
  let textures = [];
  for (let i = 0; i <= 11; i++) {
    drawables.push(mp.players.local.getNumberOfDrawableVariations(i) - 1);
    const temp = [];

    for (let j = 0; j <= drawables[i]; j++) {
      temp.push(mp.players.local.getNumberOfTextureVariations(i, j) - 1);
    }
    textures.push(temp);
  }

  return { drawables, textures };
};
exports.rotatePed = () => {
  mp.game.controls.disableAllControlActions(2);
  if (rp.globals.creatorRotate) {
    let input = mp.game.controls.getDisabledControlNormal(1, 1) * 20;
    let heading = mp.players.local.getHeading();
    mp.game.ui.setCursorSprite(6);
    mp.players.local.setHeading(heading + input);
  }
};
