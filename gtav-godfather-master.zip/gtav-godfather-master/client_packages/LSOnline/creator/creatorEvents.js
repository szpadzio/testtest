'use strict';

const { init, getPlayerNaked, rotatePed, getVariations } = require('/LSOnline/creator/creator');
// const rpc = require('/rage-rpc');

let cameras = {
  head: mp.cameras.new('Head', new mp.Vector3(152, -1002.2, -98.4), new mp.Vector3(0, 0, 0), 60),
  torso: mp.cameras.new('Torso', new mp.Vector3(152, -1002.6, -98.7), new mp.Vector3(0, 0, 0), 60),
  legs: mp.cameras.new('Legs', new mp.Vector3(152, -1002.6, -99.5), new mp.Vector3(0, 0, 0), 60)
};
var currentCamera;

mp.events.add({
  initializeCreator: () => {
    init();
    rp.globals.creator = true;

    cameras.start = mp.cameras.new('start', new mp.Vector3(152.5, -1003.2, -99), new mp.Vector3(0, 0, 20), 60);
    cameras.start.setActive(true);
    mp.game.cam.renderScriptCams(true, true, 2000, false, false);
    currentCamera = cameras.start;
    getPlayerNaked();
    mp.events.add('render', rotatePed);
    return true;
  },
  updatePed: (data) => {
    data = JSON.parse(data);
    mp.players.local.clearDecorations();
    mp.players.local.setHeadBlendData(data.shapeFirstID, data.shapeSecondID, 0, data.skinFirstID, data.skinSecondID, 0, data.shapeMix, data.skinMix, 0, false);
    mp.players.local.setEyeColor(data.eyeColor);
    data.overlays.forEach((element, index) => {
      if (element > -1) {
        let opacity;
        opacity = data.overlaysOpacity[index];
        mp.players.local.setHeadOverlay(index, element, opacity, data.overlaysColor1[index], data.overlaysColor2[index]);
      } else {
        mp.players.local.setHeadOverlay(index, 255, 0, 0, 0);
      }
    });
    data.features.forEach((element, index) => {
      mp.players.local.setFaceFeature(index, element);
    });
    data.drawables.forEach((element, index) => {
      if (index > 0) mp.players.local.setComponentVariation(index, element, data.textures[index], 0);
    });
    data.decorations.forEach((element, index) => {
      mp.players.local.setDecoration(mp.game.gameplay.getHashKey(element.collection), mp.game.gameplay.getHashKey(element.overlay));
    });
    mp.players.local.setHairColor(data.hairColor[0], data.hairColor[1]);
  },
  switchCamera: (data) => {
    if (currentCamera !== cameras[data]) {
      cameras[data].setActiveWithInterp(currentCamera.handle, 2000, 1, 1);
      currentCamera = cameras[data];
    }
  },
  characterCreated: (data) => {
    mp.events.callRemote('characterCreated', data);
  },
  click: (x, y, upOrDown, leftOrRight, relativeX, relativeY, worldPosition, hitEntity) => {
    if (leftOrRight === 'right' && rp.globals.creator) {
      if (upOrDown === 'down') rp.globals.creatorRotate = true;
      if (upOrDown === 'up') rp.globals.creatorRotate = false;
    }
  },
  destroyCreation: () => {
    rp.globals.creator = false;
    mp.events.remove('render', rotatePed);
    mp.game.cam.renderScriptCams(false, false, 0, true, false);
    Object.keys(cameras).forEach((key) => {
      cameras[key].destroy();
    });
  },
  setOutfit (data) {
    data = JSON.parse(data);
    const model = data.model;
    const outfit = JSON.parse(data.outfit);

    mp.players.local.model = mp.game.joaat(model);

    mp.players.local.clearDecorations();
    mp.players.local.setHeadBlendData(outfit.parents['0'].shape, outfit.parents['1'].shape, 0, outfit.parents['0'].skin, outfit.parents['1'].skin, 0, outfit.mix.shape, outfit.mix.skin, 0, false);
    mp.players.local.setEyeColor(outfit.body.eyeColor);
    for (let i = 0; i < 13; i++) {
      const cloth = outfit.clothes[i];
      if (outfit.face) {
        const headOverlay = outfit.face.overlays[i];

        if (headOverlay) mp.players.local.setHeadOverlay(i, headOverlay.index, headOverlay.opacity, headOverlay.firstColor, headOverlay.secondColor);
      }

      if (cloth) mp.players.local.setComponentVariation(i, cloth.id, cloth.textureId, 0);
    }
    outfit.face.features.forEach((element, index) => {
      mp.players.local.setFaceFeature(index, element);
    });

    outfit.decorations.forEach((element, index) => {
      mp.players.local.setDecoration(mp.game.gameplay.getHashKey(element.collection), mp.game.gameplay.getHashKey(element.overlay));
    });
    mp.players.local.setHairColor(outfit.body.hairColor, outfit.body.highlightColor);
  }
});
/*
rpc.register('changeGender', (model, info) => {
  mp.players.local.model = mp.game.joaat(model);
  getPlayerNaked();
  return getVariations();
});
rpc.register('getVariations', (args, info) => {
  return getVariations();
});
*/
