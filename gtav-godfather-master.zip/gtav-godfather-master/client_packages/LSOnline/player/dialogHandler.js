
mp.events.add({
  handleDialog: (decision, dialog) => {
    const parsedDialog = JSON.parse(dialog);
    switch (parsedDialog.type) {
      case 'offer':
        mp.events.callRemote(`${decision}Offer`, parsedDialog.hash);

        break;
    }
  }
});
