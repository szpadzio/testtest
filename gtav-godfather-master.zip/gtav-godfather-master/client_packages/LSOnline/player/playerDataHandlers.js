const Cash = require('./LSOnline/cash/cash');

const player = mp.players.local;
mp.events.addDataHandler({
  money: (entity, value) => {
    if (entity.type == 'player' && entity.handle === mp.players.local.handle) {
      Cash.drawMoney(entity, value);
      entity.cash = value;
    }
  },
  description: (entity, value) => {
    if (entity.type == 'player') {
      entity.description = value;
    }
  },
  spawned: (entity, value) => {
    if (entity.type == 'player' && entity.remoteId === player.remoteId) {
      entity.spawned = value;
    }
  },
  'dl': (entity, value) => {
    if (entity.handle === player.handle) {
      entity.dl = value;
    }
  }
});
