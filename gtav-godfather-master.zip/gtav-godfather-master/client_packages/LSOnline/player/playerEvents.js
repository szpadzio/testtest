'use strict';

const Overlay = require('./LSOnline/util/overlay');
const { sendHelpMessage, hideRadar, setPlayerConfigFlag } = require('./LSOnline/util/misc');
const natives = require('./LSOnline/util/natives');

const player = mp.players.local;

mp.events.add({
  entityStreamIn: player => {
    if (player.type !== 'player') {
      return false;
    }

    if (typeof player.getVariable('description') !== 'undefined') {
      const description = player.getVariable('description');
      player.description = description;
    }
  },

  playerDeath: (player, reason, killer) => {
    mp.game.audio.playSoundFrontend(-1, 'Bed', 'WastedSounds', true);
    mp.game.graphics.startScreenEffect('DeathFailNeutralIn', 0, true);
    mp.game.gameplay.setFadeOutAfterDeath(false);
  },

  playerSetSeatBelts: player => {
    if (!rp.globals.vehicleBeltsStatus) {
      rp.globals.vehicleBeltsStatus = true;
      setPlayerConfigFlag(player, 32, true);
    } else {
      rp.globals.vehicleBeltsStatus = false;
      setPlayerConfigFlag(player, 32, false);
    }
  },
  playerSpawn: () => mp.game.graphics.stopScreenEffect('DeathFailNeutralIn'),
  updateDiscord: (status, state = `@ ${rp.globals.serverName}`) => mp.discord.update(status, state),
  setInvincible: (value) => value ? mp.players.local.setInvincible(true) : mp.players.local.setInvincible(false),
  toggleFreeze: (value) => mp.players.local.freezePosition(Boolean(value)),
  openPanel: (side, panel) => Overlay.setPanel(side, panel),
  setUrl: (routeName, routeParams) => Overlay.push(routeName, routeParams),
  showHelpMessage: (value) => sendHelpMessage(value),
  hideRadar: (bool) => hideRadar(bool),
  runCommand: (command, ...args) => mp.events.callRemote('runCommand', command, ...args),
  loadIpl: (ipl) => {
    if (mp.game.streaming.isIplActive(ipl)) return true;
    mp.game.streaming.requestIpl(ipl);
    mp.players.local.freezePosition(true);
    const timer = setInterval(() => {
      const state = mp.game.invoke(rp.natives.IS_PLAYER_SWITCH_IN_PROGRESS);

      if (mp.game.streaming.isIplActive(ipl) && !state) {
        mp.players.local.freezePosition(false);
        clearInterval(timer);
      }
    }, 500);
  },
  unloadIpl: ipl => {
    mp.game.streaming.removeIpl(ipl);
  },
  playAudio: (sound, set) => {
    mp.game.audio.playSoundFrontend(-1, sound, set, true);
  },
  teleportVehicleToPos: (x, y, z) => {
    mp.players.local.vehicle.setOnGroundProperly();
    mp.players.local.vehicle.setInvincible(true);
    setTimeout(() => {
      mp.players.local.vehicle.setInvincible(false);
    }, 3000);
  },
  actionAboveHead: (entity, text) => {
    entity.actionAboveHead = `~h~* ${entity.name} ${text}`;

    if (entity.actionAboveHeadTimer) clearTimeout(entity.actionAboveHeadTimer);

    entity.actionAboveHeadTimer = setTimeout(() => {
      entity.actionAboveHead = null;
    }, 5000);
  },
  drugUsed: (effect, duration) => {
    duration = duration * 1000 * 60;
    mp.game.graphics.startScreenEffect(effect + 'In', 2000, false);
    mp.players.local.drugTimeout = setTimeout(() => {
      mp.game.graphics.stopScreenEffect(effect + 'In');
      mp.game.graphics.startScreenEffect(effect, duration, false);
      setTimeout(() => {
        mp.game.graphics.stopScreenEffect(effect);
      }, duration);
    }, 2000);
  }
});
