'use strict';

const player = mp.players.local;
const Sprite = require('./LSOnline/util/spriteManager');
const { openInteraction } = require('./LSOnline/game/interaction');
const { vectorDistance, wordWrap, pointingAt, disableControlActions } = require('./LSOnline/util/misc');
const { IS_PLAYER_SWITCH_IN_PROGRESS } = require('./LSOnline/util/natives');

// Main render for players
mp.events.add('render', (nametags) => {
  if (!mp.game.invoke(IS_PLAYER_SWITCH_IN_PROGRESS) || !player.spawned) {
    mp.players.forEachInStreamRange(
      (player2) => {
        if (!mp.players.local.spawned) return;
        if (player2 !== player && player2.dimension === player.dimension && vectorDistance(player.position, player2.position) < 15) {
          const playerName = `${player2.name} (${player2.remoteId})`;

          mp.game.graphics.drawText(playerName, [player2.position.x, player2.position.y, player2.position.z + 1],
            {
              font: 0,
              color: [255, 255, 255, 255],
              scale: [0.3, 0.3],
              outline: true
            });

          if (player2.description != null) {
            mp.game.graphics.drawText(wordWrap(player2.description, 25), [player2.position.x, player2.position.y, player2.position.z + 0.2],
              {
                font: 0,
                color: [255, 255, 255, 200],
                scale: [0.3, 0.3],
                outline: true
              }
            );
          }

          if (player2.actionAboveHead) {
            mp.game.graphics.drawText(wordWrap(player2.actionAboveHead, 50), [player2.position.x, player2.position.y, player2.position.z + 1.2],
              {
                font: 0,
                color: [151, 125, 169, 255],
                scale: [0.3, 0.3],
                outline: false
              }
            );
          }
        }
      });
  }

  if (rp.globals.interactionKey && !mp.game.player.isFreeAiming()) {
    disableControlActions([24, 257]);
    let sprite = ['shared', 'emptydot_32'];
    const result = pointingAt(5);

    if (result && (result.entity.type === 'vehicle' || result.entity.type === 'player' || result.entity.type === 'object') && !result.entity.cooldown && result.entity.handle !== mp.players.local.handle) {
      sprite = ['pilotschool', 'medaldot_32'];
      if (mp.game.controls.isDisabledControlJustPressed(2, 24)) { openInteraction(result); }
    }

    /* eslint-disable */
    new Sprite(sprite[0], sprite[1], 0.5, 0.5, 0.01, 0.02, 255, 255, 255, 200);
    /* eslint-enable */
  }

  if (!rp.globals.hudHidden) {
    Object.keys(player.textDraws).forEach(key => {
      let text = player.textDraws[key];
      mp.game.graphics.drawText(text.name, text.position, text.options);
    });
  }
});
