mp.events.add({
  cutTree: (id) => {
    const tree = mp.objects.at(id);
    tree.cooldown = true;

    tree.setRotation(270, 0, 0, 2, true);
    mp.attachmentMngr.addLocal('carrying:wood');
    mp.game.player.setRunSprintMultiplierFor(0.0);

    mp.gui.chat.push('!{yellow}> Tartak: Zanieś ścięte drzewo do tartaku! (marker)');
  }
});
