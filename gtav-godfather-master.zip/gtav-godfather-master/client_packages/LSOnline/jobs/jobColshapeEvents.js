mp.events.add({
  playerEnterColshape: entity => {
    if (mp.players.local.getVariable('job')) return;
    const job = entity.getVariable('job');
    if (job) mp.events.call('setUrl', 'job-popup', { job });
  }
});
