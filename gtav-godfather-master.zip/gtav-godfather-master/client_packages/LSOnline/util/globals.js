
// eslint-disable-next-line
exports = {
  serverName: 'luźne-rp.XD',
  interactionKey: false,
  hudHidden: false,
  vehicleCruiseControl: false,
  allowVehicleCruiseControl: true,
  vehicleBeltsStatus: false
};
