'use strict';

let interval = null;

/**
 * Natives list.
 */
const natives = {
  SET_TEXT_OUTLINE: '0x2513dfb0fb8400fe'
};

/**
 * Prepare client view before player join game.
 */
const prepareClientView = () => {
  // Disable vehicle rewards
  mp.game.player.disableVehicleRewards();

  // Disable radar.
  mp.game.ui.displayRadar(false);

  // Disable nametags
  mp.nametags.enabled = false;

  mp.game.vehicle.defaultEngineBehaviour = false;

  // Update discord.
  mp.events.call('updateDiscord', 'W grze');

  // Initialize textDraws object
  mp.players.local.textDraws = {};

  // Prepare most used dicts
  ['shared', 'pilotschool'].forEach(dict => {
    if (!mp.game.graphics.hasStreamedTextureDictLoaded(dict)) {
      mp.game.graphics.requestStreamedTextureDict(dict, true);
    }
  });

  // Initialize chat
  // mp.gui.execute('window.location = "package://LSOnline/browser/dist/chat.html"');
};

exports.prepareClientView = prepareClientView;

/**
 * Hide HUD elements.
 *
 * @param {array} array Array of elements.
 */
const hideHudElements = array => {
  for (let element of array) {
    mp.game.ui.hideHudComponentThisFrame(element);
  }
};

exports.hideHudElements = hideHudElements;

/**
 * Disable control actions.
 * Warning: This only works on inputGroup 0 (INPUTGROUP_MOVE).
 *
 * @param {array} array Array of controls.
 */
const disableControlActions = array => {
  for (let control of array) {
    mp.game.controls.disableControlAction(0, control, true);
  }
};

exports.disableControlActions = disableControlActions;

/**
 * Enable control actions.
 * Warning: This only works on inputGroup 0 (INPUTGROUP_MOVE).
 *
 * @param {array} array Array of controls.
 */
const enableControlActions = array => {
  for (let control of array) {
    mp.game.controls.enableControlAction(0, control, true);
  }
};

exports.enableControlActions = enableControlActions;

const draw3dText = (text, drawXY, font, color, scale, alignRight = false) => {
  mp.game.ui.setTextEntry('STRING');
  mp.game.ui.addTextComponentSubstringPlayerName(text);
  mp.game.ui.setTextFont(font);
  mp.game.ui.setTextScale(scale, scale);
  mp.game.ui.setTextColour(color[0], color[1], color[2], color[3]);
  mp.game.invoke(natives.SET_TEXT_OUTLINE);

  if (alignRight) {
    mp.game.ui.setTextRightJustify(true);
    mp.game.ui.setTextWrap(0, drawXY[0]);
  }

  mp.game.ui.drawText(drawXY[0], drawXY[1]);
};

exports.draw3dText = draw3dText;

// Credits: https://github.com/glitchdetector/fivem-minimap-anchor
const getMinimapAnchor = () => {
  let sfX = 1.0 / 20.0;
  let sfY = 1.0 / 20.0;
  let safeZone = mp.game.graphics.getSafeZoneSize();
  let aspectRatio = mp.game.graphics.getScreenAspectRatio(false);
  let resolution = mp.game.graphics.getScreenActiveResolution(0, 0);
  let scaleX = 1.0 / resolution.x;
  let scaleY = 1.0 / resolution.y;

  let minimap = {
    width: scaleX * (resolution.x / (4 * aspectRatio)),
    height: scaleY * (resolution.y / 5.674),
    scaleX: scaleX,
    scaleY: scaleY,
    leftX: scaleX * (resolution.x * (sfX * (Math.abs(safeZone - 1.0) * 10))),
    bottomY: 1.0 - scaleY * (resolution.y * (sfY * (Math.abs(safeZone - 1.0) * 10)))
  };

  minimap.rightX = minimap.leftX + minimap.width;
  minimap.topY = minimap.bottomY - minimap.height;
  return minimap;
};

exports.getMinimapAnchor = getMinimapAnchor;

/**
 * Credits to @ramiong - thanks man
 *
 * @param {string} text Text.
 * @param {integer} charactersLimit Characters limit.
 */
const wordWrap = (text, charactersLimit) => {
  const regex = '.{1,' + charactersLimit + '}(\\s|$)' + '|\\S+?(\\s|$)';
  return text.match(RegExp(regex, 'g')).join('\n');
};

exports.wordWrap = wordWrap;

// Credits to YARP author
const vectorDistance = (vector1, vector2) => {
  let dx = vector1.x - vector2.x;
  let dy = vector1.y - vector2.y;
  let dz = vector1.z - vector2.z;

  return Math.sqrt(dx * dx + dy * dy + dz * dz);
};

exports.vectorDistance = vectorDistance;

/**
 * Send help message.
 *
 * @param {string} value Message.
 */
const sendHelpMessage = value => {
  mp.game.ui.setTextComponentFormat('STRING');
  mp.game.ui.addTextComponentSubstringPlayerName(value);
  mp.game.ui.displayHelpTextFromStringLabel(0, false, true, -1);
};

exports.sendHelpMessage = sendHelpMessage;

/**
 * Load clip set.
 *
 * @param {string} clipSetName Clip set name.
 */
const loadClipSet = clipSetName => {
  mp.game.streaming.requestClipSet(clipSetName);
  while (!mp.game.streaming.hasClipSetLoaded(clipSetName)) mp.game.wait(0);
};

exports.loadClipSet = loadClipSet;

function pointingAt (distance) {
  const distanceToCheck = distance * 2;
  const camera = mp.cameras.new('gameplay');
  const player = mp.players.local.position;

  let position = camera.getCoord();
  let direction = camera.getDirection();
  let farAway = new mp.Vector3((direction.x * distanceToCheck) + (position.x), (direction.y * distanceToCheck) + (position.y), (direction.z * distanceToCheck) + (position.z));
  let result = mp.raycasting.testPointToPoint(position, farAway, mp.players.local.handle, [2, 4, 8, 16]);

  if (result && mp.game.system.vdist2(player.x, player.y, player.z, result.position.x, result.position.y, result.position.z) > distance) {
    return false;
  }

  return result;
}

exports.pointingAt = pointingAt;

/**
 * Hide HUD.
 *
 * @param {boolean} boolean Status.
 */
const hideHud = boolean => {
  rp.globals.hudHidden = boolean;
};

exports.hideHud = hideHud;

/**
 * Hide radar.
 *
 * @param {boolean} boolean Status.
 */
const hideRadar = boolean => {
  mp.game.ui.displayRadar(!boolean);
};

exports.hideRadar = hideRadar;

/**
 * Set player config flag.
 *
 * @param {object} player Player object.
 * @param {integer} flag Flag.
 * @param {boolean} boolean Status.
 */
const setPlayerConfigFlag = (player, flag, boolean) => {
  player.setConfigFlag(flag, !boolean);
};

exports.setPlayerConfigFlag = setPlayerConfigFlag;

/**
 * Show peds.
 */
const showPeds = () => {
  interval = setInterval(() => {
    mp.game.ped.setPedDensityMultiplierThisFrame(3);
    mp.game.streaming.setPedPopulationBudget(3);
    mp.game.streaming.setVehiclePopulationBudget(3);
  }, 2000);
};

exports.showPeds = showPeds;

/**
 * Disable peds.
 */
const disablePeds = () => {
  clearInterval(interval);
  mp.game.ped.setPedDensityMultiplierThisFrame(0);
  mp.game.streaming.setPedPopulationBudget(0);
  mp.game.streaming.setVehiclePopulationBudget(0);
};

exports.disablePeds = disablePeds;
