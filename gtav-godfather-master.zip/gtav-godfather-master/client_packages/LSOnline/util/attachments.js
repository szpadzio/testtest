// LumberMill
mp.attachmentMngr.register('job:lumbering', 'prop_tool_fireaxe', 28422, new mp.Vector3(0.03, -0.15, -0.20), new mp.Vector3(41, 0, 180));
mp.attachmentMngr.register('carrying:wood', 'prop_rub_planks_04', 28422, new mp.Vector3(0.03, -0.15, -0.20), new mp.Vector3(41, 0, 180));
