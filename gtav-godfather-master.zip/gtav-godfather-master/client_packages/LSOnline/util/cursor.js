const { isAnyCEFVisible } = require('LSOnline/util/cef');

function toggleCursor (state = null, force = false) {
  mp.gui.chat.push(`${isAnyCEFVisible()}`);
  if (isAnyCEFVisible() && !force && mp.gui.cursor.visible) return;

  if (!state) state = !mp.gui.cursor.visible;

  mp.gui.cursor.show(state, state);
}
exports.toggleCursor = toggleCursor;

mp.events.add('client:cursor:chatClosed', () => {
  if (isAnyCEFVisible()) {
    mp.gui.cursor.show(true, true);
  }
});
