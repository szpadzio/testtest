'use strict';

var instance;

/**
 * Class to handle an Overlay browser.
 * It meant to be singleton. (dunno if good solution)
 * @class Overlay
 */
class Overlay {
  /**
   * Create an overlay
   * @memberof Overlay
   */
  constructor () {
    if (instance) {
      return instance;
    }
    instance = this;
    this.browser = mp.browsers.new(
      'package://LSOnline/browser/dist/index.html'
    );
  }

  /**
   *
   * Manage pages
   * @param {string} routeName - name of  the route name in config
   * @memberof Overlay
   * @throws Error
   */
  push (routeName, params = {}) {
    if (!routeName) throw new Error('Path can not be empty');
    params = JSON.stringify(params);
    this.browser.execute(`vm.$router.push({ name: "${routeName}", params: ${params} })`);
  }

  /**
   *
   * Go n steps further or back in history
   * @param {number} [n=0]
   * @memberof Overlay
   */
  go (n = 0) {
    this.browser.execute(`vm.$router.go(${n})`);
  }

  /**
   * Inject code inside browser.
   */
  inject (code) {
    this.browser ? this.browser.execute(code) : mp.gui.chat.push(`There was a problem with injecting code inside ${this.browser}.`);
  };

  setStorage (moduleName, key, data) {
    const payload = JSON.stringify({ key, data });

    this.inject(`vm.$store.commit('${moduleName}', JSON.parse('${payload}'))`);
  }

  triggerEvent (ev, data) {
    this.inject(`window.rageEvents['${ev}'](${data})`);
  }
}

exports = new Overlay();
