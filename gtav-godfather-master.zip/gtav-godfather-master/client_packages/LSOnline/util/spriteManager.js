class SpriteManager {
  constructor (dict, sprite, screenX, screenY, scaleX, scaleY, r, g, b, a) {
    this.dict = dict;
    this.sprite = sprite;
    this.screenX = screenX;
    this.screenY = screenY;
    this.scaleX = scaleX;
    this.scaleY = scaleY;
    this.r = r;
    this.g = g;
    this.b = b;
    this.a = a;
    this.loadDict(this.dict);
    this.createSprite();
  }

  createSprite () {
    mp.game.graphics.drawSprite(this.dict, this.sprite, this.screenX, this.screenY, this.scaleX, this.scaleY, 0, this.r, this.g, this.b, this.a);
  }

  loadDict (dict) {
    if (!mp.game.graphics.hasStreamedTextureDictLoaded(dict)) {
      mp.game.graphics.requestStreamedTextureDict(dict, true);
    }
  }
}

exports = SpriteManager;
