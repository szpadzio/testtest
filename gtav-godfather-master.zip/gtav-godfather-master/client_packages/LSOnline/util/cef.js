exports.isAnyCEFVisible = () => {
  return rp.inventoryVisible || rp.nearbyItemsVisible;
};
