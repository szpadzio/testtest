const DrawText = require('./LSOnline/util/drawText');

mp.events.add({
  dutyToggle: (tag, color) => {
    if (DrawText.getText('duty')) return DrawText.destroyText('duty');
    DrawText.drawText('duty', tag, 'MINIMAP', {
      font: 4,
      color: [...color, 185],
      scale: [0.75, 0.75],
      outline: true,
      centre: true
    });
  },

  handleInvite: (data) => {
    mp.events.callRemote('handleInvite', data);
  },

  radioChatter: (entity, time) => {
    setTimeout(() => {
      mp.game.audio.playSoundFromEntity(-1, 'Radio_On', entity.handle, 'TAXI_SOUNDS', true, 0);
      setTimeout(() => mp.game.audio.playSoundFromEntity(-1, 'Radio_Off', entity.handle, 'TAXI_SOUNDS', true, 0),
        1000 + time);
    }, 1000);
  }
})
;
