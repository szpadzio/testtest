'use strict';

const player = mp.players.local;
const misc = require('./LSOnline/util/misc');

// Main render for vehicles
mp.events.add('render', () => {
  const vehicle = mp.players.local.vehicle;

  mp.vehicles.forEachInStreamRange(
    (_vehicle) => {
      if (misc.vectorDistance(player.position, _vehicle.position) < 8) {
        if (_vehicle.description != null && !player.dl) {
          mp.game.graphics.drawText(misc.wordWrap(_vehicle.description, 40), [_vehicle.position.x, _vehicle.position.y, _vehicle.position.z + 0.2],
            {
              font: 0,
              color: [255, 255, 255, 200],
              scale: [0.3, 0.3],
              outline: true
            }
          );
        }

        if (player.dl) {
          mp.game.graphics.drawText(`GameID: ${_vehicle.remoteId}\nDbID:${_vehicle['DbID'] || null}\nPos: ${_vehicle.position.x.toFixed(2)}, ${_vehicle.position.y.toFixed(2)}, ${_vehicle.position.z.toFixed(2)} (${_vehicle.dimension})\nEH:${_vehicle.getEngineHealth().toFixed(2)}\nModel: ${mp.game.vehicle.getDisplayNameFromVehicleModel(_vehicle.getModel())}\nW: ${_vehicle.windows}\nR: ${_vehicle.roof}`, [_vehicle.position.x, _vehicle.position.y, _vehicle.position.z + 0.5],
            {
              font: 4,
              color: [50, 131, 200, 200],
              scale: [0.3, 0.3],
              outline: true
            }
          );
        }
      }
    });

  if (vehicle) {
    if (vehicle.policeRadar) {
      const vehicleInFrontOf = misc.drawRaycastForPoliceRadar(vehicle);

      if (vehicleInFrontOf) {
        if (vehicleInFrontOf.entity.isAVehicle() && vehicleInFrontOf.entity !== vehicle) {
          const vehicleInFrontOfModel = mp.game.vehicle.getDisplayNameFromVehicleModel(vehicleInFrontOf.entity.model);
          const vehicleInFrontOfPlate = vehicleInFrontOf.entity.getNumberPlateText();
          const vehicleInFrontOfSpeed = vehicleInFrontOf.entity.getSpeed() * 2.236936;

          // Only for test purposes.
          mp.gui.chat.push(`Model: ${vehicleInFrontOfModel} Tablica: ${vehicleInFrontOfPlate} Prędkość: ${vehicleInFrontOfSpeed} km/h`);
        }
      }
    }

    // Simple cruise control.
    if (rp.globals.allowVehicleCruiseControl) {
      let vehicleCurrentSpeed = vehicle.getSpeed();
      let vehicleMaxSpeed = mp.game.vehicle.getVehicleModelMaxSpeed(vehicle.model);

      // B key.
      if (mp.game.controls.isControlJustReleased(0, 29)) {
        if (!rp.globals.vehicleCruiseControl) {
          rp.globals.vehicleCruiseControl = true;
          vehicle.setMaxSpeed(vehicleCurrentSpeed);
        } else {
          rp.globals.vehicleCruiseControl = false;
          vehicle.setMaxSpeed(vehicleMaxSpeed);
        }
      }
    }

    // Disable ability to exit vehicle when player have belts.
    if (rp.globals.vehicleBeltsStatus) {
      misc.disableControlActions([75, 79]);
    }
  }
});
