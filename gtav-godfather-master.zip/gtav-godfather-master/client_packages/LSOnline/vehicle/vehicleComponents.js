'use strict';

/**
 * Sync vehicle radio to all players inside vehicle.
 *
 * @param {object} vehicle Vehicle object.
 */
const syncVehicleRadio = (vehicle) => {
  if (vehicle) {
    let nowPlaying = mp.game.invoke(rp.natives.GET_PLAYER_RADIO_STATION_INDEX);

    // Check if radio is not disabled.
    if (nowPlaying !== 255) {
      mp.game.invoke(rp.natives.SET_FRONTEND_RADIO_ACTIVE);
      mp.game.invoke(rp.natives.SET_RADIO_TO_STATION_INDEX, nowPlaying);
    }
  }
};

exports.syncVehicleRadio = syncVehicleRadio;
