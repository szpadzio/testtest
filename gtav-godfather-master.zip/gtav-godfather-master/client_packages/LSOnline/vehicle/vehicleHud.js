'use strict';

// Misc.
const { draw3dText } = require('./LSOnline/util/misc');
const { IS_PLAYER_SWITCH_IN_PROGRESS } = require('./LSOnline/util/natives');

// Update interval value. Milliseconds, lower value = more accurate, at the cost of performance
const updateInterval = 500;

// Minimap, speedo config.
let streetName = null;
let zoneName = null;
let isMetric = false;

// Screen positions for HUD.
const hudOnScreenPositionX = 0.165;
const hudOnScreenPositionY = 0.860;

// Heading directions.
const headingDirections = ['N', 'NW', 'W', 'SW', 'S', 'SE', 'E', 'NE', 'N'];

// Interval to refresh current player position.
setInterval(() => {
  const position = mp.players.local.position;
  let getStreet = mp.game.pathfind.getStreetNameAtCoord(position.x, position.y, position.z, 0, 0);

  isMetric = mp.game.gameplay.getProfileSetting(227) === 1;

  zoneName = mp.game.ui.getLabelText(mp.game.zone.getNameOfZone(position.x, position.y, position.z));
  streetName = mp.game.ui.getStreetNameFromHashKey(getStreet.streetName);

  if (getStreet.crossingRoad && getStreet.crossingRoad !== getStreet.streetName) {
    streetName += ` / ${mp.game.ui.getStreetNameFromHashKey(getStreet.crossingRoad)}`;
  }
}, updateInterval);

// Show HUD only in vehicle.
mp.events.add(
  {
    render: () => {
      const player = mp.players.local;
      const vehicle = mp.players.local.vehicle;

      if (vehicle && !mp.game.invoke(IS_PLAYER_SWITCH_IN_PROGRESS)) {
        let vehicleSpeed = (vehicle.getSpeed() * (isMetric ? 3.6 : 2.236936)).toFixed(0);
        let vehicleSpeedPositionX = (vehicleSpeed > 100) ? 0.0230 : 0.020;
        draw3dText(vehicleSpeed, [hudOnScreenPositionX + 0.000, hudOnScreenPositionY + 0.00], 4, [255, 255, 255, 255], 0.80, false);
        draw3dText(`${(isMetric) ? 'KM/H' : 'MPH'}`, [hudOnScreenPositionX + vehicleSpeedPositionX, hudOnScreenPositionY + 0.018], 4, [255, 255, 255, 255], 0.40, false);

        // Fuel status.
        let vehicleFuel = player.vehicle.getVariable('fuel');
        let vehicleFuelPositionX = (vehicleFuel > 100) ? 0.0725 : 0.070;
        draw3dText(vehicleFuel, [hudOnScreenPositionX + 0.050, hudOnScreenPositionY + 0.000], 4, [255, 255, 255, 255], 0.80, false);
        draw3dText(`PALIWO`, [hudOnScreenPositionX + vehicleFuelPositionX, hudOnScreenPositionY + 0.018], 4, [255, 255, 255, 255], 0.40, false);

        // Time in-game.
        let currentTime = new Date();
        let formattedCurrentHours = (currentTime.getHours() < 10) ? ('0' + currentTime.getHours()).substr(-2) : currentTime.getHours();
        let formattedCurrentMinutes = (currentTime.getMinutes() < 10) ? ('0' + currentTime.getMinutes()).substr(-2) : currentTime.getMinutes();
        draw3dText(formattedCurrentHours + ':' + formattedCurrentMinutes, [hudOnScreenPositionX + 0.000, hudOnScreenPositionY + 0.050], 4, [255, 255, 255, 255], 0.50, false);

        // Engine status.
        let engineStatusColor = vehicle.getIsEngineRunning() ? [50, 205, 50, 255] : [220, 20, 60, 255];
        draw3dText(`SILNIK`, [hudOnScreenPositionX + 0.030, hudOnScreenPositionY + 0.050], 4, engineStatusColor, 0.50, false);

        // Windows status.
        let windowStatusColor = player.vehicle.getVariable('windows') ? [220, 20, 60, 255] : [50, 205, 50, 255];
        draw3dText(`SZYBA`, [hudOnScreenPositionX + 0.065, hudOnScreenPositionY + 0.050], 4, windowStatusColor, 0.50, false);

        // Cruise control status.
        let cruiseControlStatusColor = (rp.globals.vehicleCruiseControl) ? [50, 205, 50, 255] : [220, 20, 60, 255];
        draw3dText((rp.globals.vehicleCruiseControl) ? 'TEMPOMAT' : 'TEMPOMAT', [hudOnScreenPositionX + 0.100, hudOnScreenPositionY + 0.050], 4, cruiseControlStatusColor, 0.50, false);

        // Belts status.
        let beltsStatusColor = (rp.globals.vehicleBeltsStatus) ? [50, 205, 50, 255] : [220, 20, 60, 255];
        draw3dText(`PASY`, [hudOnScreenPositionX + 0.155, hudOnScreenPositionY + 0.050], 4, beltsStatusColor, 0.50, false);

        // Heading, street name and zone name.
        if (streetName && zoneName) {
          let playerHeading = headingDirections[[Math.floor((player.getHeading() + 22.5) / 45.0)]];
          draw3dText(playerHeading + ' | ' + streetName + ' | ' + zoneName, [hudOnScreenPositionX, hudOnScreenPositionY + 0.085], 4, [255, 255, 255, 255], 0.50);
        }
      }
    }
  }
);
