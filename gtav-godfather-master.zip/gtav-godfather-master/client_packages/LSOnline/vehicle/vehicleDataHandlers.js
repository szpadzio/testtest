mp.events.addDataHandler({
  description: (entity, value) => {
    if (entity.type == 'vehicle') {
      entity.description = value;
    }
  },

  policeRadar: (entity, value) => {
    if (entity.type == 'vehicle') {
      entity.policeRadar = value;
    }
  },

  windows: (entity, value) => {
    if (entity.type == 'vehicle') {
      entity.windows = value;
      value ? [0, 1, 2, 3].forEach(i => entity.rollUpWindow(i)) : entity.rollDownWindows();
    }
  },

  roof: (entity, value) => {
    if (entity.type == 'vehicle') {
      entity.roof = value;
      value ? entity.raiseConvertibleRoof(false) : entity.lowerConvertibleRoof(false);
    }
  },

  engineHealth: (entity, value) => {
    if (entity.type == 'vehicle') {
      entity.setEngineHealth(value);
      entity.engineHealth = value;
      mp.vehicles.at(0).getEngin;
    }
  },

  dirtLevel: (entity, value) => {
    if (entity.type == 'vehicle') {
      entity.setDirtLevel(entity.getVariable('dirtLevel') > 15.0 ? 15.00 : entity.getVariable('dirtLevel'));
    }
  },
  'DbID': (entity, value) => {
    entity['DbID'] = value;
  }
});
