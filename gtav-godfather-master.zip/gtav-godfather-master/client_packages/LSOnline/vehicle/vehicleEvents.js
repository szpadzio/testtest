'use strict';

const { syncVehicleRadio } = require('./LSOnline/vehicle/vehicleComponents');

mp.events.add({
  playerEnterVehicle: (vehicle, seat) => {
    const engineStatus = vehicle.engine ? true : false;
    if (seat === 0) {
      vehicle.distance = 0;
      setTimeout(() => {
        vehicle.timer = setInterval(() => {
          if (!mp.players.local.vehicle) {
            clearInterval(vehicle.timer);
            return;
          }
          vehicle.distance += (vehicle.getSpeed() * 0.5);
        }, 500);
      }, 2000);
    }

    // Set some variables.
    vehicle.setEngineOn(engineStatus, false, true);
    vehicle.setUndriveable(engineStatus);
    vehicle.getVariable('windows') ? [0, 1, 2, 3].forEach(i => vehicle.rollUpWindow(i)) : vehicle.rollDownWindows();
    vehicle.getVariable('roof') ? vehicle.raiseConvertibleRoof(true) : vehicle.lowerConvertibleRoof(true);
    vehicle.setEngineHealth(vehicle.getVariable('engineHealth'));

    // Sync vehicle radio for player.
    syncVehicleRadio(vehicle);
  },

  playerLeaveVehicle: () => {
    const vehicle = mp.vehicles.atHandle(mp.players.local.getVehicleIsIn(true));

    if (vehicle.distance && vehicle.distance > 0 && vehicle.timer) {
      mp.events.callRemote('updateMileage', vehicle.remoteId, vehicle.distance);
      clearInterval(vehicle.timer);
      vehicle.distance = 0;
    }

    // Disable vehicle cruise control.
    rp.globals.vehicleCruiseControl = false;

    // Hide radar for player.
  },

  entityStreamIn: vehicle => {
    if (vehicle.type !== 'vehicle') {
      return false;
    }

    if (typeof vehicle.getVariable('description') !== 'undefined') {
      const description = vehicle.getVariable('description');
      vehicle.description = description;
    }

    vehicle.getVariable('windows') ? [0, 1, 2, 3].forEach(i => vehicle.rollUpWindow(i)) : vehicle.rollDownWindows();
    vehicle.getVariable('roof') ? vehicle.raiseConvertibleRoof(true) : vehicle.lowerConvertibleRoof(true);
    vehicle.setDirtLevel(vehicle.getVariable('dirtLevel') > 15.0 ? 15.00 : vehicle.getVariable('dirtLevel'));

    vehicle.setEngineHealth(vehicle.getVariable('engineHealth'));
  },

  setDoorsLockedInSpecialVehicle: vehicle => {
    vehicle.setDoorsLocked(4); // They can get in, but can't leave - this is for police cars.
    vehicle.setDoorsShut(true);
  },

  setDoorsLocked: vehicle => {
    vehicle.setDoorsLocked(2);
  },

  unlockDoors: vehicle => {
    vehicle.setDoorsLocked(1);
  },

  lowerVehicleRoof: vehicle => {
    let getVehicleRoofStatus = vehicle.getConvertibleRoofState();

    if (getVehicleRoofStatus === 0) {
      vehicle.lowerConvertibleRoof(false);
    }
  },

  raiseVehicleRoof: vehicle => {
    let getVehicleRoofStatus = vehicle.getConvertibleRoofState();

    if (getVehicleRoofStatus === 2) {
      vehicle.raiseConvertibleRoof(false);
    }
  },

  lockSound: (vehicle, status) => {
    mp.game.audio.setAudioFlag('LoadMPData', true);
    let sound = null;
    status
      ? sound = 'Remote_Control_Open'
      : sound = 'Remote_Control_Close';

    mp.game.audio.playSoundFromEntity(-1, sound, vehicle.handle, 'PI_Menu_Sounds', true, 0);
  },

  locateVehicle: (vehicle) => {
    mp.game.ui.setNewWaypoint(vehicle.position.x, vehicle.position.y);
  }
});
