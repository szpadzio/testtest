const rpc = require('./rage-rpc');

rpc.register('getVehicleDisplayName', (model) => {
  return mp.game.ui.getLabelText(mp.game.vehicle.getDisplayNameFromVehicleModel(mp.game.joaat(model)));
});
