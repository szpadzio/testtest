const Overlay = require('/LSOnline/util/overlay.js');
const Interaction = require('/LSOnline/game/interactionFactory.js');

exports.openInteraction = (raycast) => {
  mp.gui.chat.push(raycast.job);
  if (raycast.job) handleJob(raycast);
  if (!raycast.entity) return false;
  const entity = raycast.entity;

  if (entity.type === 'vehicle') {
    mp.events.call('cursorVisible', true);

    Overlay.setInteractions([
      Interaction('car'),
      Interaction(raycast.entity.locked ? 'unlock' : 'lock', entity)
    ]);
  }
  if (entity.type === 'object' && entity.getVariable('item')) {
    mp.events.callRemote('server:item:pickupItem', JSON.stringify({ id: entity.remoteId, type: 'ground' }));
  }
};

exports.handleInteractionWithVehicle = (interactionObject) => {
  if (!mp.vehicles.exists(interactionObject.entity.id) && !mp.vehicles.atRemoteId(interactionObject.entity.remoteId)) {
    return false;
  }
  const entity = mp.vehicles.at(interactionObject.entity.id);
  if (entity.getVariable('DbID') !== interactionObject.entity.DbID) {
    return false;
  }
  if (mp.game.system.vdist2(mp.players.local.position.x, mp.players.local.position.y, mp.players.local.position.z, entity.position.x, entity.position.y, entity.position.z) > 8) {
    mp.events.call('actionDone', 'Pojazd jest za daleko.');
    return false;
  }

  switch (interactionObject.action) {
    case 'unlock':
    case 'lock': {
      mp.events.callRemote('runCommand', 'v z', interactionObject.entity.remoteId);
      break;
    }
  }
};

const handleJob = (entity) => {
  mp.events.callRemote('jobInteraction', entity.type, entity.id);
};
