exports = (action, raycast, icon = null) => {
  return Object.freeze({
    action,
    icon,
    entity: raycast ? {
      type: raycast.type,
      id: raycast.id,
      remoteId: raycast.remoteId,
      DbID: raycast.getVariable('DbID')
    } : {}
  });
};
