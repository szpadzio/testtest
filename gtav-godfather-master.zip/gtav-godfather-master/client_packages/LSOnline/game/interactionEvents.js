const { handleInteractionWithVehicle } = require('/LSOnline/game/interaction');

mp.events.add('handleInteraction', (option) => {
  option = JSON.parse(option);
  mp.events.call('cursorVisible', false);
  mp.gui.cursor.visible = false;

  if (!option.entity) return false;

  switch (option.entity.type) {
    case 'vehicle': {
      handleInteractionWithVehicle(option);
    }
  }
});
