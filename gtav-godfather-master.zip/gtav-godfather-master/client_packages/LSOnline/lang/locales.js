exports.messages = {
  en: {
    ui: {
      inventory: {
        yourInventory: 'Inventory',
        inUse: 'In use',
        use: 'Use',
        unuse: 'Unuse',
        drop: 'Drop',
        offer: 'Offer',
        empty: 'You have no items.',
        noPlayers: 'No players nearby',
        weapon: 'Weapon',
        drug: 'Drug',
        noNearbyItems: 'No items nearby.',
        nearbyItems: 'Items near you'
      },
      offer: {
        howMuch: 'For how much do you want offer the'
      },
      accept: 'Accept',
      deny: 'Deny'
    },
    login: {
      welcome: 'Welcome to the Furry Roleplay!',
      username: 'Username',
      password: 'Password',
      signin: 'Sign in',
      remember: 'Remember login',
      lostpassword: 'Forgotten password?',
      error: {
        '1000': 'Something has gone wrong. Try again.',
        '1101': 'The account corresponding to the entered combination of e-mail address and password does not exist. Try again.'
      },
      selector: {
        chooseCharacter: 'Choose your character',
        createCharacter: 'Create a new character',
        timePlayed: 'In-game time',
        joinGame: 'Join the game'
      }
    }
  },
  pl: {
    ui: {
      inventory: {
        yourInventory: 'Inventory',
        inUse: 'W użyciu',
        use: 'Użyj',
        unuse: 'Odłóż',
        drop: 'Wyrzuć',
        offer: 'Oferuj',
        empty: 'Nie posiadasz żadnych przedmiotów.',
        noPlayers: 'Brak graczy w pobliżu',
        weapon: 'Weapon',
        drug: 'Drug'
      },
      offer: {
        howMuch: 'For how much do you want offer the'
      },
      accept: 'Accept',
      deny: 'Deny'
    },
    login: {
      welcome: 'Witaj na Furry Roleplay!',
      username: 'Nazwa użytkownika',
      password: 'Hasło',
      signin: 'Zaloguj się',
      remember: 'Zapamiętaj nazwę użytkownika',
      lostpassword: 'Zapomniałeś hasła?',
      error: {
        '1000': 'Coś poszło nie tak. Spróbuj ponownie.',
        '1101': 'Konto odpowiadające wprowadzonej kombinacji adresu e-mail i hasła nie istnieje. Spróbuj ponownie.'
      },
      selector: {
        chooseCharacter: 'Wybierz postać',
        createCharacter: 'Stwórz postać',
        timePlayed: 'Przegrany czas',
        joinGame: 'Wejdź do gry'
      }
    }
  }
};
