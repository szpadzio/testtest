const player = mp.players.local;

mp.events.addDataHandler({
  item: (entity, value) => {
    if (entity.type !== 'object') return;
    entity.item = value;
    mp.events.call('client:item:itemDropped', entity.id);
  }
});
