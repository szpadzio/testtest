const items = [];
const itemsInWorld = [];

let nearbyItems = [];
let inventoryVisible = false;
let nearbyItemsVisible = false;

exports.items = items;
exports.itemsInWorld = itemsInWorld;

exports.nearbyItems = nearbyItems;
exports.inventoryVisible = inventoryVisible;
exports.nearbyItemsVisible = nearbyItemsVisible;
