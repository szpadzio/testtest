const { itemsInWorld } = require('LSOnline/item/itemStorage');
const player = mp.players.local;

mp.events.add('render', () => {
  if (!player.transitionFinished) return;
  let object;
  itemsInWorld.forEach(_item => {
    mp.gui.chat.push(_item);
    object = mp.objects.at(_item);
    if (!mp.objects.exists(object) || !object.item) return;

    if (mp.game.system.vdist(object.position.x, object.position.y, object.position.z, player.position.x, player.position.y, player.position.z) > 2) return;
    mp.game.graphics.drawText(object.item.name, [object.position.x, object.position.y, object.position.z + 0.2],
      {
        font: 0,
        color: [255, 255, 255, 200],
        scale: [0.3, 0.3],
        outline: true
      });
  });
});
