mp.events.add('entityStreamIn', (entity) => {
  mp.gui.chat.push(entity.type);
  if (entity.type !== 'object' || entity.item) return;

  const item = entity.getVariable('item');
  if (item) entity.item = item;

  mp.events.call('client:item:itemDropped', entity.id);
});
