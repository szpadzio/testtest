const Overlay = require('./LSOnline/util/overlay');
const { toggleCursor } = require('./LSOnline/util/cursor');

let { nearbyItems } = require('LSOnline/item/itemStorage');
const { items, itemsInWorld } = require('LSOnline/item/itemStorage');

rp.ui.inventoryVisible = false;
rp.ui.nearbyItemsVisible = false;

mp.events.add({
  'client:playerReadyAndSpawned': () => {
    mp.gui.chat.push('spawn');
    mp.objects.forEach(object => {
      const item = object.getVariable('item');
      mp.gui.chat.push(`${object.id} ${item}`);
      if (item) {
        object.item = item;
        mp.events.call('client:item:itemDropped', object.id);
      }
    });
  },
  'client:item:toggleInventory': (cursor = true) => {
    mp.gui.chat.push(`${mp.objects.toArray().length}`);
    rp.ui.inventoryVisible = !rp.ui.inventoryVisible;
    if (cursor) toggleCursor();
    Overlay.inject(`vm.$store.state.ui.inventory = ${rp.ui.inventoryVisible}`);
  },
  'client:item:toggleNearbyItems': (cursor = true) => {
    mp.gui.chat.push(`e ${1}`);
    rp.ui.nearbyItemsVisible = !rp.ui.nearbyItemsVisible;
    if (cursor) mp.gui.cursor.visible = rp.ui.nearbyItemsVisible;
    Overlay.inject(`vm.$store.state.ui.nearbyItems = ${rp.ui.nearbyItemsVisible}`);
  },
  'client:item:populateInventory': (data) => {
    items.push(...data);
    setItems();
  },
  'client:item:itemDropped': (objectLocalId) => {
    mp.gui.chat.push(objectLocalId);
    itemsInWorld.push(objectLocalId);
  },
  'client:item:searchForNearbyItems': () => {
    nearbyItems = [];

    itemsInWorld.forEach(_id => {
      mp.gui.chat.push(`${_id}`);
      const object = mp.objects.at(_id);
      if (!mp.objects.exists(object) || object.dimension !== mp.players.local.dimension) return;
      if (!object.item) return;
      if (mp.game.system.vdist(object.position.x, object.position.y, object.position.z, mp.players.local.position.x, mp.players.local.position.y, mp.players.local.position.z) > 3) return;

      nearbyItems.push({ entityId: object.remoteId, ...object.item, world: 'ground' });
    });

    mp.events.call('client:item:toggleNearbyItems');
    setNearbyItems();
  },
  'client:item:updateItem': (item, index = -1) => {
    if (index == -1) {
      index = items.findIndex((_item) => {
        return _item.id === item.id;
      });
    }

    if (index !== -1) {
      items[index] = item;
      setItems();
    }
  },
  'client:item:destroyItemInWorld': (remoteId) => {
    const object = mp.objects.atRemoteId(remoteId);

    if (!mp.objects.exists(object)) return;

    const index = itemsInWorld.findIndex((_item) => _item === object.id);
    if (index) itemsInWorld.splice(index, 1);
  },
  'client:item:pushItem': (item) => {
    items.push(item);
    setItems();
  },
  'client:item:popItem': (item, index = -1) => {
    if (index == -1) {
      index = items.findIndex((_item) => {
        return _item.id === item.id;
      });
    }

    if (index !== -1) {
      items.splice(index, 1);
      setItems();
    }
  }
});

mp.events.add({
  'server:item:pickupItem': (item) => {
    mp.events.callRemote('server:item:pickupItem', item);
  }
});

function setItems () {
  Overlay.setStorage('character/setData', 'items', items);
}

function setNearbyItems () {
  Overlay.setStorage('game/setData', 'nearbyItems', nearbyItems);
}
