'use strict';

mp.keys.bind(0x49, false, () => {
  if (!mp.players.local.spawned || mp.gui.chat.typing) return false;
  mp.events.call('client:item:toggleInventory');
});
