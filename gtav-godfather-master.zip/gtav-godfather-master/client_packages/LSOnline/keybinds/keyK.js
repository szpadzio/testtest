'use strict';

mp.keys.bind(0x4B, false, () => {
  mp.events.callRemote('');
});
