'use strict';

mp.keys.bind(0x2E, false, () => {
  if (!mp.gui.cursor.visible) {
    mp.events.callRemote('keyDeleteButton');
  }
});
