'use strict';
mp.keys.bind(0x73, false, () => {
  if (!mp.players.local.spawned) return;

  mp.gui.cursor.visible = !mp.gui.cursor.visible;
});
