'use strict';
const Overlay = require('/LSOnline/util/overlay');

mp.keys.bind(0x1B, false, () => {
  if (!mp.players.local.spawned) return;

  Overlay.push('overlay');
});
