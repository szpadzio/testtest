'use strict';

mp.keys.bind(0x58, true, () => {
  if (!mp.players.local.spawned) return false;
  rp.globals.interactionKey = true;
});

mp.keys.bind(0x58, false, () => {
  rp.globals.interactionKey = false;
});
