let chat = {
  size: 0,
  container: null,
  input: null,
  enabled: true,
  active: true,
  text: '',
  history: []
};

function enableChatInput (enable) {
  if (chat.active == false &&
        enable == true) { return; }

  if (enable != (chat.input != null)) {
    mp.invoke('focus', enable);
    mp.invoke('setTypingInChatState', enable);
    mp.trigger('client:chatInputEnabled', enable);

    if (enable) {
      chat.input = $('#chat').append('<div><input spellcheck="false" id="chat_msg" type="text" /></div>').children(':last');
      chat.input.children('input').focus();
      chat.input.children('input').val(chat.text);
    } else {
      chat.input.fadeOut('fast', function () {
        chat.text = chat.input.children('input').val();
        chat.input.remove();
        chat.input = null;
      });
    }
  }
}

var chatAPI = {
  push: (text) => {
    chat.container.prepend('<li>' + text + '</li>');

    chat.size++;
    if (chat.size >= 50) {
      chat.container.children(':last').remove();
    }
  },

  clear: () => {
    chat.container.html('');
  },

  activate: (toggle) => {
    if (toggle == false &&
            (chat.input != null)) { enableChatInput(false); }
    chat.active = toggle;
  },

  show: (toggle) => {
    if (toggle == false &&
            (chat.input != null)) { enableChatInput(false); }

    if (toggle) {
      $('#chat').show();
    } else {
      $('#chat').hide();
    }

    chat.active = toggle;
  }
};

if (mp.events) {
  let api = {
    'chat:push': chatAPI.push,
    'chat:clear': chatAPI.clear,
    'chat:activate': chatAPI.activate,
    'chat:show': chatAPI.show
  };

  for (let fn in api) {
    mp.events.add(fn, api[fn]);
  }
}

$(document).ready(function () {
  chat.container = $('#chat ul#chat_messages');
  let index = -1;
  $('.ui_element').show();

  $('body').keydown(function (event) {
    if (event.which == 84 && chat.input == null &&
            chat.active == true) {
      enableChatInput(true);
      event.preventDefault();
    } else if (event.which == 13 && chat.input != null) {
      let value = chat.input.children('input').val();

      if (value.length > 0) {
        if (value[0] == '/') {
          const cmd = value.substr(1);

          if (cmd.length > 0) {
            mp.invoke('command', cmd);
            chat.history.unshift(cmd); index = -1;
          }
        } else {
          mp.invoke('chatMessage', value);
          chat.history.unshift(value); index = -1;
        }
        if (chat.history.length > 50) { chat.history.pop(); }
      }

      chat.input.children('input').val('');
      enableChatInput(false);
      mp.trigger('client:cursor:chatClosed');
    } else if (event.key === 'ArrowUp' && chat.input && chat.input.children('input').is(':focus')) {
      if (index + 1 < 50 && index + 1 < chat.history.length) { index++; }

      chat.input.children('input').val(chat.history[index]);
    } else if (event.key === 'ArrowDown' && chat.input && chat.input.children('input').is(':focus')) {
      index--;
      if (index < 0) {
        chat.input.children('input').val('');
        index = -1;
      } else {
        chat.input.children('input').val(chat.history[index]);
      }
    } else if (event.key === 'PageUp' && chat.container) {
      chat.container[0].scrollBy(0, 100);
    } else if (event.key === 'PageDown' && chat.container) {
      chat.container[0].scrollBy(0, -100);
    }
  });
});
