require('./scaleform_messages/index.js');
require('./static-attachments/index.js');

// Globals
rp = {};
rp.ui = {};
rp.globals = require('./LSOnline/util/globals');
rp.natives = require('./LSOnline/util/natives');
rp.timers = {};

// Authorization
require('./LSOnline/login/login');

// CEF
require('./LSOnline/api/browser');
require('./LSOnline/browser/events/browserEvents');

// Environment
require('./LSOnline/environment/time');

// Doors
require('./LSOnline/doors/doorEvents');
require('./LSOnline/doors/doorDataHandlers');

// Items
require('./LSOnline/item/itemStorage');
require('./LSOnline/item/itemDataHandlers');
require('./LSOnline/item/itemRender');
require('./LSOnline/item/itemEvents');

// Player
require('./LSOnline/player/playerEvents');
require('./LSOnline/player/dialogHandler');
require('./LSOnline/player/playerRender');
require('./LSOnline/player/playerDataHandlers');
require('./LSOnline/game/interactionEvents');

// Jobs
require('./LSOnline/jobs/jobColshapeEvents');
require('./LSOnline/jobs/lumberMillEvents');

// Vehicles
require('./LSOnline/vehicle/vehicleRender');
require('./LSOnline/vehicle/vehicleEvents');
require('./LSOnline/vehicle/vehicleDataHandlers');
require('./LSOnline/vehicle/vehicleHud');

// Keybinds
require('./LSOnline/keybinds/keyX');
require('./LSOnline/keybinds/keyZ');
require('./LSOnline/keybinds/keyY');
require('./LSOnline/keybinds/keyK');
require('./LSOnline/keybinds/keyE');
require('./LSOnline/keybinds/keyI');
require('./LSOnline/keybinds/keyF2');
require('./LSOnline/keybinds/keyF4');
require('./LSOnline/keybinds/keyDelete');
require('./LSOnline/keybinds/keyArrowUp');
require('./LSOnline/keybinds/keyArrowDown');

// Creator
require('./LSOnline/creator/creatorEvents');

// Groups
require('./LSOnline/group/groupEvents');

// Customs
require('./LSOnline/util/attachments');

// events
require('./LSOnline/events/player');
require('./LSOnline/events/ui');
require('./LSOnline/events/utils');
require('./LSOnline/events/chat');
require('./LSOnline/events/storage');
require('./LSOnline/events/rpc/auth');
require('./LSOnline/events/rpc/offer');

// misc
require('./LSOnline/util/cef');
require('./LSOnline/util/cursor');

let misc = require('./LSOnline/util/misc');

mp.events.add({
  clientLaunched: () => misc.prepareClientView(),
  render: () => {
    mp.game.player.setHealthRechargeMultiplier(0.0);
    misc.hideHudElements([3, 4, 7, 9]);
  }
});

// Initialize chat
mp.gui.execute('window.location = "package://chat/index.html"');

mp.events.call('clientLaunched');
