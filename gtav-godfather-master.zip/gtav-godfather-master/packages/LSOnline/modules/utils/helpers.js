'use strict';
const axios = require('axios');
// const parsers = require('playlist-parser');

const upperString = string =>
  string.toLowerCase().replace(/(^| )(\w)/g, s => s.toUpperCase());
exports.upperString = upperString;

const randomInt = (min, max) =>
  Math.floor(Math.random() * (max - min + 1) + min);

exports.randomInt = randomInt;

const searchPlayerByIdOrName = searchPlayer => {
  if (!searchPlayer) return false;

  let thisPlayer = null;
  if (!isNaN(searchPlayer)) {
    const playerId = parseInt(searchPlayer);
    if (mp.players.exists(playerId)) thisPlayer = mp.players.at(playerId);
  } else {
    thisPlayer = mp.players
      .toArray()
      .find(_player =>
        _player.name.toLowerCase().match(searchPlayer.toLowerCase())
      );
  }
  if (thisPlayer == null || (!thisPlayer.isLogged || !thisPlayer.character)) {
    return false;
  }
  return thisPlayer;
};

exports.searchPlayerByIdOrName = searchPlayerByIdOrName;

const validateText = text => {
  if (!text) return false;
  text = text.trim();
  if (text.length === 0) return false;
  if (text.match(new RegExp(`[^a-ząćśńółęĄĆŚŃÓŁĘA-Z0-9ds!?$% '".:{}]/`, 'g'))) {
    return false;
  }
  if (text.length > 160) return false;
  return text;
};

exports.validateText = validateText;

const findPlayerInText = fullText => {
  if (fullText.search('{') >= 0) {
    const id = fullText.substring(
      fullText.lastIndexOf('{') + 1,
      fullText.lastIndexOf('}')
    );

    if (!id || isNaN(id)) {
      return false;
    }

    const target = mp.players.at(id);
    if (!target) return false;

    return target;
  }
  return true;
};

exports.findPlayerInText = findPlayerInText;

const parseOutfit = (outfit, name = 'default') => {
  const parsedOutfit = {};

  parsedOutfit.name = name;
  parsedOutfit.model = outfit.model;
  parsedOutfit.gender = outfit.gender;

  parsedOutfit.parents = {
    0: {
      shape: outfit.shapeFirstID,
      skin: outfit.skinFirstID
    },
    1: {
      shape: outfit.shapeSecondID,
      skin: outfit.skinSecondID
    }
  };

  parsedOutfit.mix = {
    shape: outfit.shapeMix,
    skin: outfit.skinMix
  };

  parsedOutfit.body = {
    hairColor: outfit.hairColor[0],
    highlightColor: outfit.hairColor[1],
    eyeColor: outfit.eyeColor
  };

  parsedOutfit.face = {
    features: outfit.features,
    overlays: outfit.overlays.map((_o, index) => { return { index: _o, opacity: outfit.overlaysOpacity[index], firstColor: outfit.overlaysColor1[index], secondColor: outfit.overlaysColor2[index] }; })
  };

  parsedOutfit.clothes = outfit.drawables.map((_d, index) => { return { id: _d, textureId: outfit.textures[index] }; });

  parsedOutfit.decorations = outfit.decorations;

  return parsedOutfit;
};

exports.parseOutfit = parseOutfit;

const randomLicensePlate = () => {
  return `${randomInt(
    1,
    9
  )}${randomChar()}${randomChar()}${randomChar()}${randomInt(0, 9)}${randomInt(
    0,
    9
  )}${randomInt(0, 9)}${randomInt(0, 9)}`.toUpperCase();
};

exports.getRandomLicensePlate = randomLicensePlate;

const randomChar = () => {
  return String.fromCharCode(Math.floor(Math.random() * 26) + 97);
};
exports.randomChar = randomChar;

exports.generateUniqueIdentifier = () => {
  return (
    '_' +
    Math.random()
      .toString(36)
      .substr(2, 9)
  );
};

const fetchAudioStream = url => {
  return axios.get(url, { responseType: 'text' })
    .then(r => r.data)
    .then(data => {
      return data.search('playlist') > -1 ? parsers.PLS.parse(data) : parsers.M3U.parse(data);
    });
};

exports.fetchAudioStream = fetchAudioStream;
