// Get logger
const log4js = require('log4js');

// Configuration logger
log4js.configure({
  appenders: {
    file: { type: 'file', layout: { type: 'basic' }, filename: `logs/server.log` },
    console: { type: 'console' }
  },
  categories: { default: { appenders: ['file', 'console'], level: 'info' } }
});

// Get logger instance and export
const loggerInstance = log4js.getLogger('LSRPV');
module.exports = (moduleName, msg, type = 'error') => {
  if (msg instanceof Error) {
    msg = `${msg.message} (${msg.code})`;
  }
  loggerInstance[type](`[${moduleName}] ${msg}`);
};
