'use strict';

const logger = require('../utils/logger');
const ForumClient = require('../../api/ForumClient');
const createAccount = require('./accountFactory');
/**
 * Find account by name and save data into player entity.
 */
exports.loadAccountData = (player, accountName, accountId) => {
  player.isLogged = true;

  try {
    // const result = await ForumClient.getUserInfo(accountId);
    player.account = createAccount({ id: 1 });

    logger('auth', 'Account data saved into player entity.', 'info');
    return player;
  } catch (err) {
    return logger('auth', err, 'error');
  }
};
