module.exports = function (data) {
  return {
    member_id: data.id,
    ...data
  };
};
