const { assign } = require('../../doors/doorManager');

exports.execute = async (player, offer, sender) => {
  const door = mp.markers.at(offer.entity.id);
  if (!door || door.informations.id !== offer.entity.databaseId) return player.call('actionDone', ['Coś poszło nie tak.']);
  const result = await assign(door.informations.id, 'character', player.character.info.id, door.id);

  if (result) {
    player.setVariable('money', player.data.money - Math.abs(offer.price));
    player.setVariable('offer', null);
    door.frozen = false;
    rp.logger.emit('offer:realized', offer.entity.type, player, sender, offer.entity, offer.price, offer.hash);

    return player.call('actionDone', ['Zaakceptowałeś ofertę.']);
  }
};
