const { transferVehicleToPlayer } = require('../../vehicles/vehicleService');

exports.execute = async (player, offer) => {
  const vehicle = mp.vehicles.at(offer.entity.id);
  if (!vehicle || vehicle.informations.id !== offer.entity.databaseId) {
    return player.call('actionDone', ['Nie możesz zaakceptować oferty.', 'Coś poszło nie tak.']);
  }

  const sender = mp.players.at(offer.sender.id) === offer.sender.name ? mp.players.at(offer.sender.id) : false;
  const result = await transferVehicleToPlayer(player, vehicle, sender);

  if (result) {
    player.setVariable('money', player.data.money - Math.abs(offer.price));
    player.setVariable('offer', null);

    vehicle.frozen = false;
    rp.logger.emit('offer:realized', offer.entity.type, player, sender, offer.entity, offer.price, offer.hash);

    return player.call('actionDone', ['Zaakceptowałeś ofertę.']);
  }
};
