
exports.execute = async (player, offer, sender) => {
  const item = sender.character.inventory._items.find(item => item.id === offer.entity.databaseId);

  if (!item) return player.call('actionDone', ['Coś poszło nie tak.']);

  const result = sender.character.inventory.transferToPlayer(player, item);

  if (result) {
    player.setVariable('money', player.data.money - Math.abs(offer.price));
    player.setVariable('offer', null);
    rp.logger.emit('offer:realized', offer.entity.type, player, sender, offer.entity, offer.price, offer.hash);

    return player.call('actionDone', ['Zaakceptowałeś ofertę.']);
  }
};
