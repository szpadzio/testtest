const { sendOfferToPlayer } = require('./offerService');

mp.events.add('server:createOffer:item', (player, data) => {
  const offer = JSON.parse(data);
  const item = offer.item;

  sendOfferToPlayer(player, offer, item);
});
/*
rpc.register('acceptOffer', (responseHash, info) => {
  const player = info.player;
  const offer = player.getVariable('offer');

  if (!offer || responseHash !== offer.hash) return false;

  const sender = mp.players.at(offer.sender.id);
  if (!sender || sender.character.id !== offer.sender.databaseId) return player.call('actionDone', ['Osoba, która wysłała ofertę nie jest online.']);

  const offerType = offer.type || null;
  const command = assignStrategy(offerType);

  const money = player.getVariable('money');
  if (money < offer.price) return player.call('actionDone', ['Brakuje ci pieniędzy.']);
  rp.logger.emit('offer:accepted', offer.entity.type, player, sender, offer.entity, offer.price, offer.hash);

  command.execute(player, offer, sender)
    .catch(error => {
      rp.logger.emit('offer:failed', offer.entity.type, player, sender, offer.entity, offer.price, offer.hash, error);
    });
});

rpc.register('rejectOffer', (args, { player }) => {
  const offer = player.getVariable('offer');
  clearOffer(offer);
  player.setVariable('offer', null);
});

const assignStrategy = (type) => {
  return {
    vehicle: acceptVehicleTradeCommand,
    door: acceptDoorTradeCommand,
    item: acceptItemTradeCommand
  }[type];
};

*/
