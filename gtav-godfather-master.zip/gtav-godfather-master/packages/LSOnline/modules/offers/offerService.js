'use strict';

const { Item } = require('../structures/Items');
const { OfferError } = require('../structures/Errors');
const { ItemOffer } = require('../structures/Offer');
const { haveEnoughCash, removeCashFromPlayer } = require('../player/playerService');

exports.clearOffer = (offer) => {
  if (offer.type === 'vehicle') {
    mp.vehicles.at(offer.entity.id).frozen = false;
    return true;
  }
  if (offer.type === 'door') {
    mp.markers.at(offer.entity.id).frozen = false;
    return true;
  }
  if (offer.type === 'item') {
    let item = offer.entity;
    const player = mp.players.exists(offer.sender.id) ? mp.players.at(offer.sender.id) : null;

    if (player) {
      item = player.character.inventory._items.find(_i => _i.id === item.id);
      if (item) item.frozen = false;
    }
    return true;
  }
};

const sendOfferToPlayer = function (sender, data, entity) {
  let Offer = null;
  try {
    Offer = offerFactory(sender, data, entity, 'item');

    Offer.recipient.offer = Offer;
    Offer.sender.offer = Offer;

    if (Offer.price > 0) {
      Offer.recipient.outputInfo(rp.__('offer.NewOfferReceivedPrice', sender.name, Offer.getEntityName(), Offer.price));
    } else {
      Offer.recipient.outputInfo(rp.__('offer.NewOfferReceived', sender.name, Offer.getEntityName()));
    }

    Offer.sender.outputInfo(rp.__('offer.NewOfferSent', Offer.getEntityName(), Offer.recipient.name));
  } catch (err) {
    switch (err.code) {
      case 1131:
        sender.outputError(rp.__('offer.OfferEntityNotExist'));
        break;
      case 1132:
        sender.outputError(rp.__('offer.OfferPriceInvalid'));
        break;
      case 1150:
        sender.outputError(rp.__('offer.OfferEntityFrozen'));
        break;
      case 1137: {
        sender.outputError(rp.__('offer.OfferPlayerNotAllowed'));
        break;
      }
      default:
        sender.outputError(rp.__('UnknownError'));
        break;
    }
  }
};
exports.sendOfferToPlayer = sendOfferToPlayer;

const offerFactory = (sender, data, entity, type = null) => {
  if (!type) {
    throw new OfferError(1130, 'offer type cannot be null');
  }

  const recipient = mp.players.at(data.recipient.id);

  if (recipient === sender) {
    throw new OfferError(1137, 'sender can not be recipient');
  }

  try {
    if (!(entity instanceof Item) && type === 'item') {
      entity = sender.character.inventory.freezeItem(entity.id);

      if (!entity) {
        throw new OfferError(1131, 'offer entity does not exist');
      }

      return new ItemOffer(sender, recipient, entity, data.price);
    }

    if (entity instanceof Item) {
      entity = sender.character.inventory.freezeItem(entity);

      if (!entity) {
        throw new OfferError(1131, 'offer entity does not exist');
      }

      return new ItemOffer(sender, recipient, entity, data.price);
    }
  } catch (err) {
    throw err;
  }
};

const offerAccept = (player) => {
  const Offer = player.offer;
  try {
    if (!player.offer) {
      throw new OfferError(1134, 'The player have no offer');
    }

    if (Offer.recipient !== player) {
      throw new OfferError(1137, 'The player can not accept that offer');
    }

    if (Offer.recipient.dist(Offer.sender.position) > rp.constants.MAX_OFFER_DISTANCE ||
      Offer.recipient.dimension !== Offer.sender.dimension) {
      throw new OfferError(1136, 'The players are two far from each other');
    }

    if (Offer.price > 0 && !haveEnoughCash(Offer.recipient, Offer.price)) {
      throw new OfferError(1136, 'The players are two far from each other');
    }

    if (Offer.price > 0) {
      removeCashFromPlayer(Offer.recipient, Offer.price);
      Offer.sender.data.money += Offer.price;
    }
    try {
      Offer.sender.character.inventory.transferToPlayer(Offer.recipient, Offer.entity);
      Offer.sender.outputInfo(rp.__('offer.OfferCompleteSender', Offer.recipient.name));
      Offer.recipient.outputInfo(rp.__('offer.OfferCompleteReceiver'));

      Offer.sender.actionBubble(rp.__('actions.PassSmth', Offer.recipient.name));

      Offer.recipient.Offer = null;
      Offer.sender.Offer = null;
    } catch (err) {
      throw err;
    }
  } catch (err) {
    switch (err.code) {
      case 1134:
        player.outputError(rp.__('offer.NoOffer'));
        break;
      case 1137:
        player.outputError(rp.__('offer.OfferNotAllowed'));
        break;
      default:
        handleOfferError(Offer, err);
        break;
    }
  }
};
exports.offerAccept = offerAccept;

const offerDeny = (player) => {
  const Offer = player.offer;
  try {
    if (!player.offer) {
      throw new OfferError(1134, 'The player have no offer');
    }

    if (player !== Offer.recipient) {
      throw new OfferError(1134, 'The player can not deny that offer');
    }

    Offer.recipient.outputInfo(rp.__('offer.OfferDeniedReceiver'));
    Offer.sender.outputInfo(rp.__('offer.OfferDeniedSender', Offer.recipient.name));

    Offer.entity.frozen = false;

    Offer.recipient.Offer = null;
    Offer.sender.Offer = null;
  } catch (err) {
    switch (err.code) {
      case 1134:
        player.outputError(rp.__('offer.NoOffer'));
        break;
      default:
        handleOfferError(Offer, err);
        break;
    }
  }
};
exports.offerDeny = offerDeny;

const offerCancel = (player) => {
  const Offer = player.offer;
  try {
    if (!player.offer) {
      throw new OfferError(1134, 'The player have no offer');
    }

    if (player !== Offer.sender) {
      throw new OfferError(1137, 'The player can not cancel that offer');
    }

    Offer.recipient.outputInfo(rp.__('offer.OfferCanceledReceiver', Offer.recipient.name));
    Offer.sender.outputInfo(rp.__('offer.OfferCanceledSender'));

    Offer.entity.frozen = false;

    Offer.recipient.Offer = null;
    Offer.sender.Offer = null;
  } catch (err) {
    switch (err.code) {
      case 1134:
        player.outputError(rp.__('offer.NoOffer'));
        break;
      default:
        handleOfferError(Offer, err);
        break;
    }
  }
};
exports.offerCancel = offerCancel;

const handleOfferError = (Offer, err) => {
  switch (err.code) {
    case 1131:
      Offer.sender.outputError(rp.__('offer.OfferEntityNotExist'));
      break;
    case 1132:
      Offer.sender.outputError(rp.__('offer.OfferPriceInvalid'));
      break;
    case 1150:
      Offer.sender.outputError(rp.__('offer.OfferEntityFrozen'));
      break;
    case 1136:
      Offer.recipient.outputError(rp.__('offer.OfferTooFar'));
      break;
    case 1137: {
      Offer.sender.outputError(rp.__('offer.OfferPlayerNotAllowed'));
      break;
    }
    default:
      Offer.sender.outputError(rp.__('UnknownError'));
      break;
  }
};

exports.handleOfferError = handleOfferError;
