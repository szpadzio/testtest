'use strict';

const { checkIfVehicleModelIsBike } = require('../vehicles/vehicleMisc');

mp.events.add({
  playerEnterVehicle: (player, vehicle, seat) => {
    const isBike = checkIfVehicleModelIsBike(vehicle.informations.model);

    if (seat === -1) {
      if (!isBike) {
        player.call('actionDone', [`Aby uruchomić silnik wciśnij Y.`]);
      }

      /* if (isVehicleConvertible) {
        player.call('actionDone', []`~INPUT_CELLPHONE_DOWN~ aby otworzyć dach lub ~INPUT_CELLPHONE_UP~ aby go zamknąć.`);
      }
      */
    }
  },

  vehicleDamage: (vehicle, bodyHealthLoss, engineHealthLoss) => {
    const currentEngine = vehicle.getVariable('engineHealth');

    if (currentEngine > -4000) {
      vehicle.setVariable('engineHealth', currentEngine - engineHealthLoss);
    }
  },

  vehicleDeath: vehicle => {
    if (vehicle.fuelDrain) {
      clearInterval(vehicle.fuelDrain);
    }
  },

  playerStartExitVehicle: (player) => {
    if (player.vehicle.engine) {
      player.vehicle.engine = true;
    }
  },

  playerStartEnterVehicle: (player, vehicle) => {
    if (vehicle.engine) {
      vehicle.engine = true;
    }
  },

  updateMileage: (player, vehicleId, mileage) => {
    const vehicle = mp.vehicles.at(vehicleId);

    vehicle.setVariable('dirtLevel', vehicle.getVariable('dirtLevel') + mileage / 1000 / 100);
    vehicle.informations.mileage += mileage;
  }
});
