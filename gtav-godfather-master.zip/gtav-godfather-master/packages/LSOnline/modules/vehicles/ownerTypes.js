const types = {
  gracz: 'character',
  grupa: 'group'
};

module.exports = (type) => {
  return types[type];
};
