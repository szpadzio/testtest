'use strict';

const logger = require('../utils/logger');
const helpers = require('../utils/helpers');
const database = require('../database/database');
const vehicleData = require('../vehicles/vehicleData');
const vehicleList = require('../vehicles/vehicleList.json');
const ItemFactory = require('../items/itemFactory');

/**
 * Create vehicle inside database with given name.
 * Proceed to spawn vehicle on world.
 *
 * @param {object} player Player as object.
 * @param {string} model Model of the vehicle.
 */
async function create (player, model) {
  const primaryColor = [helpers.randomInt(0, 255), helpers.randomInt(0, 255), helpers.randomInt(0, 255)];
  const secondaryColor = [helpers.randomInt(0, 255), helpers.randomInt(0, 255), helpers.randomInt(0, 255)];

  return database.Vehicle
    .create({
      name: model.charAt(0).toUpperCase() + model.slice(1),
      model: model,
      fuel: 10,
      fuelType: vehicleData.fuelTypes[0].type,
      fuelRatio: 1,
      tankCapacity: 40.0,
      primaryColor: primaryColor,
      secondaryColor: secondaryColor,
      dimension: player.dimension,
      position: player.position,
      plate: helpers.getRandomLicensePlate(),
      bodyHealth: 1000,
      engineHealth: 1000
    })
    .then(vehicle => {
      logger('vehicle', `Saved vehicle "${vehicle.name}" (Model: ${vehicle.model}) in database.`, 'info');
      return spawn(vehicle);
    });
}

exports.create = create;

/**
 * Configure newly spawned on world vehicle.
 *
 * @param {object} createdVehicle Vehicle ingame.
 * @param {object} vehicleData Vehicle as object from database.
 */
function configureCreated (createdVehicle, vehicleData) {
  try {
    let vehiclePlate = vehicleData.plate || '';
    let primaryColor = typeof vehicleData.primaryColor === 'string' ? JSON.parse(vehicleData.primaryColor) : vehicleData.primaryColor;
    let secondaryColor = typeof vehicleData.secondaryColor === 'string' ? JSON.parse(vehicleData.secondaryColor) : vehicleData.secondaryColor;

    createdVehicle.setColorRGB(primaryColor[0], primaryColor[1], primaryColor[2], secondaryColor[0], secondaryColor[1], secondaryColor[2]);
    createdVehicle.numberPlate = vehiclePlate;
    createdVehicle.informations = {
      id: vehicleData.id,
      name: vehicleData.name,
      model: vehicleData.model,
      fuel: vehicleData.fuel,
      fuelType: vehicleData.fuelType,
      fuelRatio: vehicleData.fuelRatio,
      tankCapacity: vehicleData.tankCapacity,
      primaryColor: JSON.stringify(createdVehicle.getColorRGB(0)),
      secondaryColor: JSON.stringify(createdVehicle.getColorRGB(1)),
      dirtLevel: vehicleData.dirtLevel,
      ownerId: vehicleData.ownerId,
      ownerType: vehicleData.ownerType,
      dimension: vehicleData.dimension,
      position: vehicleData.position,
      parkingPosition: vehicleData.parkingPosition,
      mileage: vehicleData.mileage,
      engineHealth: vehicleData.engineHealth,
      bodyHealth: vehicleData.bodyHealth
    };

    if (vehicleData.model in vehicleList['Cycles'] || vehicleData.model in vehicleList['Motorcycles']) {
      createdVehicle.setVariable('windows', false);
      createdVehicle.setVariable('roof', false);
    } else {
      createdVehicle.setVariable('windows', true);
      createdVehicle.setVariable('roof', true);
      createdVehicle.setVariable('dirtLevel', vehicleData.dirtLevel);
    }

    createdVehicle.setVariable('engineHealth', vehicleData.engineHealth);
    createdVehicle.setVariable('fuel', vehicleData.fuel);
    createdVehicle.setVariable('DbID', vehicleData.id);

    createdVehicle.trunk = vehicleData.Items ? vehicleData.Items.map(item => {
      return ItemFactory(item.id, item.type, item.subtype, item.name, JSON.parse(item.extra));
    }) : [];

    return createdVehicle;
  } catch (e) {
    logger('vehicle', `Error occurred when configuring vehicle "${vehicleData.name}" (ID: ${vehicleData.id} / Model: ${vehicleData.model}). (Message: ${e})`, 'error');
  }
  return createdVehicle;
}

/**
 * Load vehicle from database and proceed to spawn on world.
 *
 * @param {integer} vehicleId Vehicle ID.
 */
async function load (vehicleId) {
  let vehicle = await database.Vehicle.findByPk(vehicleId, { include: [database.Item] });

  if (vehicle) {
    vehicle = await spawn(vehicle.get({ plain: true }));
  }

  return vehicle;
}

exports.load = load;

/**
 * Load all vehicles and spawn them on world.
 */
const loadAll = async () => {
  return database.Vehicle.findAll({ where: { ownerType: 'character' }, include: [database.Item] }).then(vehicles => {
    for (let i = 0; i < vehicles.length; i++) {
      spawn(vehicles[i].get({ plain: true }));
    }
  });
};

exports.loadAll = loadAll;

/**
 * Spawn vehicle on world.
 *
 * @param {object} vehicle Vehicle as object from database.
 */
function spawn (vehicle) {
  if (vehicle.position === null) {
    return logger('vehicle', `Vehicle position is null (vehicleId: ${vehicle.id})!`, 'error');
  }

  let carPosition = typeof vehicle.position === 'string' ? JSON.parse(vehicle.position) : vehicle.position;
  const createdVehicle = mp.vehicles.new(mp.joaat(vehicle.model), new mp.Vector3(carPosition.x, carPosition.y, carPosition.z),
    {
      engine: false,
      locked: vehicle.lockedOnUnspawn,
      dimension: vehicle.dimension
    });

  if (vehicle.ownerType === 'character') {
    const player = mp.players.toArray().find(player => {
      return player.character && player.character.info.id === vehicle.ownerId;
    });

    if (player) {
      player.character.vehicles.push(createdVehicle);
    }
  }

  if (carPosition.rotation) {
    createdVehicle.rotation = new mp.Vector3(carPosition.rotation);
  }

  // logger('vehicle', `Spawned vehicle "${vehicle.name}" (GameID: ${createdVehicle.id} / ID: ${vehicle.id} / Model: ${vehicle.model}) on world.`, 'info');
  return configureCreated(createdVehicle, vehicle);
}

/**
 * Refuel vehicle.
 *
 * @param {integer} vehicleId Vehicle ID.
 * @param {integer} fuel Amount of fuel.
 */
function refuel (vehicleId, fuel) {
  return database.Vehicle.findByPk(vehicleId).then(vehicle => vehicle.update({ fuel: database.Sequelize.literal(`fuel + ${fuel}`) }))
    .then((vehicle) => {
      return logger('vehicle', `Refueled vehicle  (ID: ${vehicle.id}).`, 'info');
    })
    .catch((err) => {
      return logger('vehicle', `Error occurred when refueling vehicle (ID: ${vehicle.id}). (Message: ${err})`, 'error');
    });
}

exports.refuel = refuel;

/**
 * Update vehicle name.
 *
 * @param {integer} vehicleId Vehicle ID.
 * @param {string} name The new name of vehicle.
 */
async function updateName (vehicleId, name) {
  database.Vehicle.findByPk(vehicleId).then(vehicle => {
    vehicle
      .update({ name: name })
      .then((vehicle) => {
        logger('vehicle', `Changed vehicle "${vehicle.name}" name (Model: ${vehicle.model} / ID: ${vehicle.id}).`, 'info');
      })
      .catch((err) => {
        logger('vehicle', `Error occurred when changing vehicle "${vehicle.name}" name (Model: ${vehicle.model} / ID: ${vehicle.id}). (Message: ${err})`, 'error');
      });
  });
}

exports.updateName = updateName;

/**
 * Assign vehicle to owner.
 *
 * @param {integer} vehicleId Vehicle ID.
 * @param {string} ownerType Owner type (character | group)
 * @param {integer} owner Owner ID.
 */
async function assign (vehicleId, ownerType, ownerId) {
  return database.Vehicle.update({ ownerId, ownerType }, { where: { id: vehicleId } })
    .then((vehicle) => {
      logger('vehicle', `Assigned vehicle vehicle (ID: ${vehicleId}) to ${ownerType} (ID: ${ownerId}).`, 'info');
      return vehicle;
    })
    .catch((err) => {
      logger('vehicle', `Error occurred when assigning vehicle (ID: ${vehicleId}) to ${ownerType} (ID: ${ownerId}). (${err})`, 'error');
    });
};

exports.assign = assign;

/**
 * Remove vehicle from database.
 *
 * @param {integer} vehicleId Vehicle ID.
 */
async function remove (vehicleId) {
  database.Vehicle.findByPk(vehicleId).then(vehicle => {
    vehicle
      .destroy()
      .then(() => {
        logger('vehicle', `Removed vehicle "${vehicle.name}" (Model: ${vehicle.model} / ID: ${vehicle.id}) from database.`, 'info');
      })
      .catch((err) => {
        logger('vehicle', `Error occurred when removing vehicle "${vehicle.name}" (Model: ${vehicle.model} / ID: ${vehicle.id}). (Message: ${err})`, 'error');
      });
  });
}

exports.remove = remove;

/**
 * Update vehicle.
 *
 * @param {integer} vehicleId Vehicle id.
 * @param {array} data Data.
 */
async function update (vehicleId, data) {
  return database.Vehicle.update({ ...data }, { where: { id: vehicleId } });
};

exports.update = update;

/**
 * Unspawn vehicle from world.
 *
 * @param {object} vehicle Vehicle as entity.
 */
async function unspawn (vehicle) {
  if (vehicle.frozen) {
    return false;
  }

  if (vehicle) {
    try {
      const result = await update(vehicle.informations.id, {
        dimension: vehicle.dimension,
        bodyHealth: vehicle.bodyHealth,
        engineHealth: vehicle.getVariable('engineHealth').toFixed(3),
        position: { ...vehicle.position, rotation: vehicle.rotation },
        lockedOnUnspawn: vehicle.locked,
        fuel: vehicle.informations.fuel,
        primaryColor: vehicle.getColorRGB(0),
        secondaryColor: vehicle.getColorRGB(1),
        mileage: vehicle.informations.mileage,
        dirtLevel: vehicle.getVariable('dirtLevel') || 0
      });

      if (vehicle.informations.ownerType === 'character') {
        const player = mp.players.toArray().find(player => {
          return player.character.info.id === vehicle.informations.ownerId;
        });

        if (player) {
          const vehicles = player.character.vehicles;

          player.character.vehicles.splice(vehicles.indexOf(vehicle), 1);
        }
      }

      vehicle.destroy();
      return result[0];
    } catch (e) {
      console.log(e);
      return e;
    }
  }
  return false;
}

exports.unspawn = unspawn;

async function findVehiclesForOwner (ownerType, ownerId, raw = true) {
  return database.Vehicle.findAll({ where: { ownerType, ownerId }, raw });
};

exports.findVehiclesForOwner = findVehiclesForOwner;
