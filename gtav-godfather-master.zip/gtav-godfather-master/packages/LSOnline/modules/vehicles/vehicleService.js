'use strict';

const { assign } = require('./vehicleManager');
const { checkIfVehicleModelIsBike, checkIfVehicleModelIsOneWheeler, checkIfVehicleModelIsPolice, checkIfVehicleModelIsEmergency } = require('../vehicles/vehicleMisc');

/**
 * Get closest vehicle for player.
 *
 * @param {object} player Player.
 * @param {integer} range Range.
 */
function getClosestVehicleForPlayer (player, range) {
  let foundVehicle = null;

  mp.vehicles.forEachInRange(player.position, range, player.dimension,
    (vehicle) => {
      foundVehicle = vehicle;
    }
  );

  return foundVehicle;
}

exports.getClosestVehicleForPlayer = getClosestVehicleForPlayer;

/**
 * Get vhicle by ID.
 *
 * @param {integer} vehicleId Vehicle ID.
 */
function getVehicleById (vehicleId) {
  let foundVehicle = null;

  mp.vehicles.forEach(
    (vehicle) => {
      if (vehicle.informations.id === vehicleId) {
        foundVehicle = vehicle;
      }
    });

  return foundVehicle;
}

exports.getVehicleById = getVehicleById;

/**
 * Clear description for vehicle.
 *
 * @param {object} vehicle Vehicle object.
 */
const clearDescription = (vehicle) => {
  vehicle.setVariable('description', null);
};

exports.clearDescription = clearDescription;

/**
 * Toggle vehicle engine.
 *
 * @param {object} vehicle Vehicle object.
 * @param {object} player Player object.
 */
const toggleVehicleEngine = (vehicle, player) => {
  const isBike = checkIfVehicleModelIsBike(vehicle.informations.model);

  if (!isBike) {
    if (vehicle.informations.fuel === 0) {
      return false;
    }

    // Action type and status of vehicle engine.
    const actionType = vehicle.engine ? 'gasi' : 'odpala';
    vehicle.engine ? vehicle.engine = false : vehicle.engine = true;

    // Check action type.
    if (actionType === 'odpala') {
      vehicle.fuelDrain = setInterval(() => {
        if (vehicle.informations.fuel - vehicle.informations.fuelRatio < 0) {
          vehicle.informations.fuel = 0;
          vehicle.engine = false;

          clearInterval(vehicle.fuelDrain);
        } else {
          vehicle.informations.fuel = vehicle.informations.fuel - vehicle.informations.fuelRatio;
        }
      }, 1000 * 60);
    } else {
      if (vehicle.fuelDrain) {
        clearInterval(vehicle.fuelDrain);
      }
    }

    // Run command.
    rp.commands.get('me').run(player, { fullText: `${actionType} silnik pojazdu ${vehicle.informations.name}.` });
  }
};

exports.toggleVehicleEngine = toggleVehicleEngine;

/**
 * Toggle vehicle lock.
 *
 * @param {object} vehicle Vehicle object.
 * @param {object} player Player object.
 */
function toggleVehicleLock (vehicle, player) {
  let actionType;

  // Check if vehicle is one wheeler.
  if (checkIfVehicleModelIsOneWheeler(vehicle.informations.model)) {
    actionType = vehicle.locked ? `zdejmuje blokadę z ${vehicle.informations.name}.` : `zakłada blokadę na ${vehicle.informations.name}.`;
  } else {
    actionType = vehicle.locked ? `otwiera drzwi pojazdu ${vehicle.informations.name}.` : `zamyka drzwi pojazdu ${vehicle.informations.name}.`;
  }

  // Check if vehicle is locked.
  if (vehicle.locked) {
    vehicle.locked = false;

    // Unlock doors on client-side.
    player.call('unlockDoors', [vehicle]);
  } else {
    const isVehicleEmergencyModel = checkIfVehicleModelIsEmergency(vehicle.informations.model);
    vehicle.locked = true;

    // Lock doors on client-side.
    player.call('setDoorsLocked', [vehicle]);

    // Lock doors on client-side for police models too.
    if (isVehicleEmergencyModel) {
      player.call('setDoorsLockedInSpecialVehicle', [vehicle]);
    }
  }

  // Call sound in range.
  mp.players.callInRange(vehicle.position, 10, 'lockSound', [vehicle, !vehicle.locked]);

  // Run animation on player.
  player.playAnimation('anim@mp_player_intmenu@key_fob@', 'fob_click', 1, 0 | 16 | 32);

  // Run command on player.
  rp.commands.get('me').run(player, { fullText: `${actionType}` });
}

exports.toggleVehicleLock = toggleVehicleLock;

/**
 * Toggle police radar.
 *
 * @param {object} vehicle Vehicle objcet.
 * @param {object} player Player object.
 */
function togglePoliceRadar (vehicle, player) {
  const actionType = vehicle.data.policeRadar ? 'wyłącza' : 'włącza';
  const isVehiclePoliceModel = checkIfVehicleModelIsPolice(vehicle.informations.model);

  // Check if vehicle is police model.
  if (isVehiclePoliceModel) {
    vehicle.data.policeRadar
      ? vehicle.data.policeRadar = false
      : vehicle.data.policeRadar = true;

    // Run command.
    rp.commands.get('me').run(player, { fullText: `${actionType} radar w pojeździe ${vehicle.informations.name}.` });
  }
}

exports.togglePoliceRadar = togglePoliceRadar;

/**
 * Get owner of vehicle.
 *
 * @param {integer} ownerId Owner ID.
 * @param {string} ownerType Owner type.
 */
function getOwner (ownerId, ownerType) {
  let owner = null;

  switch (ownerType) {
    case 'group': {
      const globalGroup = rp.groups.get(parseInt(ownerId));
      if (!globalGroup) {
        throw new Error('The owner does not exist', 'ERR_OWNER_NOT_FOUND');
      }

      owner = { ownerType, ownerId: globalGroup.id, gameObject: globalGroup };
      break;
    }

    case 'character': {
      const player = mp.players.at(ownerId);

      if (!player) {
        throw new Error('The owner does not exist', 'ERR_OWNER_NOT_FOUND');
      }

      owner = { ownerType, ownerId: player.character.info.id, gameId: player.id, gameObject: player };
      break;
    }
    default: {
      throw new Error('The owner does not exist', 'ERR_OWNER_NOT_FOUND');
    }
  }
  return owner;
};

exports.getOwner = getOwner;

/**
 * Vehicle can be accessed by.
 *
 * @param {object} player Player object.
 * @param {object} vehicle Vehicle object.
 */
function canBeAccessedBy (player, vehicle) {
  if (!vehicle) {
    return false;
  }

  if (!vehicle.informations) {
    if (vehicle.ownerType === 'character') {
      return vehicle.ownerId === player.character.info.id ? 'owner' : false;
    }
  }

  if (vehicle.informations.ownerType === 'group') {
    return player.character.groups.find(_group => _group.id === vehicle.informations.ownerId) !== undefined;
  }

  if (vehicle.informations.ownerType === 'character') {
    return vehicle.informations.ownerId === player.character.info.id ? 'owner' : false;
  }

  return false;
};

exports.canBeAccessedBy = canBeAccessedBy;

/**
 * Assign vehicle to owner.
 *
 * @param {object} owner Owner objcet.
 * @param {object} vehicle Vehicle objcet.
 */
const assignTo = async (owner, vehicle) => {
  vehicle.informations.ownerType = owner.ownerType;
  vehicle.informations.ownerId = owner.ownerId;

  if (owner.ownerType === 'character') {
    owner.gameObject.character.vehicles.push(vehicle);
  }

  const result = await assign(vehicle.informations.id, owner.ownerType, owner.ownerId);
  return result;
};

exports.assignTo = assignTo;

/**
 * Transfer vehicle to group.
 *
 * @param {*} target Target object.
 * @param {object} vehicle Vehicle object.
 * @param {bool} source Source.
 */
function transferVehicleToGroup (target, vehicle, source = false) {
  if (vehicle.informations.ownerType === 'character') {
    if (source) {
      source.character.vehicles.splice(source.character.vehicles.indexOf(vehicle), 1);
    } else {
      for (const player of mp.players.toArray()) {
        if (player.character.vehicles.includes(vehicle)) {
          player.character.vehicles.splice(player.character.vehicles.indexOf(vehicle), 1);
          break;
        }
      };
    }
  }

  return assignTo(target, vehicle);
};

exports.transferVehicleToGroup = transferVehicleToGroup;

/**
 * Transfer vehicle to player.
 *
 * @param {*} target Target object.
 * @param {object} vehicle Vehicle object.
 * @param {bool} source Source.
 */
function transferVehicleToPlayer (target, vehicle, source = false) {
  if (vehicle.informations.ownerType === 'character') {
    if (source) {
      source.character.vehicles.splice(source.character.vehicles.indexOf(vehicle), 1);
    } else {
      for (const player of mp.players.toArray()) {
        if (player.character.vehicles.includes(vehicle)) {
          player.character.vehicles.splice(player.character.vehicles.indexOf(vehicle), 1);
          break;
        }
      };
    }
  }

  return assignTo(exports.getOwner(target.id, 'character'), vehicle);
};

exports.transferVehicleToPlayer = transferVehicleToPlayer;

/**
 * Respawn all vehicles on world.
 */
const respawnAll = () => {
  mp.vehicles.forEach((vehicle) => {
    if (vehicle.getOccupants().length > 0) return;

    let carPosition = JSON.parse(vehicle.informations.position);

    vehicle.engine = false;
    vehicle.dimension = Number(vehicle.informations.dimension) || 0;
    vehicle.position = new mp.Vector3({ x: carPosition.x, y: carPosition.y, z: carPosition.z });

    if (carPosition.rotation) {
      vehicle.rotation = new mp.Vector3(carPosition.rotation);
    }
  });

  return mp.vehicles.size();
};

exports.respawnAll = respawnAll;

/**
 * Respawn a vehicle on world.
 */
const respawn = (gameId) => {
  const vehicle = mp.vehicles.at(gameId);
  if (!vehicle) return;
  if (vehicle.getOccupants().length > 0) return;

  let carPosition = JSON.parse(vehicle.informations.position);
  vehicle.engine = false;
  vehicle.dimension = Number(vehicle.informations.dimension) || 0;
  vehicle.position = new mp.Vector3({ x: carPosition.x, y: carPosition.y, z: carPosition.z });

  if (carPosition.rotation) {
    vehicle.rotation = new mp.Vector3(carPosition.rotation);
  }

  return vehicle;
};

exports.respawn = respawn;
