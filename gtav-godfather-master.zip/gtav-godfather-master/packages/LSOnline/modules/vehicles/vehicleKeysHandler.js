
const { isVehicleDriver } = require('../player/playerMisc');
const { checkIfVehicleIsConvertible } = require('../vehicles/vehicleMisc');
const { getClosestVehicleForPlayer } = require('../vehicles/vehicleService');

mp.events.add({
  keyArrowDown: player => {
    if (isVehicleDriver(player)) {
      const vehicle = player.vehicle;
      const isVehicleConvertible = checkIfVehicleIsConvertible(vehicle.informations.model);

      vehicle.setVariable('roof', false);
      vehicle.setVariable('windows', false);

      if (isVehicleConvertible) {
        player.call('lowerVehicleRoof', [player.vehicle]);
      }
    }
  },

  keyArrowUp: player => {
    if (isVehicleDriver(player)) {
      const vehicle = player.vehicle;
      const isVehicleConvertible = checkIfVehicleIsConvertible(vehicle.informations.model);

      if (isVehicleConvertible) {
        vehicle.setVariable('roof', true);
        vehicle.setVariable('windows', true);

        player.call('raiseVehicleRoof', [player.vehicle]);
      }
    }
  },

  keyZ: player => {
    let vehicle = getClosestVehicleForPlayer(player, 2);

    if (vehicle) {
      rp.commands.get('v z').run(player, null, [vehicle.id]);
    }
  },

  keyY: player => {
    if (isVehicleDriver(player)) {
      rp.commands.get('engine').run(player);
    }
  },

  keyK: player => {
    if (player.vehicle) {
      player.call('playerSetSeatBelts', [player]);
    }
  }
});
