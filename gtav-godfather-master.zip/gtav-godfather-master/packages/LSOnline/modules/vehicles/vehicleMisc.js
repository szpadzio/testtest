'use strict';

const vehicleList = require('../vehicles/vehicleList');

/**
 * Check if vehicle model exists.
 *
 * @param {string} model Model.
 */
const checkIfVehicleModelExists = (model) => {
  const vehicleCategories = [
    'Boats', 'Commercials', 'Compacts', 'Coupes', 'Cycles', 'Emergency',
    'Helicopters', 'Industrial', 'Military', 'Motorcycles', 'Muscle',
    'Off-Road', 'Planes', 'SUVs', 'Sedans', 'Service', 'Sports',
    'SportsClassic', 'Super', 'Trailer', 'Trains', 'Utility', 'Vans'
  ];

  for (let category of vehicleCategories) {
    if (model in vehicleList[category]) {
      return true;
    }
  }

  return false;
};

exports.checkIfVehicleModelExists = checkIfVehicleModelExists;

/**
 * Check if vehicle model is police.
 * Temporary because vehicleClass on client-side or using native not working. ~ 2019 - still not working.
 *
 * @param {string} model Model.
 */
const checkIfVehicleModelIsPolice = (model) => {
  if (model in vehicleList['Police']) {
    return true;
  }

  return false;
};

exports.checkIfVehicleModelIsPolice = checkIfVehicleModelIsPolice;

/**
 * Check if vehicle model is emergency.
 * Temporary because vehicleClass on client-side or using native not working. ~ 2019 - still not working.
 *
 * @param {string} model Model.
 */
const checkIfVehicleModelIsEmergency = (model) => {
  if (model in vehicleList['Emergency'] || model in vehicleList['Military']) {
    return true;
  }

  return false;
};

exports.checkIfVehicleModelIsEmergency = checkIfVehicleModelIsEmergency;

/**
 * Check if vehicle is convertible.
 *
 * @param {string} model Model.
 */
const checkIfVehicleIsConvertible = (model) => {
  if (model in vehicleList['HaveConvertibleRoof']) {
    return true;
  }

  return false;
};

exports.checkIfVehicleIsConvertible = checkIfVehicleIsConvertible;

/**
 * Check if vehicle model is bike.
 *
 * @param {string} model Model.
 */
const checkIfVehicleModelIsBike = (model) => {
  if (model in vehicleList['Cycles']) {
    return true;
  }

  return false;
};

exports.checkIfVehicleModelIsBike = checkIfVehicleModelIsBike;

/**
 * Check if vehicle model is one wheeler.
 *
 * @param {string} model Model.
 */
const checkIfVehicleModelIsOneWheeler = (model) => {
  if (model in vehicleList['Cycles'] || model in vehicleList['Motorcycles']) {
    return true;
  }

  return false;
};

exports.checkIfVehicleModelIsOneWheeler = checkIfVehicleModelIsOneWheeler;
