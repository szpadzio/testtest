'use strict';

const logger = require('../utils/logger');
const { loadAll } = require('./vehicleManager');

const boot = async () => {
  rp.vehicles = [];
  await loadAll();
  logger('server', `Successfully bootstrapped vehicles!`, 'info');
};

exports.boot = boot;
