const ChatCommand = require('../chat/chatCommand');

module.exports = class extends ChatCommand {
  constructor (...args) {
    super(...args, {
      name: 'sayGroup'
    });
  }

  run (player, command, slot) {
    let text = super.run(player, command.fullText, true);
    let group = player.character.getGroup(slot);
    if (!group) return player.outputError(rp.__('player.group.NoGroup'));

    group = rp.groups.get(group.id);

    if (text) group.broadcastInCharacter(player, text);
  }
};
