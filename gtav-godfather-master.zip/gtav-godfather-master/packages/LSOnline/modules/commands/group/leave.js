const GroupCommand = require('./groupCommand');
const { clearDuty } = require('../../characters/characterService');

module.exports = class extends GroupCommand {
  constructor (...args) {
    super(...args, {
      name: 'group-leave',
      aliases: ['group-wyjdz', 'group-opusc']
    });
  }

  async run (player, command, group, args) {
    clearDuty(player);
    const result = await player.character.leaveGroup(command.slot);

    if (result) {
      player.outputInfo(rp.__('player.group.GroupLeft'));
    }
  }
};
