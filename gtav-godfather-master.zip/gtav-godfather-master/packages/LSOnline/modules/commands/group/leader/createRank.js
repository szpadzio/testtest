const GroupCommand = require('../groupCommand');
const permissions = require('../../../groups/memberPermissions');

module.exports = class CreateRank extends GroupCommand {
  constructor (...args) {
    super(...args, {
      name: 'group-createrank',
      aliases: ['group-stworzrange'],
      args: [rp.__('commands.Name'), rp.__('commands.Permissions')],
      perms: ['leader']
    });
  }

  async run (player, command, group, ...args) {
    const [name, ...parameters] = args;
    if (!name) {
      player.outputError(rp.__('leader.GroupRankInvalid', command.name, command.fullText));
      return player.outputError(rp.__('leader.GroupRankInvalid2', command.name, command.fullText));
    }
    if (name > 16) {
      return player.outputError(rp.__('leader.GroupRankNameTooLong'));
    }

    const wrongParsed = [];
    parameters.forEach(element => {
      if (!(element in permissions)) {
        wrongParsed.push(element);
      }
    });
    if (wrongParsed.length > 0) {
      return player.outputError(rp.__('leader.GroupRankPermissionsInvalid', wrongParsed.join(', ')));
    }
    const result = await group.createRank(name, parameters);
    if (result && result.code === 'ERR_DUPLICATE') return player.outputError(rp.__('leader.GroupRankDuplicate'));
    if (result.errors) return player.outputError(rp.__('UnknownError'));
    if (result) return player.outputInfo(rp.__('leader.GroupRankCreated', result.name));
    return player.outputError(rp.__('UnknownError'));
  }
};
