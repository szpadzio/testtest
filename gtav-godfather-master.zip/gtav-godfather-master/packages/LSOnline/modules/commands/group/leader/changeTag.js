const GroupCommand = require('../groupCommand');

module.exports = class extends GroupCommand {
  constructor (...args) {
    super(...args, {
      name: 'group-changetag',
      aliases: ['group-zmientag'],
      args: [rp.__('commands.GroupTag')],
      perms: ['leader']
    });
  }

  async run (player, command, group, ...args) {
    const [newTag] = args;

    if (!newTag) {
      return player.outputError('leader.GroupTagInvalid');
    }

    const result = await group.edit({ tag: newTag.toUpperCase() });

    if (result) {
      return player.outputError('leader.GroupTagUpdated');
    }
  }
};
