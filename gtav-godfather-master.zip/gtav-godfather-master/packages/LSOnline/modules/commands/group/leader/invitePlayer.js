const GroupCommand = require('../groupCommand');
const { inviteCharacterToGroup } = require('../../../characters/characterService');

module.exports = class extends GroupCommand {
  constructor (...args) {
    super(...args, {
      name: 'group-invite',
      aliases: ['group-zapros'],
      args: [rp.__('commands.IDOrName')],
      perms: ['leader']
    });
  }

  async run (player, command, group, ...args) {
    const target = this.searchPlayerByIdOrName(args[0]);
    if (target === player || !target) {
      return player.outputError(rp.__('PlayerDoesNotExist'));
    }

    if (target.character.groups.length >= rp.constants.maxGroups) {
      return player.outputError(rp.__('leader.GroupMemberTooMuchGroups'));
    }

    player.outputinfo(rp.__('leader.GroupMemberInvited', player.name, group.name));
    return inviteCharacterToGroup(target, player, group);
  }
};
