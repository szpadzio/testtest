const GroupCommand = require('../groupCommand');
const { findRankInGroup } = require('../../../groups/groupManager');
const { changeRankForCharacter } = require('../../../characters/characterManager');

module.exports = class extends GroupCommand {
  constructor (...args) {
    super(...args, {
      name: 'group-giverank',
      aliases: ['group-nadajrange'],
      args: [rp.__('commands.IDOrName'), rp.__('commands.RankName')],
      perms: ['leader']
    });
  }

  async run (player, command, group, ...args) {
    const target = this.searchPlayerByIdOrName(args[0]);
    let rank = args[1];

    if (!target) {
      return player.outputError(rp.__('PlayerDoesNotExist'));
    }
    rank = await findRankInGroup(rank, group.id);
    if (!rank) {
      return player.outputError(rp.__('leader.GroupRankNotFound'));
    }

    if (target === player && !rank.permissions.includes('leader')) {
      return player.outputError(rp.__('leader.GroupLeaderRankChangeFailed'));
    }

    const result = await changeRankForCharacter(target.id, group.id, rank.id);

    return result
      ? player.outputInfo(rp.__('leader.GroupMemberRankChanged', target.name, rank.name))
      : player.outputError(rp.__('UnknownError'));
  }
};
