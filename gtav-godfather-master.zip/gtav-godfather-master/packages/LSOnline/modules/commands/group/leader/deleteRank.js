const Command = require('../groupCommand');
const { findRankInGroup } = require('../../../groups/groupManager');

module.exports = class extends Command {
  constructor (...args) {
    super(...args, {
      name: 'group-deleterank',
      aliases: ['group-usunrange'],
      args: [rp.__('commands.RankName')],
      perms: ['leader']
    });
  }

  async run (player, command, group, ...args) {
    const [name] = args;
    const rank = await findRankInGroup(name, group.id);
    if (!rank) {
      return player.outputError(rp.__('leader.GroupRankNotFound'));
    }
    const result = await group.deleteRank(rank.name);
    if (result) return player.outputInfo(rp.__('leader.GroupRankdeleted'));

    return player.outputError(rp.__('UnknownError'));
  }
};
