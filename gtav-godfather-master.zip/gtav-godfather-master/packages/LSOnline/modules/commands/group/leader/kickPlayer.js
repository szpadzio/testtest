const GroupCommand = require('../groupCommand');

module.exports = class extends GroupCommand {
  constructor (...args) {
    super(...args, {
      name: 'group-uninvite',
      aliases: ['group-kick', 'group-wypros'],
      args: [rp.__('commands.IDOrName')],
      perms: ['leader']
    });
  }

  async run (player, command, group, ...args) {
    const target = this.searchPlayerByIdOrName(args[0]);
    let result = false;
    if (target === player || !target) {
      return player.outputError(rp.__('PlayerDoesNotExist'));
    }

    if (target.character.groups.filter(_group => _group.id === group.id).length > 0) {
      result = await group.kickMember(target);
    } else {
      return player.outputError(rp.__('leader.GroupMemberIsNotMember', target.name, group.name));
    }

    if (result > 0) {
      target.outputInfo(rp.__('player.group.PlayerUninvited', group.name));
      return player.outputInfo(rp.__('leader.GroupMemberUninvited', target.name, group.name));
    }
  }
};
