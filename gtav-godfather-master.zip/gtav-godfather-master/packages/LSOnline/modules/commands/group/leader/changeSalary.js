const GroupCommand = require('../groupCommand');
const groupManager = require('../../../groups/groupManager');

module.exports = class extends GroupCommand {
  constructor (...args) {
    super(...args, {
      name: 'group-changesalary',
      aliases: ['group-zmienwyplate'],
      args: [rp.__('commands.Rank'), rp.__('commands.Amount')],
      perms: ['leader']
    });
  }

  async run (player, command, group, ...args) {
    let [rank, newSalary] = args;
    newSalary = parseInt(newSalary);
    if (!newSalary || newSalary < 0 || isNaN(newSalary)) {
      return player.outputError(rp.__('leader.GroupSalaryInvalid'));
    }

    rank = await groupManager.findRankInGroup(rank, group.id);
    if (!rank) {
      return player.outputError(rp.__('leader.GroupRankNotFound'));
    }

    const result = rank.update({ salary: newSalary });
    if (result) {
      player.outputInfo(rp.__('leader.GroupSalaryUpdated'));
      group.rank.salary = newSalary;
    }
  }
};
