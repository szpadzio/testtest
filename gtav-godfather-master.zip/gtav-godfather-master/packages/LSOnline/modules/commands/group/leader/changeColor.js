const GroupCommand = require('../groupCommand');
const color = require('color');

module.exports = class extends GroupCommand {
  constructor (...args) {
    super(...args, {
      name: 'group-changecolor',
      aliases: ['group-zmienkolor'],
      args: [rp.__('commands.HEXColor')],
      perms: ['leader']
    });
  }

  async run (player, command, group, ...args) {
    let [newColor] = args;
    try {
      newColor = color(newColor).hex();
    } catch (e) {
      newColor = false;
    }

    if (!newColor) {
      return player.outputError(rp.__('leader.GroupColorInvalid'));
    }
    const result = await group.edit({ color: newColor });
    if (result) return player.outputError(rp.__('leader.GroupColorUpdated', group.name));
  }
};
