const Command = require('../../structures/Command');

module.exports = class extends Command {
  constructor (...args) {
    super(...args, {
      name: 'group-online'
    });
  }

  run (player, command, group, args) {
    group = rp.groups.get(group.id);
    if (!group) return player.outputError(rp.__('player.group.NoGroup'));
    group.activeMembers.forEach(e => player.outputChatBox(e.name));
  }
};
