const Command = require('./groupCommand');
const Color = require('color');
const moment = require('moment');

module.exports = class extends Command {
  constructor (...args) {
    super(...args, {
      name: 'group-duty'
    });
  }

  async run (player, command, group) {
    if (!group) return;
    const globalGroup = rp.groups.get(group.id);
    if (player.character.duty) {
      player.character.duty.duration = moment.duration(moment().diff(player.character.duty.start)).asMilliseconds();

      player.character.duty.end = new Date();
      player.call('dutyToggle');
      player.outputInfo(rp.__('player.group.DutyEnded', moment.duration(player.character.duty.duration, 'milliseconds').humanize()));

      await player.character.updateDuty();
      return;
    }
    player.character.duty = {
      start: new Date(),
      group
    };

    const color = Color(globalGroup.color).rgb();
    player.call('dutyToggle', [group.tag, color.color]);
    player.outputInfo(rp.__('player.group.DutyStarted', group.name));
  }
};
