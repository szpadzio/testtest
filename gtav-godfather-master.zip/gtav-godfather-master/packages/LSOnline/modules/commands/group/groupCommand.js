const Command = require('../../structures/Command');

module.exports = class GroupCommand extends Command {
  constructor (...args) {
    let [file, options] = args;
    if (options === undefined) options = {};
    super(file, {
      ...options,
      restriction: options.restriction ? true : false
    });
  }
};
