const Command = require('../../structures/Command');

module.exports = class extends Command {
  constructor (...args) {
    super(...args, {
      name: 'group-info'
    });
  }

  run (player, command, group, args) {
    return player.outputChatBox(JSON.stringify(group));
  }
};
