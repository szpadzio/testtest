const GroupCommand = require('./groupCommand');

module.exports = class extends GroupCommand {
  constructor (...args) {
    super(...args, {
      name: 'g',
      aliases: ['grupa', 'group']
    });
  }

  run (player, command, args) {
    const [slot, action] = args;

    if (args.length === 0) {
      return false;
    }
    args = args.splice(2);

    const group = player.character.getGroup(slot);
    if (!group) return player.outputError('player.group.NoGroup');
    const subcommand = rp.commands.get(`group-${action}`);
    if (subcommand && !subcommand.haveEnoughPermissions(group.rank)) {
      return player.outputError('NoActionPermission');
    }

    if (subcommand && args.length < subcommand.args.length) return player.outputTip(`/${command.name} ${command.fullText} ${subcommand.tooltip}`);
    if (subcommand) return subcommand.run(player, { ...command, slot }, group, ...args);
    return player.outputTip(rp.__('GroupTip'));
  }
};
