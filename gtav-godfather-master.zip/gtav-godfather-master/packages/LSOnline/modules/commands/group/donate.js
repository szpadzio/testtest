const GroupCommand = require('./groupCommand');

module.exports = class extends GroupCommand {
  constructor (...args) {
    super(...args, {
      name: 'group-donate',
      aliases: ['group-pay', 'group-plac', 'group-wplac'],
      args: [rp.__('commands.Amount')]
    });
  }

  run (player, command, group, ...args) {
    let [amount] = args;
    amount = parseInt(amount);

    if (isNaN(amount) || !amount || amount <= 0) {
      return player.outputError('AmountInvalid');
    }

    if (amount > player.money) {
      return player.outputError('NotEnoughMoney');
    }
    player.setVariable('money', player.getVariable('money') - Math.abs(amount));

    group.donate(amount);
  }
};
