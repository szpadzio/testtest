const Command = require('../../structures/Command');

class Teleport extends Command {
  constructor (...args) {
    super(...args, {
      name: 'weather',
      aliases: ['pogoda'],
      args: [rp.__('commands.WeatherOrReal')]
    });
  }

  run (player, command, args) {
    const [weather] = args;

    weather === 'realworld'
      ? rp.weatherMode = 'realworld' : rp.weatherMode = 'admin';

    mp.world.setWeatherTransition(weather);
    player.outputInfo(rp.__('admin.world.WeatherChanged'));
  }
}

module.exports = Teleport;
