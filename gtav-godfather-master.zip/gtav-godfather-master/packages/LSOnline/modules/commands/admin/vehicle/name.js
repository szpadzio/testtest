const Command = require('../../../structures/Command');
const { updateName } = require('../../../vehicles/vehicleManager');

class Vehicle extends Command {
  constructor (...args) {
    super(...args, {
      name: 'avehicle name',
      aliases: ['aveh name', 'av name'],
      args: [rp.__('commands.VehicleGameId'), rp.__('commands.VehicleNewName')]
    });
  }

  async run (player, command, args) {
    const [vehicleId, name] = args;

    const vehicle = mp.vehicles.at(vehicleId);
    if (vehicle) {
      vehicle.informations.name = name;
      await updateName(vehicle.informations.id, name);

      player.outputInfo(rp.__('admin.vehicle.VehicleRenamed', name, vehicle.id));
    } else {
      return player.outputTip(`/${command.name} ${this.tooltip}`);
    }
  }
}

module.exports = Vehicle;
