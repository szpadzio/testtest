const Command = require('../../../structures/Command');
const { update } = require('../../../vehicles/vehicleManager');
class Parking extends Command {
  constructor (...args) {
    super(...args, {
      name: 'avehicle parking',
      aliases: ['aveh parking', 'av parking', 'av zaparkuj'],
      args: [rp.__('commands.VehicleName')]
    });
  }

  async run (player, command, args) {
    const [vehicleId] = args;
    const vehicle = mp.vehicles.at(vehicleId);

    if (vehicle) {
      vehicle.informations.parking = vehicle.position;
      const result = await update(vehicle.informations.id, { parkingPosition: { position: vehicle.position, rotation: vehicle.rotation } });

      if (result) {
        return player.outputInfo(rp.__('admin.vehicle.VehicleParked', vehicle.informations.name, vehicle.id));
      }
      return player.outputError(rp.__('UnknownError'));
    } else {
      return player.outputTip(`/${command.name} ${this.tooltip}`);
    }
  }
}

module.exports = Parking;
