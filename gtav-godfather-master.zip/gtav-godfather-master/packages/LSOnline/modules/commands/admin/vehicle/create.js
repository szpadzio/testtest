const Command = require('../../../structures/Command');
const { create } = require('../../../vehicles/vehicleManager');
const { checkIfVehicleModelExists } = require('../../../vehicles/vehicleMisc');

class Vehicle extends Command {
  constructor (...args) {
    super(...args, {
      name: 'av',
      aliases: ['avehicle', 'av create', 'av stworz'],
      hasSubcommands: true,
      args: [rp.__('commands.VehicleModel')]
    });
  }

  async run (player, command, args) {
    const modelName = args[0];
    const isVehicleModelExist = checkIfVehicleModelExists(modelName);

    isVehicleModelExist
      ? await create(player, modelName)
      : player.outputTip(`/${command.name} ${this.tooltip}`);
  }
}

module.exports = Vehicle;
