const Command = require('../../../structures/Command');
const { getOwner, transferVehicleToGroup, transferVehicleToPlayer } = require('../../../vehicles/vehicleService');
const ownerTypes = require('../../../vehicles/ownerTypes');

class Assign extends Command {
  constructor (...args) {
    super(...args, {
      name: 'avehicle przypisz',
      aliases: ['aveh przypisz', 'av przypisz'],
      perms: ['admin', 'vehicle'],
      args: [rp.__('commands.VehicleGameId'), rp.__('commands.OwnerType'), rp.__('commands.OwnerId')]
    });
  }

  async run (player, command, args) {
    const [vehicleId, ownerType, ownerId] = args;
    let vehicle = mp.vehicles.at(parseInt(vehicleId));
    if (vehicle) {
      try {
        const owner = getOwner(ownerId, ownerTypes(ownerType));
        const result = owner.ownerType === 'group' ? transferVehicleToGroup(owner, vehicle) : transferVehicleToPlayer(owner.gameObject, vehicle);
        if (result) return player.outputInfo(rp.__('admin.vehicle.VehicleTransfered', vehicle.informations.name, owner.gameObject.name));
      } catch (e) {
        if (e.code === 'ERR_OWNER_NOT_FOUND') return player.outputError(rp.__('admin.vehicle.VehicleOwnerId'));
        return player.outputTip(`/${command.name} ${this.tooltip}`);
      }
    } else {
      return player.outputError(rp.__('admin.commands.VehicleDoesNotExist'));
    }
  }
}

module.exports = Assign;
