const Command = require('../../../structures/Command');

class Fix extends Command {
  constructor (...args) {
    super(...args, {
      name: 'avehicle fix',
      aliases: ['aveh fix', 'av fix', 'av napraw'],
      args: [rp.__('commands.VehicleModel')]
    });
  }

  async run (player, command, args) {
    const vehicleId = args[0];
    const vehicle = mp.vehicles.at(vehicleId);

    if (vehicle) {
      vehicle.repair();
      vehicle.setVariable('engineHealth', 1000);
    } else {
      return player.outputTip(`/${command.name} ${this.tooltip}`);
    }
  }
}

module.exports = Fix;
