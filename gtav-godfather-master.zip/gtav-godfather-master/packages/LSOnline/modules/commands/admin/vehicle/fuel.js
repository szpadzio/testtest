const Command = require('../../../structures/Command');
const { refuel } = require('../../../vehicles/vehicleManager');

class Fuel extends Command {
  constructor (...args) {
    super(...args, {
      name: 'avehicle fuel',
      aliases: ['aveh fuel', 'av fuel', 'av paliwo'],
      args: [rp.__('commands.VehicleModel'), rp.__('commands.FuelAmount')]
    });
  }

  async run (player, command, args) {
    const [vehicleId, fuel] = args;
    const vehicle = mp.vehicles.at(vehicleId);

    if (vehicle) {
      if (isNaN(fuel)) return player.outputTip(`/${command.name} ${this.tooltip}`);

      vehicle.informations.fuel = parseFloat(vehicle.informations.fuel) + parseFloat(fuel);
      await refuel(vehicle.informations.id, fuel);

      player.outputInfo(rp.__('admin.vehicle.VehicleRefueled', vehicle.informations.name, vehicle.id));
    } else {
      return player.outputTip(`/${command.name} ${this.tooltip}`);
    }
  }
}

module.exports = Fuel;
