const Command = require('../../../structures/Command');
const { respawnAll, respawn } = require('../../../vehicles/vehicleService');

class Respawn extends Command {
  constructor (...args) {
    super(...args, {
      name: 'av respawn',
      aliases: ['av res'],
      args: [rp.__('commands.VehicleGameId')]
    });
  }

  run (player, command, args) {
    const [vehicleId] = args[0];
    if (vehicleId) {
      const result = respawn(vehicleId);
      player.outputInfo(rp.__('admin.commands.VehicleRespawned', result.informations.name, result.id));
    }
  }
}

module.exports = Respawn;
