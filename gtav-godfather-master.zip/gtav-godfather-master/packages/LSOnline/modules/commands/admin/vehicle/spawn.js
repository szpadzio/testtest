const Command = require('../../../structures/Command');
const { load } = require('../../../vehicles/vehicleManager');

class Unspawn extends Command {
  constructor (...args) {
    super(...args, {
      name: 'avehicle spawn',
      aliases: ['aveh spawn', 'av spawn'],
      args: [rp.__('commands.VehicleId')]
    });
  }

  async run (player, command, args) {
    const vehicleId = parseInt(args[0]);
    if (isNaN(vehicleId) || vehicleId < 1) {
      return player.outputError(rp.__('admin.vehicle.VehicleIdInvalid'));
    }

    if (mp.vehicles.toArray().find(_vehicle => _vehicle.informations.id === vehicleId)) {
      return player.outputError(rp.__('admin.vehicle.VehicleAlreadySpawned'));
    }

    const vehicle = await load(vehicleId);

    if (vehicle) return player.outputInfo(rp.__('admin.vehicle.VehicleSpawned', vehicle.informations.name, vehicle.id));

    return player.outputTip(`/${command.name} ${this.tooltip}`);
  }
}

module.exports = Unspawn;
