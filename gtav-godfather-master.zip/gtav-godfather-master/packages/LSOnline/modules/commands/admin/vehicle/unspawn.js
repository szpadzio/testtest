const Command = require('../../../structures/Command');
const { unspawn } = require('../../../vehicles/vehicleManager');

class Unspawn extends Command {
  constructor (...args) {
    super(...args, {
      name: 'avehicle unspawn',
      aliases: ['aveh unspawn', 'av unspawn'],
      args: ['ID pojazdu z gry']
    });
  }

  async run (player, command, args) {
    const vehicleId = args[0];
    const vehicle = mp.vehicles.at(vehicleId);

    if (vehicle) {
      const result = await unspawn(vehicle);
      if (!result) return player.outputError(rp.__('admin.vehicle.VehicleNotFound'));

      player.outputInfo(rp.__('admin.vehicle.VehicleUnspawned', vehicle.informations.name, vehicle.id));
    } else {
      return player.outputError(rp.__('UnknownError'));
    }
  }
}

module.exports = Unspawn;
