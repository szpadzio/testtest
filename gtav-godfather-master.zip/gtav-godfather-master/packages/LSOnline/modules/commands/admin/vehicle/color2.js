const Command = require('../../../structures/Command');

class Color2 extends Command {
  constructor (...args) {
    super(...args, {
      name: 'avehicle color2',
      aliases: ['aveh color2', 'av color2', 'av kolor2'],
      args: ['ID pojazdu z gry', 'r', 'g', 'b']
    });
  }

  async run (player, command, args) {
    const [vehicleId, r, g, b] = args;
    const vehicle = mp.vehicles.at(vehicleId);

    if (vehicle) {
      const color = vehicle.getColorRGB(0);
      vehicle.setColorRGB(color[0], color[1], color[2], parseInt(r), parseInt(g), parseInt(b));
      vehicle.informations.secondaryColor = JSON.stringify(vehicle.getColorRGB(1));
      player.outputInfo(rp.__('admin.vehicle.VehiclePainted', vehicle.informations.name, vehicle.id));
    } else {
      return player.outputTip(`/${command.name} ${this.tooltip}`);
    }
  }
}

module.exports = Color2;
