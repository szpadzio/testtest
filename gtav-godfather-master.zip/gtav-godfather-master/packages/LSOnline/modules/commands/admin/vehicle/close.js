const Command = require('../../../structures/Command');

class Close extends Command {
  constructor (...args) {
    super(...args, {
      name: 'avehicle close',
      aliases: ['aveh close', 'av close', 'av zamknij'],
      args: [rp.__('commands.VehicleGameId')]
    });
  }

  async run (player, command, args) {
    const vehicleId = parseInt(args[0]);
    const vehicle = mp.vehicles.at(vehicleId);

    if (vehicle) {
      vehicle.locked = !vehicle.locked;

      return vehicle.locked
        ? player.outputInfo(rp.__('admin.commands.VehicleLocked', vehicle.informations.name))
        : player.outputInfo(rp.__('admin.commands.VehicleUnlocked', vehicle.informations.name));
    } else {
      return player.outputTip(`/${command.name} ${this.tooltip}`);
    }
  }
}

module.exports = Close;
