const Command = require('../../../structures/Command');

class VGoto extends Command {
  constructor (...args) {
    super(...args, {
      name: 'avehicle goto',
      aliases: ['aveh goto', 'av goto'],
      args: [rp.__('commands.VehicleGameId')]
    });
  }

  async run (player, command, args) {
    const vehicleId = parseInt(args[0]);
    const vehicle = mp.vehicles.at(vehicleId);

    if (vehicle) {
      player.dimension = vehicle.dimension;
      player.position = new mp.Vector3({ x: vehicle.position.x, y: vehicle.position.y, z: vehicle.position.z + 1 });
      return;
    }
    return player.outputTip(`/${command.name} ${this.tooltip}`);
  }
}

module.exports = VGoto;
