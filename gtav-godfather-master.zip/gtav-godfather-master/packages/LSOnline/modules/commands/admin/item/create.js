const Command = require('../../../structures/Command');
const ItemFactory = require('../../../items/itemFactory');
const { save } = require('../../../items/itemManager');

class CreateItem extends Command {
  constructor (...args) {
    super(...args, {
      name: 'ap stworz',
      aliases: ['ap create'],
      args: [rp.__('commands.ItemType'), rp.__('commands.ItemSubTypeOrNull'), rp.__('commands.ItemNameOrNull')]
    });
  }

  async run (player, command, args) {
    let [type, subtype, name] = args;

    subtype = subtype === 'null' ? null : subtype.replace('_', ' ');
    name = name === 'null' ? null : name.replace('_', ' ');

    try {
      const item = ItemFactory(null, type, subtype, name);
      const dbItem = await save(item, player.character.info.id, 'character');
      item.id = dbItem.id;
      player.character.inventory.pushItem(item);
    } catch (err) {
      if (err.code === 'ERR_TYPE_NOT_FOUND') return player.outputError(rp.__('admin.item.ItemTypeInvalid'));
      return player.outputError(rp.__('UnknownError'));
    }
  }
}

module.exports = CreateItem;
