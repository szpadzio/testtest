const Command = require('../../../structures/Command');

class Item extends Command {
  constructor (...args) {
    super(...args, {
      name: 'ap',
      aliases: ['ai', 'aprzedmiot'],
      hasSubcommands: true
    });
  }

  async run (player, command, args) {

  }
}

module.exports = Item;
