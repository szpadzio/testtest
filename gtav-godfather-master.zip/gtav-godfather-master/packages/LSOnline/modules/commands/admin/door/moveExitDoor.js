const Command = require('../../../structures/Command');
const { moveExitDoor } = require('../../../doors/doorManager');

class Enter extends Command {
  constructor (...args) {
    super(...args, {
      name: 'adoor wyjscie',
      aliases: ['ad wyjscie', 'ad exit'],
      args: [rp.__('commands.DoorGameId')]
    });
  }

  async run (player, command, args) {
    const [doorGameId] = args;
    let door = mp.markers.at(parseInt(doorGameId));
    if (door && door.isDoor) {
      try {
        const newPosition = { position: player.position, dimension: player.dimension, ipl: player.door.informations.ipl };
        const result = await moveExitDoor(door.informations.id, door.id, newPosition);
        if (result) return player.outputInfo(rp.__('admin.property.DoorExitUpdated', door.informations.name, door.id));
      } catch (e) {
        return player.outputError(rp.__('admin.property.DoorActionFailed'));
      }
    } else {
      return player.outputError(rp.__('admin.property.GameIdInvalid'));
    }
  }
}

module.exports = Enter;
