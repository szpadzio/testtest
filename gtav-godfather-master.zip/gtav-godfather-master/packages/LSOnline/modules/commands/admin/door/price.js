const Command = require('../../../structures/Command');
const { updateEnterPrice } = require('../../../doors/doorManager');

class Price extends Command {
  constructor (...args) {
    super(...args, {
      name: 'adoor price',
      aliases: ['adrzwi cena', 'ad price'],
      args: [rp.__('commands.DoorGameId'), rp.__('commands.DoorEntryPrice')]
    });
  }

  async run (player, command, args) {
    const [doorGameId, price] = args;
    const door = mp.markers.at(doorGameId);

    if (door) {
      await updateEnterPrice(door.informations.id, door.id, price);

      player.outputInfo('admin.property.DoorEnterPriceUpdated', door.informations.name, door.id);
    }
    return player.outputTip(`/${command.name} ${this.tooltip}`);
  }
}

module.exports = Price;
