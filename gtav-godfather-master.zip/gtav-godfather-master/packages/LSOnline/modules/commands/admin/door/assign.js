const Command = require('../../../structures/Command');
const { getOwner } = require('../../../vehicles/vehicleService');
const ownerTypes = require('../../../vehicles/ownerTypes');
const { assign } = require('../../../doors/doorManager');

class Assign extends Command {
  constructor (...args) {
    super(...args, {
      name: 'adoor przypisz',
      aliases: ['ad przypisz', 'ad assign'],
      args: [
        rp.__('commands.DoorName'),
        rp.__('commands.DoorGameId'),
        rp.__('commands.OwnerType'),
        rp.__('commands.OwnerId')
      ]
    });
  }

  async run (player, command, args) {
    const [doorGameId, ownerType, ownerId] = args;
    let door = mp.markers.at(parseInt(doorGameId));
    if (door && door.isDoor) {
      try {
        const owner = getOwner(ownerId, ownerTypes(ownerType));
        const result = await assign(door.informations.id, owner.ownerType, owner.ownerId, doorGameId);
        if (result) return player.outputInfo(rp.__('admin.property.assigned.DoorAssigned', door.informations.name, door.id, owner.gameObject.name));
      } catch (e) {
        if (e.code === 'ERR_OWNER_NOT_FOUND') return player.outputError(rp.__('admin.property.OwnerInvalid'));
        return player.outputTip(`/${command.name} ${this.tooltip}`);
      }
    } else {
      return player.outputError(rp.__('admin.property.GameIdInvalid'));
    }
  }
}

module.exports = Assign;
