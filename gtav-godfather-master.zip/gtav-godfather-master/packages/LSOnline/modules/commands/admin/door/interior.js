const Command = require('../../../structures/Command');
const { updateInterior } = require('../../../doors/doorManager');

class Interior extends Command {
  constructor (...args) {
    super(...args, {
      name: 'ad interior',
      aliases: ['adrzwi interior', 'adoor interior'],
      args: [rp.__('commands.DoorGameId'), rp.__('commands.DoorIPL')]
    });
  }

  async run (player, command, args) {
    const [doorGameId, interiorIpl] = args;

    const marker = mp.markers.at(doorGameId);
    if (marker && marker.isDoor) {
      try {
        await updateInterior(marker.informations.id, marker.id, interiorIpl);
      } catch (e) {
        return player.outputTip(`/${command.name} ${this.tooltip}`);
      }
      player.outputInfo(rp.__('admin.property.DoorIPLUpdated', marker.informations.name, marker.informations.id));
    }
    return player.outputTip(`/${command.name} ${this.tooltip}`);
  }
}

module.exports = Interior;
