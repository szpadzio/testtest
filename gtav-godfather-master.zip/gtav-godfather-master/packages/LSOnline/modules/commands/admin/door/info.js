const Command = require('../../../structures/Command');
const db = require('../../../database/database');

class DoorInfo extends Command {
  constructor (...args) {
    super(...args, {
      name: 'ad info',
      aliases: ['adrzwi info', 'adoor info']
    });
  }

  async run (player, command, args) {
    if (player.lastEnteringDoor) {
      const door = mp.markers.at(player.lastEnteringDoor.informations.doorMarkerId);
      let owner = null;
      if (door.informations.ownerType !== null) {
        owner = door.informations.ownerType === 'character'
          ? await db.Character.findByPk(door.informations.ownerId, { raw: true, attributes: [ 'name' ] })
          : await db.Group.findByPk(door.informations.ownerId, { raw: true, attributes: [ 'name' ] });
      }
      player.outputChatBox(`!{yellow} === ${rp.__('admin.property.DoorInfo')} ===`);
      player.outputChatBox(`!{yellow} ${rp.__('admin.property.DoorInfo',
        door.informations.locked,
        door.informations.insideDimension,
        door.informations.ipl, owner ? owner.name : 'null')}`);
    }
  }
}

module.exports = DoorInfo;
