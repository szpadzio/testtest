const Command = require('../../../structures/Command');
const { getDoorPresets, createDoorWithPreset } = require('../../../doors/doorManager');

class Door extends Command {
  constructor (...args) {
    super(...args, {
      name: 'ad preset',
      aliases: ['adoor preset', 'adrzwi preset'],
      args: ['Cena', 'ID presetu (0 - jeżeli brak)', 'Nazwa drzwi']
    });
  }

  /* async run (player, command, args) {
    let [price, preset, ...name] = args;
    [price, preset, name] = [parseInt(price), parseInt(preset), Array.isArray(name) ? name.join(' ') : name];

    if (!price || isNaN(price) || price < 0 || !name || preset === undefined) {
      return player.call('actionDone', ['Złe argumenty.']);
    }
    if (!preset || preset === '0' || isNaN(preset)) {
      player.call('actionDone', ['Wybierz interior z listy.']);
      return rpc.callBrowsers(player, 'setInteriorList', [
        await getDoorPresets(),
        name,
        price
      ]);
    }
    createDoorWithPreset(preset, name, player.position, player.dimension, player.heading, price).catch(e => player.call('actionDone', [`Wystąpił błąd.`]));
  } */
}

module.exports = Door;
