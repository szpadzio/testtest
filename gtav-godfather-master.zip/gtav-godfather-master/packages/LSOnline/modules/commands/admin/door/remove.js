const Command = require('../../../structures/Command');
const { remove } = require('../../../doors/doorManager');

class Remove extends Command {
  constructor (...args) {
    super(...args, {
      name: 'adoor usun',
      aliases: ['ad usun', 'ad delete'],
      args: [rp.__('commands.DoorGameId'), rp.__('commands.DoorName')]
    });
  }

  async run (player, command, args) {
    let [doorGameId, ...doorName] = args;
    doorName = doorName.join(' ');
    let door = mp.markers.at(parseInt(doorGameId));
    if (door && door.isDoor) {
      if (doorName !== door.informations.name) return player.outputError(rp.__('admin.property.DoorNameCompareFailed'));
      try {
        player.call('destroyDoorLabel');
        await remove(door.informations.id, doorGameId);
      } catch (e) {
        player.outputInfo(rp.__('admin.property.DoorNameUpdated', doorGameId));
      }
    } else {
      return player.outputError(rp.__('admin.property.GameIdInvalid'));
    }
  }
}

module.exports = Remove;
