const Command = require('../../../structures/Command');
const { createDoor } = require('../../../doors/doorManager');

class Door extends Command {
  constructor (...args) {
    super(...args, {
      name: 'ad create',
      aliases: ['adoor create', 'ad stworz'],
      args: [rp.__('commands.DoorName')]
    });
  }

  async run (player, command, args) {
    const [doorName] = args;
    createDoor(
      doorName,
      player.position,
      player.dimension,
      player.heading,
      null,
      player.position,
      null
    );
  }
}

module.exports = Door;
