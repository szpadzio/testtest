const Command = require('../../../structures/Command');
const { moveEnterDoor } = require('../../../doors/doorManager');

class Enter extends Command {
  constructor (...args) {
    super(...args, {
      name: 'adoor wejscie',
      aliases: ['ad wejscie', 'ad enter'],
      args: [rp.__('commands.DoorGameId')]
    });
  }

  async run (player, command, args) {
    const [doorGameId] = args;
    let door = mp.markers.at(parseInt(doorGameId));
    if (door && door.isDoor) {
      try {
        const newPosition = { position: player.position, dimension: player.dimension };
        const result = await moveEnterDoor(door.informations.id, door.id, newPosition);
        if (result) return player.outputInfo(rp.__('admin.property.DoorEntranceUpdated', door.informations.name, door.id));
      } catch (e) {
        return player.outputError(rp.__('admin.property.DoorActionFailed'));
      }
    } else {
      return player.outputError(rp.__('admin.property.GameIdInvalid'));
    }
  }
}

module.exports = Enter;
