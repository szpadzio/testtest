const Command = require('../../../structures/Command');

class Door extends Command {
  constructor (...args) {
    super(...args, {
      name: 'ad',
      aliases: ['adoor', 'adrzwi'],
      hasSubcommands: true
    });
  }

  async run (player, command, args) {

  }
}

module.exports = Door;
