const Command = require('../../../structures/Command');
const { updateName } = require('../../../doors/doorManager');

class Name extends Command {
  constructor (...args) {
    super(...args, {
      name: 'ad nazwa',
      aliases: ['adrzwi nazwa', 'adoor name', 'ad name'],
      args: [rp.__('commands.DoorGameId'), rp.__('commands.NewName')]
    });
  }

  async run (player, command, args) {
    let [doorGameId, ...name] = args;
    [doorGameId, name] = [parseInt(doorGameId), name.join(' ')];
    const marker = mp.markers.at(doorGameId);
    if (marker && marker.isDoor) {
      try {
        await updateName(marker.informations.id, marker.id, name);
      } catch (e) {
        return player.outputError(rp.__('admin.property.DoorActionFailed'));
      }
      player.outputInfo(rp.__('admin.property.DoorNameUpdated', doorGameId));
    }

    return player.outputTip(`/${command.name} ${this.tooltip}`);
  }
}

module.exports = Name;
