const Command = require('../../structures/Command');

class Weapon extends Command {
  constructor (...args) {
    super(...args, {
      name: 'bron'
    });
  }

  run (player, command, args) {
    let [weapon, ammo] = args;
    weapon = mp.joaat(weapon);
    if (!weapon) weapon = mp.joaat('weapon_compactrifle');

    player.giveWeapon(weapon, parseInt(ammo) || 10000);
  }
}

module.exports = Weapon;
