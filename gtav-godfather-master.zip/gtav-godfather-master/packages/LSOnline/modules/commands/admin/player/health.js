const Command = require('../../../structures/Command');

class Health extends Command {
  constructor (...args) {
    super(...args, {
      name: 'health',
      aliases: ['hp'],
      args: [rp.__('commands.PlayerId'), rp.__('commands.Health')]
    });
  }

  run (player, command, args) {
    let [playerId, health] = args;
    const foundPlayer = this.searchPlayerByIdOrName(playerId);

    if (!foundPlayer) return player.outputError(rp.__('admin.player.PlayerDoesNotExist'));
    health = parseInt(health);
    if (isNaN(health)) return player.outputError(rp.__('admin.player.HealthValueInvalid'));
    foundPlayer.health = health;
  }
}

module.exports = Health;
