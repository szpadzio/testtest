const Command = require('../../../structures/Command');
const { reviveFromBrutallyWounded } = require('../../../player/playerService');

class Unbw extends Command {
  constructor (...args) {
    super(...args, {
      name: 'unbw',
      args: [rp.__('commands.PlayerId')]
    });
  }

  run (player, command, args) {
    const playerId = args[0];
    const foundPlayer = this.searchPlayerByIdOrName(playerId);

    if (!foundPlayer) {
      return player.outputError(rp.__('admin.player.PlayerDoesNotExist'));
    }

    if (!foundPlayer.brutallyWounded) {
      return player.outputError(rp.__('admin.player.PlayerDoesNotHaveBW'));
    }

    reviveFromBrutallyWounded(foundPlayer, true);
  }
}

module.exports = Unbw;
