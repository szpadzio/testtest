const Command = require('../../../structures/Command');
class Goto extends Command {
  constructor (...args) {
    super(...args, {
      name: 'goto',
      aliases: ['idzdo'],
      args: [rp.__('commands.PlayerId')]
    });
  }

  run (player, command, args) {
    const playerId = args[0];
    const foundPlayer = this.searchPlayerByIdOrName(playerId);

    if (!foundPlayer) {
      return player.outputError('admin.player.PlayerDoesNotExist');
    }
    player.position = foundPlayer.position;
    player.dimension = foundPlayer.dimension;
  }
}
module.exports = Goto;
