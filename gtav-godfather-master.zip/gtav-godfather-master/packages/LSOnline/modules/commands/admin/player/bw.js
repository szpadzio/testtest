const Command = require('../../../structures/Command');
const { killPlayer } = require('../../../player/playerService');

class Bw extends Command {
  constructor (...args) {
    super(...args, {
      name: 'bw',
      args: [rp.__('commands.PlayerId')]
    });
  }

  run (player, command, args) {
    const playerId = args[0];
    const foundPlayer = this.searchPlayerByIdOrName(playerId);

    if (!foundPlayer) {
      return player.outputError('admin.player.PlayerDoesNotExist');
    }

    if (foundPlayer.brutallyWounded) {
      return player.outputError(rp.__('admin.player.PlayerHasBW'));
    }

    killPlayer(foundPlayer);
  }
}

module.exports = Bw;
