const Command = require('../../../structures/Command');

class Group extends Command {
  constructor (...args) {
    super(...args, {
      name: 'ag',
      aliases: ['agroup', 'agrupa'],
      hasSubcommands: true,
      args: []
    });
  }

  async run (player, command, args) {
  }
}

module.exports = Group;
