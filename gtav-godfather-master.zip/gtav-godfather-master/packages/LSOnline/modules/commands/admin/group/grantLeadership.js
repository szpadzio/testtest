const Command = require('../../../structures/Command');
class Leader extends Command {
  constructor (...args) {
    super(...args, {
      name: 'ag lider',
      aliases: ['agroup leader', 'ag leader'],
      hasSubcommands: true,
      args: [rp.__('commands.PlayerId'), rp.__('commands.Groupid')]
    });
  }

  async run (player, command, args) {
    let [targetId, groupId] = args;
    const target = mp.players.at(targetId);
    const group = rp.groups.get(parseInt(groupId));
    if (!target || !group) return player.outputError(rp.__('admin.group.GroupOrPlayer'));
    const leaderRank = await group.getRank('Lider');
    if (!leaderRank) return player.outputError(rp.__('admin.group.GroupLeaderRankNotFound'));
    const result = await target.character.addToGroup(group, leaderRank, player);
    if (result.errors) return player.outputError(rp.__('UnknownError'));
    if (result && (result.code === 'ER_DUP_ENTRY' || result.code === 'ERR_DUPLICATE')) return player.outputError(rp.__('admin.group.GroupMemberDuplicate'));
    if (result) return player.outputInfo('admin.group.GroupLeaderGranted', target.name, group.name);
  }
}

module.exports = Leader;
