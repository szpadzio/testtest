const Command = require('../../../structures/Command');
const { getTypes } = require('../../../groups/groupTypes');

module.exports = class extends Command {
  constructor (...args) {
    super(...args, {
      name: 'ag typ',
      aliases: ['ag type', 'agroup type'],
      args: [rp.__('commands.GroupName'), rp.__('GroupTypes', getTypes())],
      perms: ['admin', 'group']
    });
  }

  async run (player, command, args) {
    const [id, type] = args;

    const group = rp.groups.get(parseInt(id));
    if (!group) player.outputError(rp.__('admin.group.GroupNotFound'));
    const result = group.edit({ type });
    if (!result) return player.outputError(rp.__('admin.group.GroupTypeNotUpdated'));
    if (result) player.outputInfo(rp.__('admin.group.GroupTypeUpdated', name));
  }
};
