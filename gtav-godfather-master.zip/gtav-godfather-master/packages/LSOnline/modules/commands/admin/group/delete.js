const Command = require('../../../structures/Command');

module.exports = class extends Command {
  constructor (...args) {
    super(...args, {
      name: 'ag usun',
      aliases: ['ag delete', 'agroup delete'],
      args: [rp.__('commands.GroupId')],
      perms: ['admin', 'group']
    });
  }

  async run (player, command, args) {
    const [id] = args;
    const group = rp.groups.get(parseInt(id));
    if (!group) return player.outputError(rp.__('admin.group.GroupNotFound'));
    const result = await group.delete();
    if (!result) return player.outputError(rp.__('admin.group.GroupNotDeleted'));
    if (result) player.outputInfo(rp.__('admin.group.GroupDeleted', group.name));
  }
};
