const Command = require('../../../structures/Command');
const { create } = require('../../../groups/groupManager');

class Create extends Command {
  constructor (...args) {
    super(...args, {
      name: 'ag stworz',
      aliases: ['agroup create', 'ag create'],
      hasSubcommands: true,
      args: [rp.__('commands.GroupTag'), rp.__('commands.GroupName')]
    });
  }

  async run (player, command, args) {
    let [tag, ...name] = args;
    name = name.join(' ');

    if (name.length > 32 || tag.length < 2 || tag.length > 4) {
      return player.outputError(rp.__('GroupTagOrNameInvalid'));
    }

    const result = await create(name, tag);

    if (result.errors || result.e) return player.outputError(rp.__('UnknownError'));
    if (result.e && result.e.code === 'ER_DUP_ENTRY') return player.outputError(rp.__('admin.group.GroupDuplicate'));
    if (result) {
      return player.outputInfo(rp.__('admin.group.GroupCreated', result.group.name, result.group.id));
    }
  }
}

module.exports = Create;
