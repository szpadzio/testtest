const Command = require('../../../structures/Command');

module.exports = class extends Command {
  constructor (...args) {
    super(...args, {
      name: 'ag nazwa',
      aliases: ['ag name', 'agroup name'],
      args: [rp.__('commands.GroupName')],
      perms: ['admin', 'group']
    });
  }

  async run (player, command, args) {
    const [id, name] = args;

    const group = rp.groups.get(parseInt(id));
    if (!group) return player.outputError(rp.__('admin.property.GroupNotFound'));
    const result = group.edit({ name });
    if (!result) return player.outputError(rp.__('admin.property.GroupNameNotUpdated'));

    if (result) player.outputInfo(rp.__('GroupNameUpdated', name));
  }
};
