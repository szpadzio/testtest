const Command = require('../structures/Command');

class Ping extends Command {
  constructor (...args) {
    super(...args, {
      name: 'gotuwa',
      aliases: ['kasa']
    });
  }

  async run (player, command, args) {
    player.data.money = parseInt(args[0]);
  }
}

module.exports = Ping;
