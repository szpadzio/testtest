const Command = require('../../structures/Command');

class DoorInfo extends Command {
  constructor (...args) {
    super(...args, {
      name: 'd info',
      aliases: ['drzwi info', 'door info']
    });
  }

  run (player, command, args) {
    if (player.lastEnteringDoor) {
      const door = mp.markers.at(player.lastEnteringDoor.informations.doorMarkerId);
      player.outputChatBox(`!{yellow} === ${door.informations.name} (ID: ${door.informations.id}, GameID: ${door.id}) ===`);
      player.outputChatBox(`!{yellow} ${rp.__('player.door.DoorInfo', door.informations.locked, door.informations.dimension, door.informations.ipl)}`);
    } else {
      return player.outputError('player.door.NoDoorNear');
    }
  }
}

module.exports = DoorInfo;
