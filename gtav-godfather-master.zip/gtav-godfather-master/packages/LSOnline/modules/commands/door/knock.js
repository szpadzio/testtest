const Command = require('../../structures/Command');

class Knock extends Command {
  constructor (...args) {
    super(...args, {
      name: 'zapukaj',
      aliases: ['knock']
    });
  }

  run (player, command, args) {
    if (player.lastEnteringDoor) {
      const door = mp.markers.at(player.lastEnteringDoor.informations.doorMarkerId);
      if (door.informations.insideDimension === 0) return;

      rp.commands.get('me').run(player, {
        fullText: rp.__('actions.KnockDoor')
      });

      mp.players.broadcastInDimension(
        door.informations.insideDimension,
        `!{${rp.constants.colors.do}} ** ${rp.__('SmbKnockTheDoor')}`
      );

      return true;
    }
    return player.outputError('player.door.NoDoorNear');
  }
}

module.exports = Knock;
