const ChatCommand = require('../chat/chatCommand');
const { enterDoor, leaveDoor } = require('../../doors/doorService');
class DriveThru extends ChatCommand {
  constructor (...args) {
    super(...args, {
      name: 'przejazd'
    });
  }

  run (player, command, args) {
    if (player.vehicle) {
      let door = player.lastEnteringDoor;
      let marker = mp.markers.at(door.informations.doorMarkerId);

      if (!marker || marker.informations.locked) {
        player.outputError('player.door.DoorLocked');
      }
      return door.informations.type === 'enter'
        ? enterDoor(player, marker, player.vehicle)
        : leaveDoor(player, marker, player.vehicle);
    }

    return player.outputError('player.door.NoDoorNear');
  }
}

module.exports = DriveThru;
