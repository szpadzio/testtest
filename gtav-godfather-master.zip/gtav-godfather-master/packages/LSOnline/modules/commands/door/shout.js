const ChatCommand = require('../chat/chatCommand');

class Shout extends ChatCommand {
  constructor (...args) {
    super(...args, {
      name: 'dk',
      aliases: ['dkrzycz', 'dshout'],
      args: ['Tekst']
    });
  }

  run (player, command, args) {
    const text = super.run(player, command.fullText);

    if (text && player.lastEnteringDoor) {
      const door = mp.markers.at(player.lastEnteringDoor.informations.doorMarkerId);
      if (door.informations.insideDimension === 0) return;
      mp.players.broadcastInRange(
        player.position,
        25,
        player.dimension,
        `!{${rp.constants.colors.say}} ${
          player.name
        } ${rp.__('actions.ShoutDoor')} ${text}!`
      );

      mp.players.broadcastInDimension(
        door.informations.insideDimension,
        `!{${rp.constants.colors.say}} ${
          player.name
        } ${rp.__('actions.ShoutDoor')} ${text}!`);

      return true;
    }
    return player.outputError('player.door.NoDoorNear');
  }
}

module.exports = Shout;
