const Command = require('../../structures/Command');

class Door extends Command {
  constructor (...args) {
    super(...args, {
      name: 'd',
      aliases: ['drzwi', 'door'],
      hasSubcommands: true
    });
  }

  run (player, command, args) {
  }
}

module.exports = Door;
