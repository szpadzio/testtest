const Command = require('../../structures/Command');
const { toggleDoor } = require('../../doors/doorService');
const { checkIfPlayerBelongsToGroupWithPermissions } = require('../../player/playerService');

class Breach extends Command {
  constructor (...args) {
    super(...args, {
      name: 'wywaz',
      aliases: ['breach']
    });
  }

  async run (player, command, args) {
    if (player.lastEnteringDoor && !player._isDoingTask) {
      const door = mp.markers.at(player.lastEnteringDoor.informations.doorMarkerId);
      if (door.informations.insideDimension === 0) return;

      if (!checkIfPlayerBelongsToGroupWithPermissions(player, ['breaching'])) return false;
      rp.commands.get('me').run(player, {
        fullText: rp.__('actions.Breach')
      });
      mp.players.broadcastInDimension(
        door.informations.insideDimension,
        `!{${rp.constants.colors.do}} ** ${rp.__('SmbBreachTheDoor')}`
      );
      player._isDoingTask = true;
      player.playAnimation('melee@unarmed@streamed_core', 'kick_close_a', 1.0, 1);
      // await rpc.callClient(player, 'startTimeInteraction', [5000, 'breachDoor']);
      player.stopAnimation();
      player._isDoingTask = false;
      toggleDoor(door, false);
      rp.commands.get('do').run(player, {
        fullText: rp.__('actions.DoorBreached')
      });
      return true;
    }
    return player.outputError(rp.__('player.door.NoDoorNear'));
  }
}

module.exports = Breach;
