const ChatCommand = require('../chat/chatCommand');

class DoorDo extends ChatCommand {
  constructor (...args) {
    super(...args, {
      name: 'ddo',
      aliases: ['drzwido'],
      args: ['Tekst']
    });
  }

  run (player, command, args) {
    const text = super.run(player, command.fullText, true);

    if (text && player.lastEnteringDoor) {
      const door = mp.markers.at(player.lastEnteringDoor.informations.doorMarkerId);
      if (door.informations.insideDimension === 0) return;

      mp.players.broadcastInRange(
        player.position,
        15,
        player.dimension,
        `!{${rp.constants.colors.do}} * ${text} (( ${player.name} ))`
      );

      mp.players.broadcastInDimension(
        door.informations.insideDimension,
        `!{${rp.constants.colors.do}} * ${text} (( ${player.name} ))`);

      return true;
    }
    return player.outputError('player.door.NoDoorNear');
  }
}

module.exports = DoorDo;
