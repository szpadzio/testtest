const Command = require('../../structures/Command');
const { canBeBought } = require('../../doors/doorService');
const { haveEnoughCash, removeCashFromPlayer } = require('../../player/playerService');
const { assign } = require('../../doors/doorManager');

class BuyDoor extends Command {
  constructor (...args) {
    super(...args, {
      name: 'zakup',
      aliases: ['zamieszkaj', 'buyproperty']
    });
  }

  async run (player, command, args) {
    if (player.lastEnteringDoor) {
      const door = mp.markers.at(player.lastEnteringDoor.informations.doorMarkerId);

      if (canBeBought(door)) {
        if (!haveEnoughCash(player, door.informations.price)) return player.outputError(rp.__('NotEnoughMoney'));
        removeCashFromPlayer(player, door.informations.price);
        try {
          await assign(door.informations.id, 'character', player.character.info.id, player.lastEnteringDoor.informations.doorMarkerId);
          return player.call('propertyBought');
        } catch (e) {
          return player.outputError(rp.__('UnknownError'));
        }
      } else {
        return player.outputError(rp.__('player.door.DoorNotForSell'));
      }
    }
    return player.outputError(rp.__('player.door.NoDearNear'));
  }
}

module.exports = BuyDoor;
