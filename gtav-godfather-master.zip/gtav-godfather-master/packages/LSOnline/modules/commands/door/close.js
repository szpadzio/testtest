const Command = require('../../structures/Command');
const { canBeAccessedBy, toggleDoor } = require('../../doors/doorService');

class CloseDoor extends Command {
  constructor (...args) {
    super(...args, {
      name: 'd z',
      aliases: ['drzwi zamknij']
    });
  }

  run (player, command, args) {
    if (player.lastEnteringDoor) {
      const door = mp.markers.at(player.lastEnteringDoor.informations.doorMarkerId);
      if (!canBeAccessedBy(player, door)) return player.outputError('player.door.DoorNoKeys');

      rp.commands.get('me').run(player, {
        fullText: rp.__('actions.LockingDoor')
      });
      toggleDoor(door);

      return true;
    }
    return player.outputError('player.door.NoDoorNear');
  }
}

module.exports = CloseDoor;
