const Command = require('../../structures/Command');
const { canBeAccessedBy } = require('../../doors/doorService');

class SearchDoor extends Command {
  constructor (...args) {
    super(...args, {
      name: 'd schowek',
      aliases: ['drzwi schowek', 'd przeszukaj']
    });
  }

  run (player, command, args) {
    if (player.door) {
      const door = player.door;
      if (!canBeAccessedBy(player, door)) return player.call('actionDone', ['Nie posiadasz kluczy do drzwi.']);

      /* rpc.callBrowsers(player, 'setNearbyItems', [door.trunk.map(item => Object({ name: item.getFormattedName(), id: item.id, type: 'door' }))]);
      rp.commands.get('ame').run(player, {
        fullText: `przeszukuje pomieszczenie.`
      });

      return true;
    }
    return player.call('actionDone', ['Nie znajdujesz się w drzwiach.']); */
    }
  }
}

module.exports = SearchDoor;
