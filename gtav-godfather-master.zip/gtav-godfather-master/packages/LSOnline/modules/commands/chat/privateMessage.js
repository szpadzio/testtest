const ChatCommand = require('./chatCommand');

module.exports = class extends ChatCommand {
  constructor (...args) {
    super(...args, {
      name: 'pm',
      aliases: ['w', 'pw'],
      args: [rp.__('commands.IDOrName'), rp.__('commands.Text')]

    });
  }

  run (player, command, args) {
    let [receiver] = args;
    const text = super.run(player, command.args.slice(1).join(' '), false, false, false);

    receiver = this.searchPlayerByIdOrName(receiver);
    if (!receiver) {
      return player.outputError(rp.__('PlayerDoesNotExist'));
    }

    player.outputChatBox(`!{${rp.constants.colors.pm}}(( >> ${receiver.name} [${receiver.id}]: ${text} ))`);
    receiver.outputChatBox(`!{${rp.constants.colors.pmReceiver}}(( ${player.name} [${player.id}]: ${text} ))`);
  }
};
