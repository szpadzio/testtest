const ChatCommand = require('./chatCommand');

module.exports = class extends ChatCommand {
  constructor (...args) {
    super(...args, {
      name: 'say',
      aliases: ['l'],
      args: ['Tekst']
    });
  }

  run (player, command, animation, suffix = false, ...args) {
    const text = super.run(player, command.fullText, true);
    const [groupId, hideForSelf] = args;
    const timeToSpeak = 1000 + text.split('').length * 50;
    if (animation) {
      player.playAnimation('mp_facial', 'mic_chatter', 1, 33);
      setTimeout(() => {
        player.playAnimation('mp_facial', 'mic_chatter', 0, 33);
      }, timeToSpeak);
    }

    if ('duty' in player.character && player.character.duty !== null) {
      const group = player.character.duty.group.getGlobalGroup();
      if (groupId === player.character.duty.group.id && group.permissions.emergency) {
        mp.players.callInRange(player.position, 15, 'radioChatter', [player, 0.75 * timeToSpeak - 1000]);
        player.playAnimation('random@arrests', 'generic_radio_chatter', 1, 51);
        setTimeout(() => {
          player.playAnimation('random@arrests', 'exit_radio_chatter', 2, 51);
        }, timeToSpeak);
      }
    }

    if (player.vehicle && player.vehicle.getVariable('windows')) {
      player.vehicle.getOccupants().forEach(_player => {
        if (hideForSelf && player.id === _player.id) {
        } else {
          _player.outputChatBox(`!{${rp.constants.colors.say.close}}${player.name} ${getSuffix(suffix)}: ${text}`);
        }
      });
      return true;
    }
    mp.players.forEachInRange(player.position, 15, player.dimension, (person) => {
      if (person.vehicle && person.vehicle.getVariable('windows')) return;
      const distance = player.distSquared(person.position);
      if (distance > 10 && text) {
        person.outputChatBox(`!{${rp.constants.colors.say.far}}${player.name} ${getSuffix(suffix)}: ${text}`);
      } else if (distance >= 6 && text) {
        person.outputChatBox(`!{${rp.constants.colors.say.medium}}${player.name} ${getSuffix(suffix)}: ${text}`);
      } else if (text) {
        if (hideForSelf && player.id == person.id) {
        } else {
          person.outputChatBox(`!{${rp.constants.colors.say.close}}${player.name} ${getSuffix(suffix)}: ${text}`);
        }
      }
    });
  }
};

const getSuffix = (type) => {
  const suffixes = {
    group: ' ' + rp.__('actions.ThroughRadio'),
    default: ''
  };
  return rp.__('actions.Says') + (suffixes[type] || suffixes['default']);
};
