const ChatCommand = require('./chatCommand');

class Ame extends ChatCommand {
  constructor (...args) {
    super(...args, {
      name: 'ame',
      aliases: ['aja'],
      args: [rp.__('commands.Text')]
    });
  }

  run (player, command, args) {
    const text = super.run(player, command.fullText, true, false);

    if (text.length > 80) return player.outputError(rp.__('player.chat.ActionTooLong'));
    player.outputChatBox(`!{${rp.constants.colors.me.close}} * ${player.name} ${text}`);
    mp.players.callInRange(player.position, 10, 'actionAboveHead', [player, text]);
  }
}

module.exports = Ame;
