const ChatCommand = require('./chatCommand');

class Me extends ChatCommand {
  constructor (...args) {
    super(...args, {
      name: 'c',
      aliases: ['szept', 'sz'],
      args: ['Tekst']
    });
  }

  run (player, command, args) {
    const text = super.run(player, command.fullText, true);

    if (text) {
      if (player.vehicle && player.vehicle.getVariable('windows')) {
        player.vehicle.getOccupants().forEach(_player => {
          _player.outputChatBox(`!{${rp.constants.colors.say.close}}${player.name} ${rp.__('actions.Whispers')}: ${text}`);
        });
        return true;
      }
      mp.players.forEachInRange(player.position, 4, player.dimension, (_player) => {
        if (_player.vehicle && _player.vehicle.getVariable('windows')) return;
        _player.outputChatBox(`!{${rp.constants.colors.whisper}} ${player.name} ${rp.__('actions.Whispers')}: ${text}`);
      });
    }
  }
}

module.exports = Me;
