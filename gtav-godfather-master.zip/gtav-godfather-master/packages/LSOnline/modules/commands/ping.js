const Command = require('../structures/Command');

class Ping extends Command {
  constructor (...args) {
    super(...args, {
      name: 'ping',
      aliases: ['pong']
    });
  }

  async run (player, command, args) {
    player.outputChatBox(rp.__('player.ping', player.ping));
  }
}

module.exports = Ping;
