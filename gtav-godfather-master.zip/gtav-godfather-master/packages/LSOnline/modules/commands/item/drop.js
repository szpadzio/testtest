const Command = require('../../structures/Command');

class UseItem extends Command {
  constructor (...args) {
    super(...args, {
      name: 'p wyrzuc',
      aliases: ['p drop'],
      args: [rp.__('commands.Index')]
    });
  }

  run (player, command, args) {
    let [index] = args;

    try {
      player.character.inventory.drop(index);
    } catch (err) {
      if (err.code === 'ERR_ITEM_INDEX') return player.outputError(rp.__('WrongIndex'));
      return player.outputError(rp.__('UnknownError'));
    }
  }
}

module.exports = UseItem;
