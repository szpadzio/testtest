const Command = require('../../structures/Command');
const itemManager = require('../../items/itemManager');

class HideItem extends Command {
  constructor (...args) {
    super(...args, {
      name: 'p schowaj',
      aliases: ['p stash', 'p hide', 'p szafa'],
      args: [rp.__('commands.Index')]
    });
  }

  run (player, command, args) {
    const [index] = args;

    const item = player.character.inventory._items[index];
    if (!player.door || !item) {
      return player.outputError(rp.__('player.door.NoInsideDoor'));
    } else {
      rp.commands.get('ame').run(player, { fullText: rp.__('actions.StashItem') });

      player.character.inventory.popItem(item);

      player.door.trunk.push(item);
      itemManager.transferItem(item, player.door.informations.id, 'door');
    }
  }
}

module.exports = HideItem;
