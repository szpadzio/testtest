const Command = require('../../structures/Command');

class PickupItem extends Command {
  constructor (...args) {
    super(...args, {
      name: 'p podnies',
      aliases: ['p pickup']
    });
  }

  run (player, command, args) {
    if (!player.vehicle) {
      return player.call('client:item:searchForNearbyItems');
    } else {
      rp.commands.get('ame').run(player, { fullText: 'przeszukuje pojazd.' });
      if (player.vehicle.trunk.length === 0) player.call('actionDone', ['Brak przedmiotów w pojeździe.']);
      // return rpc.callBrowsers(player, 'setNearbyItems', [true, player.vehicle.trunk.map(item => { return { name: item.getFormattedName(), id: item.id, type: 'vehicle' }; }), true]);
    }
  }
}

module.exports = PickupItem;
