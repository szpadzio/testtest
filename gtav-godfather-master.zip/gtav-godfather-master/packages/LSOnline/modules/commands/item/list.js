const Command = require('../../structures/Command');

class UseItem extends Command {
  constructor (...args) {
    super(...args, {
      name: 'p lista'

    });
  }

  run (player, command, args) {
    player.call('client:item:toggleInventory');
  }
}

module.exports = UseItem;
