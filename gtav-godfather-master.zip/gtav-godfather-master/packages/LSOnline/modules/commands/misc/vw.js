const Command = require('../../structures/Command');

class Vw extends Command {
  constructor (...args) {
    super(...args, {
      name: 'vw',
      aliases: ['virtualworld']
    });
  }

  run (player, command, args) {
    player.outputChatBox(`!{#dddddd} ${rp.__('player.VW', player.dimension)}`);
  }
}

module.exports = Vw;
