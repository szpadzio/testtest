const Command = require('../../structures/Command');
const helpers = require('../../utils/helpers');

class Roll extends Command {
  constructor (...args) {
    super(...args, {
      name: 'roll',
      aliases: ['kostka']
    });
  }

  run (player, command, args) {
    rp.commands.get('do').run(player, { fullText: `${rp.__('player.roll')} ${helpers.randomInt(1, 6)}.`, system: true });
  }
}

module.exports = Roll;
