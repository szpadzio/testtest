const Command = require('../../structures/Command');

class Position extends Command {
  constructor (...args) {
    super(...args, {
      name: 'pos',
      aliases: ['position']
    });
  }

  run (player, command, args) {
    player.outputChatBox(`!{#dddddd}X: ${player.position.x}, Y: ${player.position.y}, Z: ${player.position.z}`);
  }
}

module.exports = Position;
