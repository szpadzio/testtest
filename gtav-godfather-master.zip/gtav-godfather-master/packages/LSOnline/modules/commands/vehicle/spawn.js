const Command = require('../../structures/Command');
const { load } = require('../../vehicles/vehicleManager');
const { canBeAccessedBy } = require('../../vehicles/vehicleService');

class Spawn extends Command {
  constructor (...args) {
    super(...args, {
      name: 'v spawn',
      aliases: ['veh spawn', 'vehicle spawn'],
      args: [rp.__('commands.VehicleUid')]
    });
  }

  async run (player, command, args) {
    const vehicleId = parseInt(args[0]);
    if (isNaN(vehicleId) || vehicleId < 1) {
      return player.outputTip(`/${command.name} ${this.tooltip}`);
    }

    if (mp.vehicles.toArray().find(_vehicle => _vehicle.informations.id === vehicleId)) {
      return player.outputError(rp.__('player.vehicle.VehicleAlreadySpawned'));
    }

    const vehicle = await load(vehicleId);
    if (!vehicle) return player.outputError(rp.__('VehicleNotFound'));

    if (!canBeAccessedBy(player, vehicle) && vehicle.informations.ownerType === 'group') {
      vehicle.destroy();
      return player.outputError(rp.__('NoActionPermission'));
    }
    if (vehicle) return player.outputInfo(rp.__('player.vehicle.VehicleSpawned', vehicleId));

    return player.outputTip(`/${command.name} ${this.tooltip}`);
  }
}

module.exports = Spawn;
