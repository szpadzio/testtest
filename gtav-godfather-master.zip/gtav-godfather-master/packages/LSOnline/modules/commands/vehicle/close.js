const Command = require('../../structures/Command');
const { toggleVehicleLock, getClosestVehicleForPlayer, canBeAccessedBy } = require('../../vehicles/vehicleService');
const { checkIfVehicleModelIsOneWheeler } = require('../../vehicles/vehicleMisc');

class Close extends Command {
  constructor (...args) {
    super(...args, {
      name: 'v z',
      aliases: ['v zamknij', 'vehicle z']
    });
  }

  run (player, command, args) {
    const vehicle = args.length > 0 ? mp.vehicles.at(args[0]) : getClosestVehicleForPlayer(player, 5);

    if (!vehicle) return player.outputError(rp.__('player.vehicle.NoVehicleNearby'));
    if (checkIfVehicleModelIsOneWheeler(vehicle.informations.model) && vehicle.getOccupants().length > 0) return player.outputError(rp.__('player.vehicle.VehicleOneWheeerOccupiedLock'));

    if (!canBeAccessedBy(player, vehicle)) return player.outputError(rp.__('NoActionPermission'));

    toggleVehicleLock(vehicle, player);
  }
}

module.exports = Close;
