const Command = require('../../structures/Command');
const { unspawn } = require('../../vehicles/vehicleManager');
const { canBeAccessedBy } = require('../../vehicles/vehicleService');

class Unspawn extends Command {
  constructor (...args) {
    super(...args, {
      name: 'v unspawn',
      aliases: ['veh unspawn', 'vehicle unspawn'],
      args: [rp.__('commands.VehicleUid')]
    });
  }

  async run (player, command, args) {
    const vehicleId = parseInt(args[0]);
    const vehicle = player.character.vehicles.find(_v => _v.informations.id === vehicleId);
    if (vehicle) {
      if (!canBeAccessedBy(player, vehicle) && vehicle.informations.ownerType !== 'group') return player.outputError(rp.__('NoActionPermission'));
      const result = await unspawn(vehicle);
      if (!result) return player.outputError(rp.__('VehicleNotFound'));

      player.outputInfo(rp.__('player.vehicle.VehicleUnspawned', vehicle.informations.name, vehicleId));
    } else {
      return player.outputTip(`/${command.name} ${this.tooltip}`);
    }
  }
}

module.exports = Unspawn;
