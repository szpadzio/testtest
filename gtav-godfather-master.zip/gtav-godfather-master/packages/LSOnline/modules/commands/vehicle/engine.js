const Command = require('../../structures/Command');
const { isVehicleDriver } = require('../../player/playerMisc');
const { toggleVehicleEngine, canBeAccessedBy } = require('../../vehicles/vehicleService');

class Engine extends Command {
  constructor (...args) {
    super(...args, {
      name: 'engine',
      aliases: ['silnik', 'v silnik']
    });
  }

  run (player, command, args) {
    if (isVehicleDriver(player)) {
      const vehicle = player.vehicle;
      if (!canBeAccessedBy(player, vehicle)) return player.outputError(rp.__('NoActionPermission'));

      return toggleVehicleEngine(vehicle, player);
    }
    return player.outputError(rp.__('player.vehicle.VehicleNotPresentDriver'));
  }
}

module.exports = Engine;
