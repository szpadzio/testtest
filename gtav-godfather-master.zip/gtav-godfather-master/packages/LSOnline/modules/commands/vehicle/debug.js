const Command = require('../../structures/Command');

class Debug extends Command {
  constructor (...args) {
    super(...args, {
      name: 'v debug',
      aliases: ['dl']
    });
  }

  run (player, command, args) {
    player.setVariable('dl', player.getVariable('dl') === undefined ? true : !player.getVariable('dl'));
  }
}

module.exports = Debug;
