const Command = require('../../structures/Command');
const { canBeAccessedBy } = require('../../vehicles/vehicleService');
const { update } = require('../../vehicles/vehicleManager');

class Close extends Command {
  constructor (...args) {
    super(...args, {
      name: 'v zaparkuj',
      aliases: ['v parking', 'veh zaparkuj']
    });
  }

  async run (player, command, args) {
    const vehicle = player.vehicle;
    if (!vehicle) return player.outputError(rp.__('VehicleSpawned'));
    if (!canBeAccessedBy(player, vehicle)) return player.outputError(rp.__('NoActionPermission'));

    vehicle.informations.parking = vehicle.position;
    const result = await update(vehicle.informations.id, { parkingPosition: { position: vehicle.position, rotation: vehicle.rotation } });
    if (result[0]) player.outputInfo(rp.__('player.vehicle.VehicleParked'));
  }
}

module.exports = Close;
