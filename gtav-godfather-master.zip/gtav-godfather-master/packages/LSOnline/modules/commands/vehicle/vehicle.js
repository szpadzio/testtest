const Command = require('../../structures/Command');

class Vehicle extends Command {
  constructor (...args) {
    super(...args, {
      name: 'v',
      aliases: ['v', 'vehicle', 'pojazd'],
      hasSubcommands: true,
      args: []
    });
  }

  async run (player, command, args) {
    player.outputChatBox(JSON.stringify(player.character.vehicles));
  }
}

module.exports = Vehicle;
