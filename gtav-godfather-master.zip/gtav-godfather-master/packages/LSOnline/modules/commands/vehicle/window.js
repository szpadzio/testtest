const Command = require('../../structures/Command');
const { checkIfVehicleModelIsOneWheeler } = require('../../vehicles/vehicleMisc');
class Window extends Command {
  constructor (...args) {
    super(...args, {
      name: 'window',
      aliases: ['szyba', 'v szyba']
    });
  }

  run (player, command, args) {
    if (player.vehicle) {
      const vehicle = player.vehicle;
      if (!vehicle.getVariable('roof')) return;
      if (checkIfVehicleModelIsOneWheeler(vehicle.model)) return;
      player.outputInfo(rp.__('player.vehicle.WindowsToggled'));
      vehicle.setVariable('windows', vehicle.getVariable('windows') === undefined ? true : !vehicle.getVariable('windows'));
    }
  }
}

module.exports = Window;
