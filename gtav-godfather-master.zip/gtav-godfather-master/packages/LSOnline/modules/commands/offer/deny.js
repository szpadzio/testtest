const Command = require('../../structures/Command');
const { offerDeny } = require('../../offers/offerService');

class Offer extends Command {
  constructor (...args) {
    super(...args, {
      name: 'offer deny',
      aliases: ['oferta odrzuc', 'o odrzuc', 'o deny'],
      hasSubcommands: true,
      args: []
    });
  }

  async run (player, command, args) {
    offerDeny(player);
  }
}

module.exports = Offer;
