const Command = require('../../structures/Command');
const { offerAccept } = require('../../offers/offerService');

class Offer extends Command {
  constructor (...args) {
    super(...args, {
      name: 'offer accept',
      aliases: ['oferta akceptuj', 'o akceptuj', 'o accept'],
      hasSubcommands: true,
      args: []
    });
  }

  async run (player, command, args) {
    offerAccept(player);
  }
}

module.exports = Offer;
