const Command = require('../../structures/Command');

class Offer extends Command {
  constructor (...args) {
    super(...args, {
      name: 'offer',
      aliases: ['oferta', 'o'],
      hasSubcommands: true,
      args: []
    });
  }

  async run (player, command, args) {
    player.outputTooltip(`/${command.name} ${this.formatTooltip()}`);
  }
}

module.exports = Offer;
