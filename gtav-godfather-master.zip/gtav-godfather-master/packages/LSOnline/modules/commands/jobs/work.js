const Command = require('../../structures/Command');

class Work extends Command {
  constructor (...args) {
    super(...args, {
      name: 'work',
      aliases: ['praca']
    });
  }

  run (player, command, args) {
    if (!player.colshape || !(player.colshape.isJob && player.colshape.data.job)) return player.outputError(rp.__('player.job.NoMarker'));
    if (player.getVariable('job')) {
      return mp.events.call(`jobFinished:${player.getVariable('job')}`, player);
    }
    switch (player.colshape.data.job) {
      case 'lumberMill':
        mp.events.call('jobStarted:lumberMill', player);
        break;
    }
  }
}

module.exports = Work;
