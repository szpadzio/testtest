'use strict';

const logger = require('../utils/logger');
const database = require('../database/database');
const helpers = require('../utils/helpers');
const ItemFactory = require('../items/itemFactory');
const { canBeBought, createSellLabel } = require('./doorService');

/**
 * Create door inside database with given name.
 * Proceed to spawn them on world.
 *
 * @param {object} player Player as object.
 * @param {string} name Name of the door.
 */
async function createDoor (
  name,
  doorPosition,
  dimension,
  heading,
  ipl = null,
  insidePosition,
  price = null,
  type = 0
) {
  return database.Door.create({
    name,
    owner: null,
    ownerType: null,
    enterPrice: 0,
    price,
    position: JSON.stringify(doorPosition),
    insidePosition: JSON.stringify(insidePosition),
    heading: heading,
    dimension: dimension,
    ipl,
    type,
    insideDimension: await database.Door.max('id') + 1
  })
    .then(door => {
      logger(
        'door',
        `Saved door "${door.name}" (ID: ${door.id}) in database.`,
        'info'
      );
      return spawn(door);
    })
    .catch(e => {
      logger('door', e);
      throw e;
    });
}

exports.createDoor = createDoor;

const createDoorWithPreset = async (preset, name, doorPosition, dimension, heading, price) => {
  try {
    if (!isNaN(preset)) preset = await database.DoorPreset.findByPk(preset);
  } catch (e) {
    logger('door', e);
    throw e;
  }
  if (preset === null) throw Error('Preset was not found', 'ERR_NOT_FOUND');
  return createDoor(
    name,
    doorPosition,
    dimension,
    heading,
    preset.ipl,
    JSON.parse(preset.insidePosition),
    price
  );
};
exports.createDoorWithPreset = createDoorWithPreset;

/**
 * Spawn door on world as marker.
 *
 * @param {object} door Door as object from database.
 */
function spawn (door) {
  if (door.position === null) {
    door.destroy();

    return logger(
      'door',
      `Position of door "${
        door.name
      }" is null, proceeding to destroy this doors.`,
      'error'
    );
  }
  let doorPosition = JSON.parse(door.position);
  const createdDoor = mp.markers.new(
    1,
    new mp.Vector3(doorPosition.x, doorPosition.y, doorPosition.z - 1),
    1,
    {
      visible: true,
      dimension: door.dimension
    }
  );
  configureCreated(createdDoor, door.dataValues);
}

/**
 * Configure newly spawned on world door.
 *
 * @param {object} createdDoor Marker as a door ingame, given as object.
 * @param {object} doorData Door as object from database.
 */
function configureCreated (createdDoor, doorData) {
  try {
    const doorPosition = JSON.parse(doorData.position);
    const doorInsidePosition = JSON.parse(doorData.insidePosition);

    // Configure marker
    createdDoor.scale = rp.constants.doors.markerScale;
    createdDoor.isDoor = true;
    createdDoor.setColor(51, 204, 255, 155);

    // Assign data to marker
    createdDoor.informations = {
      id: doorData.id,
      type: doorData.type,
      name: doorData.name,
      ipl: doorData.ipl,
      price: doorData.price,
      ownerId: doorData.ownerId,
      ownerType: doorData.ownerType,
      enterPrice: doorData.enterPrice,
      audioStream: doorData.audioStream,
      position: doorPosition,
      locked: doorData.locked,
      insidePosition: doorInsidePosition,
      dimension: doorData.dimension,
      insideDimension: doorData.insideDimension
    };

    // Create colshapes for door
    createdDoor.enterColshape = createEnterColshape(createdDoor, doorData);
    createdDoor.exitColshape = createExitColshape(createdDoor, doorData);

    // create trunk
    createdDoor.trunk = doorData.Items ? doorData.Items.map(item => {
      return ItemFactory(item.id, item.type, item.subtype, item.name, JSON.parse(item.extra));
    }) : [];
  } catch (e) {
    logger(
      'door',
      `Error occurred when configuring door "${doorData.name}" (ID: ${
        doorData.id
      }). (Message: ${e})`,
      'error'
    );
  }
}

/**
 * Create enter colshape for door.
 *
 * @param {object} createdDoor Marker as a door ingame, given as object.
 * @param {object} doorData Door as object from database.
 */
function createEnterColshape (createdDoor, doorData) {
  const doorPosition = JSON.parse(doorData.position);
  const enterColshape = mp.colshapes.newSphere(
    doorPosition.x,
    doorPosition.y,
    doorPosition.z,
    rp.constants.doors.markerScale,
    doorData.dimension
  );

  // Configure colshape, assign data
  enterColshape.dimension = doorData.dimension;
  enterColshape.isDoor = true;

  enterColshape.informations = {
    type: 'enter',
    doorMarkerId: createdDoor.id,
    doorId: doorData.id
  };

  enterColshape.setVariable('name', `${doorData.name} (ID: ${createdDoor.id})`);
  if (canBeBought(createdDoor)) {
    enterColshape.setVariable('canBeBought', true);
    enterColshape.label = createSellLabel(createdDoor);
  }
  enterColshape.setVariable('price', doorData.enterPrice);
  enterColshape.setVariable('locked', doorData.locked);

  return enterColshape;
}

/**
 * Create exit colshape for door.
 *
 * @param {object} createdDoor Marker as a door ingame, given as object.
 * @param {object} doorData Door as object from database.
 */
function createExitColshape (createdDoor, doorData) {
  const doorInsidePosition = JSON.parse(doorData.insidePosition);
  const exitColshape = mp.colshapes.newSphere(
    doorInsidePosition.x,
    doorInsidePosition.y,
    doorInsidePosition.z,
    rp.constants.doors.markerScale,
    doorData.insideDimension
  );

  // Configure colshape, assign data
  exitColshape.dimension = doorData.insideDimension;
  exitColshape.isDoor = true;

  exitColshape.informations = {
    type: 'leave',
    doorMarkerId: createdDoor.id,
    doorId: doorData.id
  };

  return exitColshape;
}

/**
 * Load all doors and spawn them on world.
 */
const loadAll = () => {
  return database.Door.findAll({ include: [database.Item] }).then(doors => {
    for (let i = 0; i < doors.length; i++) {
      spawn(doors[i]);
    }
    return true;
  });
};

exports.loadAll = loadAll;

exports.updateInterior = updateInterior;

/**
 * Update door interior.
 *
 * @param {integer} doorId Door ID in database.
 * @param {string} interior Interior name (look at IPL list).
 */
function updateInterior (doorId, markerId, interior) {
  return database.Door.findByPk(doorId)
    .update({ ipl: interior })
    .then(door => {
      logger(
        'door',
        `Changed door "${door.name}" (ID: ${door.id}) interior to "${
          door.ipl
        }".`,
        'info'
      );
      return door;
    })
    .then(door => {
      mp.markers.at(markerId).informations.ipl = interior;
      return door;
    })
    .catch(err => {
      logger(
        'door',
        `Error occurred when changing door interior (ID: ${
          doorId
        }). (Message: ${err})`,
        'error'
      );
      throw err;
    });
}

exports.updateName = updateName;

/**
 * Update door name.
 *
 * @param {integer} doorId Door ID in database.
 * @param {string} name Door name
 */
function updateName (doorId, markerId, name) {
  return database.Door.update({ name }, { where: { id: doorId } })
    .then(door => {
      logger(
        'door',
        `Changed door name (ID: ${doorId}) to "${
          name
        }".`,
        'info'
      );
      return door;
    })
    .then(door => {
      mp.markers.at(markerId).enterColshape.setVariable('name', `${name} (ID: ${markerId})`);
      mp.markers.at(markerId).informations.name = name;

      return door;
    })
    .catch(err => {
      logger(
        'door',
        `Error occurred when changing door name (ID: ${
          doorId
        }). (Message: ${err})`,
        'error'
      );
      throw err;
    });
}

async function updateAudioStream (doorId, url) {
  console.log(await helpers.fetchAudioStream(url));
}

exports.updateAudioStream = updateAudioStream;

/**
 * Update door enter price.
 *
 * @param {integer} doorId Door ID in database.
 * @param {integer} enterPrice Enter price.
 */
function updateEnterPrice (doorId, markerId, enterPrice) {
  database.Door.findByPk(doorId)
    .update({ enterPrice: enterPrice })
    .then(door => {
      logger(
        'door',
        `Changed door "${door.name}" (ID: ${door.id}) enter price to $"${
          door.enterPrice
        }".`,
        'info'
      );
      mp.markers.at(markerId).informations.enterPrice = enterPrice;
      return door;
    })
    .catch(err => {
      logger(
        'door',
        `Error occurred when changing door enter price (ID: ${
          doorId
        }). (Message: ${err})`,
        'error'
      );
      throw err;
    });
}

exports.updateEnterPrice = updateEnterPrice;

/**
 * Get closest door for player.
 *
 * @param {object} player Player as object.
 * @param {integer} range Range.
 */
function getClosestDoorForPlayer (player, range) {
  let foundDoor = null;

  mp.colshapes.forEachInRange(player.position, range, player.dimension, door => {
    foundDoor = door;
  });

  return foundDoor;
}

exports.getClosestDoorForPlayer = getClosestDoorForPlayer;

function getDoorPresets () {
  return database.DoorPreset.findAll({ raw: true });
}

exports.getDoorPresets = getDoorPresets;

/**
 * Assign door to owner.
 *
 * @param {integer} doorId door ID.
 * @param {string} ownerType Owner type (character | group)
 * @param {integer} owner Owner ID.
 */
exports.assign = (doorId, ownerType, ownerId, markerId) => {
  return database.Door.update({ ownerId, ownerType }, { where: { id: doorId } })
    .then((door) => {
      logger('door', `Assigned door door (ID: ${doorId}) to ${ownerType} (ID: ${ownerId}).`, 'info');
      door = mp.markers.at(markerId);
      door.informations.ownerType = ownerType;
      door.informations.ownerId = ownerId;
      if (door.enterColshape.label && mp.labels.exists(door.enterColshape.label)) mp.labels.at(door.enterColshape.label.id).destroy();
      return door;
    })
    .catch((err) => {
      logger('door', `Error occurred when assigning door (ID: ${doorId}) to ${ownerType} (ID: ${ownerId}). (${err}, ${err.stack})`, 'error');
      throw err;
    });
};

/**
 * Remove door from database.
 *
 * @param {integer} doorId door ID.
 */
exports.remove = function remove (doorId, markerId) {
  let door;
  return database.Door.destroy({ where: { id: doorId } })
    .then(() => {
      const marker = mp.markers.at(markerId);
      if (marker.enterColshape.label) marker.enterColshape.label.destroy();
      marker.enterColshape.destroy();
      marker.exitColshape.destroy();
      marker.destroy();
      logger('door', `Removed door ${marker.informations.name} (ID: ${doorId}) from database.`, 'info');
      return door;
    })
    .catch((err) => {
      logger('door', `Error occurred when removing door (ID ${doorId}). (Message: ${err})`, 'error');
      throw err;
    });
};

exports.moveEnterDoor = (doorId, markerId, position) => {
  return database.Door
    .update({
      position: JSON.stringify(position.position),
      dimension: position.dimension
    },
    { where: { id: doorId } })
    .then(door => {
      const marker = mp.markers.at(markerId);
      marker.position = new mp.Vector3(position.position.x, position.position.y, position.position.z - 1);
      marker.informations.position = { x: position.position.x, y: position.position.y, z: position.position.z };
      marker.dimension = marker.informations.dimension = position.dimension;
      marker.enterColshape.label.destroy();
      marker.enterColshape.destroy();
      marker.enterColshape = createEnterColshape({ id: markerId }, { ownerId: marker.informations.ownerId, ownerType: marker.informations.ownerType, id: marker.informations.id, name: marker.informations.name, locked: marker.informations.locked, enterPrice: marker.informations.enterPrice, position: JSON.stringify(position.position), dimension: position.dimension });
      return door;
    })
    .catch(err => {
      logger('door', `Error occurred when moving door enter (ID ${doorId}). (Message: ${err})`, 'error');
      throw err;
    });
};

exports.moveExitDoor = (doorId, markerId, position) => {
  return database.Door
    .update({
      insidePosition: JSON.stringify(position.position),
      insideDimension: position.dimension,
      ipl: position.ipl
    },
    { where: { id: doorId } })
    .then(door => {
      const marker = mp.markers.at(markerId);
      marker.informations.insidePosition = { x: position.position.x, y: position.position.y, z: position.position.z };
      marker.informations.insideDimension = position.dimension;
      marker.informations.ipl = position.ipl;
      marker.exitColshape.destroy();
      marker.exitColshape = createExitColshape({ id: markerId }, { ownerId: marker.informations.ownerId, ownerType: marker.informations.ownerType, id: marker.informations.id, name: marker.informations.name, locked: marker.informations.locked, enterPrice: marker.informations.enterPrice, insidePosition: JSON.stringify(position.position), insideDimension: position.dimension });
      return door > 0;
    })
    .catch(err => {
      logger('door', `Error occurred when moving door exit (ID ${doorId}). (Message: ${err})`, 'error');
      throw err;
    });
};
