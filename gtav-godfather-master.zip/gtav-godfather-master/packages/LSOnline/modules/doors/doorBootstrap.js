'use strict';

const logger = require('../utils/logger');
const { loadAll } = require('./doorManager');

const boot = async () => {
  await loadAll();
  logger('server', `Successfully bootstrapped doors!`, 'info');
};

exports.boot = boot;
