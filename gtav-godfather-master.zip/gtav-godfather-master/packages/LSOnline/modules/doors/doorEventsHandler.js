const { enterDoor, leaveDoor } = require('./doorService');

mp.events.add({
  playerEnterColshape: (player, shape) => {
    if (shape.isDoor && shape.informations.doorId) {
      // Assign data to player
      player.lastEnteringDoor = shape;
      player.data.inFrontOfDoors = true;
    } else {
      player.colshape = shape;
    }
  },

  playerExitColshape: (player, shape) => {
    if (shape.isDoor && shape.informations.doorId) {
      player.lastEnteringDoor = null;
      player.data.inFrontOfDoors = false;
    } else {
      player.colshape = null;
    }
  },

  keyE: player => {
    if (player.data.inFrontOfDoors) {
      if (player.lastEnteringDoor) {
        let door = player.lastEnteringDoor;
        let marker = mp.markers.at(door.informations.doorMarkerId);

        if (marker && marker.informations.locked && door.informations.type === 'leave') return player.call('actionDone', ['Drzwi są zamknięte']);
        if (!marker || marker.informations.locked) return;
        door.informations.type === 'enter'
          ? enterDoor(player, marker)
          : leaveDoor(player, marker);
      }
    }
  }
});
