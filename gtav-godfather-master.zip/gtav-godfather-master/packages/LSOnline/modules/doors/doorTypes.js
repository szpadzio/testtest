// 0 -> brak
// 1 -> mieszkalny
