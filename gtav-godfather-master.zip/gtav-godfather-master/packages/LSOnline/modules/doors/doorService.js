'use strict';

const {
  checkPlayerCash,
  pushHelpMessage,
  removeCashFromPlayer
} = require('../player/playerService');

/**
 * Enter door as player.
 *
 * @param {object} player Player as object.
 * @param {object} door Door as object.
 */
const enterDoor = (player, door, vehicle = null) => {
  if (door) {
    if (
      door.informations.insidePosition &&
      door.informations.insideDimension
    ) {
      if (door.informations.enterPrice > 0) {
        if (!checkPlayerCash(player, door.informations.doorEnterPrice)) {
          return pushHelpMessage(
            player,
            `Aby wejść do tego budynku musisz posiadać $${
              door.informations.doorEnterPrice
            }!`
          );
        }

        removeCashFromPlayer(player, door.informations.doorEnterPrice);
      }
      if (door.informations.ipl) {
        player.call('loadIpl', [door.informations.ipl]);
      }
      //  rpc.callBrowsers(player, 'setAudioStream', door.informations.audioStream);
      if (vehicle) {
        vehicle.position = new mp.Vector3(door.informations.insidePosition.x, door.informations.insidePosition.y, door.informations.insidePosition.z);
        player.call('teleportVehicleToPos');
      } else {
        player.position = new mp.Vector3(door.informations.insidePosition.x, door.informations.insidePosition.y, door.informations.insidePosition.z);
      }
      player.door = door;
      player.dimension = door.informations.insideDimension;
    }
  }
};

exports.enterDoor = enterDoor;

/**
 * Leave door as player.
 *
 * @param {object} player Player as object.
 */
const leaveDoor = (player, door, vehicle = null) => {
  if (door) {
    player.dimension = door.informations.dimension;
    if (vehicle) {
      player.call('teleportVehicleToPos', [door.informations.position.x, door.informations.position.y, door.informations.position.z]);
    } else {
      player.position = door.informations.position;
    }
    player.call('unloadIpl', [door.informations.ipl]);
    if (door.informations.dimension !== 0) {
      if (door.informations.ipl) player.call('loadIpl', [door.informations.ipl]);
      player.door = door;
    }
    // Clear info about door for player.
    // clearCurrentDoorInfo(player);
  }
};

exports.leaveDoor = leaveDoor;

/**
 * Clear last entering door info for player.
 *
 * @param {object} player Player as object.
 */
const clearDoorInfo = player => {
  player.lastEnteringDoor = null;
  player.door = null;

  player.inFrontOfDoors = false;
};

exports.clearDoorInfo = clearDoorInfo;

exports.canBeAccessedBy = (player, door) => {
  if (!door) return false;

  if (door.informations.ownerType === 'group') {
    return player.character.groups.find(_group => _group.id === door.informations.ownerId) !== undefined;
  }
  if (door.informations.ownerType === 'character') {
    return door.informations.ownerId === player.character.info.id ? 'owner' : false;
  }
  return false;
};

exports.canBeBought = (door) => {
  return door.informations.ownerId === null && door.informations.price > 0;
};

const createSellLabel = (door) => {
  return mp.labels.new(`(( ~h~ Możesz ~g~ zakupić ~w~ tą posiadłość za $${door.informations.price}. /zamieszkaj ))`, { ...door.position, z: door.position.z + 0.5 },
    {
      los: true,
      font: 1,
      drawDistance: 5,
      color: [255, 255, 255, 255],
      dimension: door.dimension
    });
};
exports.createSellLabel = createSellLabel;

const toggleDoor = (door, state) => {
  state = state ? state : !door.informations.locked;
  door.informations.locked = state;
  door.enterColshape.setVariable('locked', state);
};
exports.toggleDoor = toggleDoor;
