'use strict';

const { stopPlayingAnimation } = require('../player/playerService');

mp.events.add({
  keyDeleteButton: player => stopPlayingAnimation(player)
});
