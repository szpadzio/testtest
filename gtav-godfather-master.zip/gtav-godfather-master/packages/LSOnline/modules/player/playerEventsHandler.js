'use strict';

const queues = require('../../api/queue/queues');
const { validateText } = require('../utils/helpers');
const { setBrutallyWounded, prepareBeforeQuit, createQuitLabel } = require('../player/playerService');
const { checkIfPlayerHaveCharacterInstance, checkIfPlayerIsBrutallyWounded } = require('../player/playerMisc');

mp.events.add({
  playerQuit: async (player, exitType, reason) => {
    // createQuitLabel(player, exitType);
    await prepareBeforeQuit(player, exitType);
  },
  playerDeath: (player, reason, killer) =>
    setBrutallyWounded(player, reason, killer),

  playerCommand: (player, command) => {
    const args = command.split(/[ ]+/);
    const commandName = args.splice(0, 1)[0].toLowerCase();
    if (!mp.players.exists(player)) { return false; }

    let subCommand = '';
    let result = rp.commands.get(commandName);

    // Check if player have character instance.
    if (!checkIfPlayerHaveCharacterInstance(player, true)) return;

    // Check if command exists.
    if (!result) {
      return player.call('actionDone', [
        'Podana komenda nie istnieje'
      ]);
    }

    // Check for sub commands.
    if (result.hasSubcommands) {
      if (args.length > 0) {
        subCommand = rp.commands.get(commandName + ' ' + args[0].toLowerCase());
      }

      if (subCommand) {
        result = subCommand;
        subCommand = args.splice(0, 1);
      }
    }

    // If player have BW or something.
    if (player.brutallyWounded && result.restriction) {
      return player.call('actionDone', [
        'Twoja postać jest nieprzytomna lub wyciszona!'
      ]);
    }
    const filteredArgs = result.args.filter(a => a.search('\\*') === -1);
    if (filteredArgs.length > 0 && args.length < filteredArgs.length) {
      return player.call('actionDone', [
        `Coś poszło nie tak! Użycie: /${commandName} ${subCommand} ${result.tooltip}`
      ]);
    }
    result.run(
      player,
      {
        name: subCommand ? `${commandName} ${subCommand}` : commandName,
        fullText: args.join(' '),
        args
      },
      args
    );
  },

  playerChat: (player, text) => {
    if (!checkIfPlayerHaveCharacterInstance(player, true)) return;
    // Check if player have character instance.

    // Check if player is brutally wounded.
    checkIfPlayerIsBrutallyWounded(player, true);

    // Validate text.
    if (!validateText(text)) {
      return player.call('actionDone', [
        'Użyłeś niedozwolonych znaków na czacie.'
      ]);
    }

    if ((text[0] === '!' || text[0] === '@') && !isNaN(text[1])) {
      const ooc = text[0] === '@';
      const numberPattern = /\d+/g;
      text = text.split(' ');
      const matches = text[0].match(numberPattern);
      if (!matches) {
        return;
      }
      const slot = Number(matches[0]);
      text.splice(0, 1);
      text = text.join(' ');
      if (ooc) {
        return rp.commands.get('sayGroupOOC').run(player, {
          fullText: text
        }, slot);
      }
      rp.commands.get('sayGroup').run(player, { fullText: text }, slot);
      return;
    }
    // Run command 'say'.
    rp.commands.get('say').run(player, { fullText: text }, false);
  },

  playedHour: (player) => {
    rp.timers.getTimer(player, 'fullHour').reset(1000 * 60 * 60, true);
    queues['payday']
      .createJob({
        character: player.character.info,
        groups: player.character.groups,
        player
      })
      .save()
      .then((job) => {
        job.on('succeeded', (result) => {
          if (!player) return;
          player.outputChatBox(`!{green}=== Twoja postać otrzymuje wypłatę. ===`);
          player.outputChatBox(`!{yellow}> Przychód:`);
          player.outputChatBox(`!{green}>> Wypłata: $100`);
          if (result.group) player.outputChatBox(`!{green}>> Wypłata: $${result.salaryAmount - 100} z grupy ${result.group.name}`);
          if (result.isGroupInDebt) player.outputChatBox(`!{yellow}>> Twoja grupa jest niewypłacalna, więc otrzymujesz mniej pieniędzy.`);
          player.outputChatBox(`!{yellow}> Podatki:`);
          player.outputChatBox(`!{red}>> Nieruchomości: $0`);
          player.outputChatBox(`!{red}>> Od wypłaty: $14`);

          player.setVariable('bank', player.getVariable('bank') + result.salaryAmount);
        });
        return true;
      })
      .catch((e) => {
        console.log(e);
      });
  },

  runCommand: (player, command, ...args) => {
    command = rp.commands.get(command);
    if (command) command.run(player, null, args);
  }
});
