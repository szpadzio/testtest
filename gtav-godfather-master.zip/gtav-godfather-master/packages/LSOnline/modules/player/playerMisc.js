'use strict';

/**
 * Check if player is vehicle driver.
 *
 * @param {object} player Player object.
 */
const isVehicleDriver = (player) => {
  if (!player.vehicle || player.seat !== 0) {
    return false;
  }

  return true;
};

exports.isVehicleDriver = isVehicleDriver;

/**
 * Check if player have character instance - kick if not.
 *
 * @param {object} player Player object.
 * @param {bool} kick Kick player if he dont have character instance.
 */
const checkIfPlayerHaveCharacterInstance = (player, kick) => {
  if (!mp.players.exists(player)) { return false; }
  if (!player.character) {
    if (kick) {
      console.log('proc:' + player.hasPendingProc('server:authorizePlayer'));
      // player.kick();
      return false;
    }

    return false;
  }

  return true;
};

exports.checkIfPlayerHaveCharacterInstance = checkIfPlayerHaveCharacterInstance;

/**
 * Check if player is brutally wounded.
 *
 * @param {object} player Player object.
 * @param {bool} notification Send notification.
 */
const checkIfPlayerIsBrutallyWounded = (player, notification) => {
  if (player.brutallyWounded) {
    if (notification) {
      return player.call('actionDone', ['Nie możesz tego teraz zrobić!', 'Twoja postać jest nieprzytomna!']);
    }

    return true;
  }

  return false;
};

exports.checkIfPlayerIsBrutallyWounded = checkIfPlayerIsBrutallyWounded;
