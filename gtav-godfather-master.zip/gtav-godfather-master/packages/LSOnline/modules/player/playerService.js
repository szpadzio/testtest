'use strict';

const brutallyWoundedTime = 20000; // Move this to server config or something.
const Timer = require('../structures/Timer');
const { getDeathReason } = require('../player/playerData');
const { checkIfPlayerHaveCharacterInstance, checkIfPlayerIsBrutallyWounded } = require('../player/playerMisc');

/**
 * Set player in brutally wounded status.
 *
 * @param {object} player Player object.
 * @param {string} reason Reason.
 * @param {object} killer Killer player object.
 */
const setBrutallyWounded = (player, reason, killer) => {
  if (player.brutallyWoundedTimer) {
    clearBrutallyWoundedTimers(player);
  }

  // Remove all weapons, set brutally wounded status with timer.
  player.removeAllWeapons();
  player.brutallyWounded = true;
  player.brutallyWoundedTimer = setTimeout(
    reviveFromBrutallyWounded,
    brutallyWoundedTime,
    player
  );

  // Run command for world.
  rp.commands.get('me').run(player, { fullText: `traci przytomność.` });
};

exports.setBrutallyWounded = setBrutallyWounded;

/**
 * Revive player from brutally wounded status.
 *
 * @param {object} player Player object.
 * @param {bool} fromMedic If he was revived from medic or normally.
 */
const reviveFromBrutallyWounded = (player, fromMedic = false) => {
  clearBrutallyWoundedTimers(player);
  clearDescription(player);

  // Spawn player, set HP based from who he was revived.
  spawnPlayer(player);
  fromMedic ? setHealth(player, 30) : setHealth(player, 20);
};

exports.reviveFromBrutallyWounded = reviveFromBrutallyWounded;

/**
 * Clear brutally wounded timers.
 *
 * @param {object} player Player object.
 */
const clearBrutallyWoundedTimers = (player) => {
  player.brutallyWounded = false;

  // Clear timers.
  clearTimeout(player.brutallyWoundedTimer);
  player.brutallyWoundedTimer = null;
};

exports.clearBrutallyWoundedTimers = clearBrutallyWoundedTimers;

/**
 * Set player health.
 *
 * @param {object} player Player object.
 * @param {float} health Health.
 */
const setHealth = (player, health) => {
  player.health = health;
};

exports.setHealth = setHealth;

/**
 * Kill player.
 *
 * @param {object} player Player object.
 */
const killPlayer = (player) => {
  player.health = 0;
};

exports.killPlayer = killPlayer;

/**
 * Spawn player.
 *
 * @param {object} player Player object.
 */
const spawnPlayer = (player) => {
  player.spawn(player.position);
};

exports.spawnPlayer = spawnPlayer;

/**
 * Clear player description.
 *
 * @param {object} player Player object.
 */
const clearDescription = (player) => {
  player.outputChatBox(`!{#dddddd} Opis postaci został pomyślnie usunięty.`);
  player.setVariable('description', null);
};

exports.clearDescription = clearDescription;

/**
 * Prepare player before quit.
 *
 * @param {object} player Player object.
 * @param string exitType Exit type.
 */
const prepareBeforeQuit = async (player, exitType) => {
  // Check if player have character instance.
  if (!checkIfPlayerHaveCharacterInstance(player, false)) return;

  // Clear timers for entity.
  rp.timers.clearTimersForEntity(player);

  // Clear brutally wounded timers.
  clearBrutallyWoundedTimers(player);

  player.character.inventory.syncItems();

  // If this was timeout from player and he was in vehicle, save last position of this vehicle to put him back when he goes back.
  let vehicle = player.vehicle;
  player.vehicle ? vehicle = { id: vehicle.informations.id, seat: player.seat } : vehicle = null;

  // Save player before quit.
  return player.character.saveBeforeQuit(player, vehicle, exitType);
};

exports.prepareBeforeQuit = prepareBeforeQuit;

/**
 * Create quit label.
 *
 * @param {object} player Player object.
 * @param {string} exitType exit type.
 */
const createQuitLabel = (player, exitType) => {
  if (!checkIfPlayerHaveCharacterInstance(player, false)) return;
  // Check if player have character instance.

  // Check if player have quitLabel already assigned.
  if (!player.quitLabel) {
    player.quitLabel = mp.labels.new(
      `~HUD_COLOUR_GREYLIGHT~ (( ${player.name} - ${exitType} ))`,
      new mp.Vector3(player.position.x, player.position.y, player.position.z),
      {
        los: true,
        font: 0,
        drawDistance: 10,
        dimension: player.dimension
      }
    );
  }

  // This need to be rewrited when we gonna create labels manager.
  setTimeout(() => {
    if (player.quitLabel) {
      player.quitLabel.destroy();
    }
  }, 40000);
};

exports.createQuitLabel = createQuitLabel;

/**
 * Stop playing animation.
 *
 * @param {object} player Player object.
 */
const stopPlayingAnimation = player => {
  const isPlayerBrutallyWounded = checkIfPlayerIsBrutallyWounded(player);

  if (isPlayerBrutallyWounded) {
    player.stopAnimation();
    player.isPlayingAnimation = false;
  }
};

exports.stopPlayingAnimation = stopPlayingAnimation;

/**
 * Check player cash.
 *
 * @param {object} player Player as object.
 * @param {integer} cash Amount of cash to check.
 */
const haveEnoughCash = (player, cash) => {
  if (isNaN(player.data.money)) return false;
  return player.data.money >= cash;
};

exports.haveEnoughCash = haveEnoughCash;

/**
 * Remove cash from player.
 *
 * @param {object} player Player as object.
 * @param {integer} cash Amount of cash to take from player.
 */
const removeCashFromPlayer = (player, cash) => {
  player.data.money = player.data.money - Math.abs(cash);
};

exports.removeCashFromPlayer = removeCashFromPlayer;

const checkIfPlayerBelongsToGroupWithPermissions = (player, permissions = []) => {
  return player.character.groups.filter(_g => {
    const _gG = _g.getGlobalGroup();
    for (let i = 0; i < permissions.length; i++) {
      console.log(_gG, permissions[i]);
      return _gG.permissions[permissions[i]] === true;
    }
  }).length > 0;
};

exports.checkIfPlayerBelongsToGroupWithPermissions = checkIfPlayerBelongsToGroupWithPermissions;
