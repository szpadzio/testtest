class TimerPool {
  constructor () {
    this.timers = {
      none: new Map(),
      player: new Map()
    };
  }

  getTimer (entity, timerName, entityName = entity.name) {
    const type = entity.type || 'none';

    if (!timerName) throw new Error('times has to be named');

    return this.timers[type].get(entityName)[timerName];
  }

  pushTimerForEntity (entity, timer, entityName = entity.name) {
    const type = entity.type || 'none';

    if (!this.timers[type]) this.timers[type] = new Map();

    const collection = this.timers[type].get(entityName);
    if (!collection) this.timers[type].set(entityName, {});

    this.timers[type].get(entityName)[timer.name] = timer;
  }

  clearTimersForEntity (entity, entityName = entity.name) {
    const type = entity.type || 'none';

    if (!this.timers[type]) return false;

    const timers = this.timers[type].get(entity.name);
    if (!timers) return false;
    console.log('debug', timers);
    for (const timer of timers) {
      timer.destroy();
    }

    return this._clearEntity(entity);
  }

  _clearEntity (entity, entityName = entity.name) {
    const type = entity.type || 'none';

    return this.timers[type].delete(entityName);
  }
}

module.exports = TimerPool;
