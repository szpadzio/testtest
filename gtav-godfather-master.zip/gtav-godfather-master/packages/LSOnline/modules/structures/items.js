const itemList = require('../items/itemList.json');

/**
 * Generic class to Extend
 *
 * @class Item
 */
exports.Item = class Item {
  constructor (uid, name = '', type = null, subtype = null, extra = {}) {
    this.id = uid;
    this.name = name;
    this.type = type;
    this.subtype = subtype;
    this.destroyAfterUse = false;
    if (extra.amount) this.amount = extra.amount;
  }

  /**
   * Get basic name
   *
   * @returns
   * @memberof Item
   */
  getName () {
    if (this.name) return this.name;
    if (itemList[this.type].hasOwnProperty('name')) return itemList[this.type].name;
    if (itemList[this.type][this.subtype] && itemList[this.type][this.subtype].hasOwnProperty('name')) return itemList[this.type][this.subtype].name;
    return this.subtype || this.type;
  }

  /**
   * Get descriptom from JSON file about item
   *
   * @returns
   * @memberof Item
   */
  getDescription () {
    return itemList[this.type].description || itemList[this.type][this.subtype].description || ' ';
  }

  /**
   * Method to get formatted name (ex. some items can have ammo amount in name and such)
   *
   * @returns {}
   * @memberof Item
   */
  getFormattedName () {
    return `${this.getName()}`.trim();
  }

  /**
   * Get extra parameters about item
   *
   * @returns
   */
  getExtras () {
    return {};
  }

  /**
   * Sync in-game state (ex. ammo) to item object, ex. before save
   *
   * @returns
   */
  sync () {
    return null;
  }

  /**
   * Logic on use
   *
   * @param {mp.Player} player
   * @returns
   */
  _onUse (player) {
    return null;
  }
};

exports.Weapon = class Weapon extends exports.Item {
  constructor (uid, name = '', type = null, subtype = null, extra = {}) {
    super(...arguments);
    this.model = itemList[this.type][this.subtype].model;
    this.hash = parseInt(itemList[this.type][this.subtype].hash, 16) || mp.joaat(this.model);
    this.ammo = extra.ammo || 30;
    this.attachments = extra.attachments || null;
  }

  getExtras () {
    return { ammo: this.ammo, attachments: this.attachments };
  }

  _onUse (player, emitAction = true) {
    this._inUse = true;
    player.giveWeapon(this.hash, 0);
    player.setWeaponAmmo(this.hash, this.ammo);

    if (emitAction) rp.commands.get('ame').run(player, { fullText: `wyciąga ${this.getFormattedName()}` });
    return true;
  }

  _onDisuse (player) {
    this._inUse = false;
    this.sync(player);
    player.removeWeapon(this.hash);
    rp.commands.get('ame').run(player, { fullText: `chowa ${this.getFormattedName()}` });
    return true;
  }

  async sync (player) {
    const ammo = player.getWeaponAmmo(this.hash);
    this.ammo = this.ammo - Math.abs(ammo - this.ammo);
    return this.ammo;
  }
};

exports.Watch = class Watch extends exports.Item {
  constructor (uid, name = '', type = null, subtype = null, extra = {}) {
    super(...arguments);
  }

  _onUse (player) {
    rp.commands.get('ame').run(player, { fullText: `patrzy na ${this.getFormattedName()}` });
    player.outputChatBox(`Obecnie jest godzina ${new Date().toLocaleTimeString()}.`);
    return true;
  }
};

exports.Mask = class Mask extends exports.Item {
  constructor (uid, name = '', type = null, subtype = null, extra = {}) {
    super(...arguments);
    this.drawable = extra.drawable || itemList[this.type].drawable;
    this.durability = extra.durability || itemList[this.type].durability || 1;
  }

  _onUse (player) {
    this._inUse = true;

    rp.commands.get('ame').run(player, { fullText: `zakłada maskę.` });

    player.name = 'Zamaskowany ' + player.character.info.uuid.slice(0, 4).toUpperCase();
    player.setClothes(1, this.drawable, 0, 2);

    rp.logger.emit('mask:used', player);
    return true;
  }

  _onDisuse (player) {
    this._inUse = false;

    rp.commands.get('ame').run(player, { fullText: `ściąga maskę.` });

    player.name = player.character.info.name;
    player.setClothes(1, 0, 0, 2);

    rp.logger.emit('mask:disused', player);
    return true;
  }
};

exports.Drug = class Drug extends exports.Item {
  constructor (uid, name = '', type = null, subtype = null, extra = {}) {
    super(...arguments);
    this.amount = extra.amount || 0;
  }

  getExtras () {
    return { amount: this.amount };
  }

  getFormattedName () {
    return `${this.getName()} (${this.amount}g)`;
  }

  _onUse (player) {
    player.health += this.effect;
    player.call('drugUsed', [itemList[this.type][this.subtype].vision, itemList[this.type][this.subtype].duration]);
    this.amount -= 1;

    rp.commands.get('ame').run(player, { fullText: `zażywa ${this.getName()}.` });
    player.outputChatBox('!{yellow} Doznajesz euferycznego kopa energii. Twoje serce przyśpiesza, jesteś bardziej skupiony. Niestety ten błogi stan trwa krótko, za kilkanaście minut twoja energia zniknie, a twój mózg wraz z ciałem zatęskni za kolejną dawką dopaminy i cracku.');
    return true;
  }
};

exports.Container = class Container extends exports.Item {
  constructor (uid, name = '', type = null, subtype = null, extra = {}, items = []) {
    super(...arguments);
    this.capacity = itemList[this.type][this.subtype].capacity;
    this._items = items;
  }

  _onUse (player) {
    rpc.callBrowsers(player, 'setNearbyItems', [true, this._items.map(_item => Object({ id: _item.id, name: _item.getFormattedName(), type: 'container', parent: this.id })), this.id]);
  }

  contains (item) {
    if (typeof item === 'number') {
      return this._items.find(_item => _item.id === item);
    }
  }

  pickup (player, item) {
    if (item.id === this.id) return player.call('Coś poszło nie tak');
    const index = this._items.indexOf(item);
    this._items.splice(index, 1);

    this._onUse(player);

    rp.commands.get('ame').run(player, { fullText: `wyciąga ${item.getFormattedName()} z torby.` });
    player.character.inventory.pushItem(item);
  }

  add (player, Item) {
    this._items.push(Item);
    rpc.callBrowsers(player, 'setNearbyItems', [true, this._items.map(_item => Object({ id: _item.id, name: _item.getFormattedName(), type: 'container', parent: this.id })), this.id]);
  }
};
