class Outfit {
  constructor (data) {
    this.name = data.name;
    this.model = data.model;

    Object.assign(this, JSON.parse(data.data));
  }
}

module.exports = Outfit;
