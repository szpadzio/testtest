const DroppedItem = require('./DroppedItem');
const items = require('./Items');

const ItemFactory = require('../items/itemFactory');
const itemManager = require('../items/itemManager');
const { InventoryError } = require('../structures/Errors');

module.exports = class Inventory {
  constructor (player, items = []) {
    this._player = player;
    this._items = [];
    this._itemsInUse = new Set();

    for (const item of items) {
      this.pushItem(item);
    }

    // this.setFront();
  }

  pushItem (Item) {
    this._player.call('client:item:pushItem', [format(Item)]);

    return this._items.push(Item);
  }

  popItem (Item) {
    const index = this._items.indexOf(Item);
    this._player.call('client:item:popItem', [format(Item), index]);

    return this._items.splice(index, 1);
  }

  deleteItem (Item) {

  }

  async syncItems () {
    const array = [];
    for (const item of this._itemsInUse) {
      array.push(item.sync(this._player));
    }
    return Promise.all(array);
  }

  use (index, ...args) {
    try {
      if (typeof this._items[index] === 'undefined') throw new Error('Index out of range', 'ERR_ITEM_INDEX');

      const item = this._items[index];

      if (item._inUse) {
        item._onDisuse(this._player, ...args);
        this._player.call('client:item:updateItem', [format(item), index]);
      } else {
        if (item.type === 'weapon' && this._player.allWeapons.hasOwnProperty(item.hash)) {
          throw new Error('Player has already this weaponhash in use', 'ERR_ITEM_DUPLICATEHASH');
        }

        item._onUse(this._player, ...args);
        this._player.call('client:item:updateItem', [format(item), index]);
        if (item.amount && item.amount <= 0) this.popItem(item);
      }
    } catch (err) {
      switch (err.message) {
        case 'Index out of range': {
          this._player.notify(rp.__('player.inventory.WrongIndex'));
          break;
        }
        case 'Player has already this weaponhash in use': {
          this._player.notify(rp.__('player.inventory.NotUsedDuplicate'));
          break;
        }
      }
    }
    return true;
  }

  async drop (index, container) {
    try {
      if (container) index = this._items.findIndex(_item => _item.id === index.id);
      if (typeof this._items[index] === 'undefined') throw new Error('Index out of range', 'ERR_ITEM_INDEX');
      const item = this._items[index];
      if (item.frozen) return;

      if (item._inUse) this.use(index);
      this.popItem(item);

      if (container && item.type !== 'container') {
        const containerItem = this._items.find(_item => _item.id === container);
        if (!containerItem) return;

        itemManager.putToContainer(item, containerItem);
        containerItem.add(this._player, item);
        rp.commands.get('ame').run(this._player, { fullText: rp.__('actions.PutsAwayBag', this.getFormattedName()) });
      } else if (this._player.vehicle) {
        this._player.vehicle.trunk.push(item);

        itemManager.putToVehicle(item, this._player.vehicle);
        rp.commands.get('ame').run(this._player, { fullText: rp.__('actions.PutsAwayVehicle', this.getFormattedName()) });
      } else {
        let ground = await this._player.callProc('client:getGroundCoords', [this._player.position.x, this._player.position.y, this._player.position.z]);

        rp.droppedItems[item.id] = new DroppedItem(item.id, item.name, item.type, item.subtype, item.getExtras(),
          { x: this._player.position.x, y: this._player.position.y, z: ground }, this._player.dimension, this._player.heading);
        itemManager.putOnGround(rp.droppedItems[item.id]);

        rp.commands.get('ame').run(this._player, { fullText: rp.__('actions.PutsAway', this.getFormattedName()) });
      }
    } catch (err) {
      switch (err.message) {
        case 'Index out of range': {
          this._player.notify(rp.__('player.inventory.WrongIndex'));
          break;
        }
      }
    }
  }

  pickup (item) {
    try {
      if (!item) throw new Error('No item', 'ERR_NO_ITEM');

      if (item instanceof DroppedItem) item.destroy();
      itemManager.pickupItem(item, this._player.character.info.id);

      rp.commands.get('ame').run(this._player, { fullText: rp.__('actions.PicksUp', this.getFormattedName()) });
      return this.pushItem(ItemFactory(item.id, item.type, item.subtype, item.name, item.extra));
    } catch (err) {
      this._player.notify(rp.__('UnknownError'));
    }
  }

  async save () {
    await this.syncItems();
    return itemManager.bulkUpdate(this._items.map(_i =>
      Object.assign(_i, { extra: _i.getExtras(), ownerType: 'character', ownerId: this._player.character.info.id })));
  }

  transferToPlayer (target, Item) {
    if (Item instanceof items.Item === false) throw new Error('Is not item', 'ERR_ITEM_INSTANCE');

    const item = this._items.find(_item => _item === Item);
    if (!item) throw new Error('Item missing', 'ERR_NO_ITEM');

    itemManager.transferItem(item, target.character.info.id);

    this.popItem(item);
    target.character.inventory.pushItem(item);

    item.frozen = false;

    return item;
  }

  accept (item) {
    itemManager.transferItem(item);

    item.frozen = false;

    return true;
  }

  setFront () {
    const items = this._items.map(item => format(item));
    console.log(items);
    return this._player.call('client:item:populateInventory', [items]);
  }

  freezeItem (item) {
    let entity = null;

    if (typeof (item) == 'number') {
      entity = this._items.find((_item) => _item.id === item);
    }

    if (item instanceof items.Item) {
      const index = this._items.findIndex(_item => _item === item);

      entity = this._items[index];
    }

    if (entity && entity.frozen) {
      throw new InventoryError(1150, 'The item is already reserved');
    }

    if (entity) {
      entity.frozen = true;
    }

    return entity;
  }
  length () {
    return this._items.length;
  }
};

function format (item) {
  return {
    name: item.getFormattedName(),
    id: item.id,
    inUse: item._inUse
  };
}
