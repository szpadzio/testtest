module.exports = class VisibleMarker {
  constructor (x, y, z, type, dimension, color, label, font) {
    this.colshape = mp.colshapes.newSphere(x, y, z, 1, dimension);
    this.marker = mp.markers.new(type, new mp.Vector3(x, y, z), 1,
      {
        color: color,
        visible: true,
        dimension: dimension
      });
    this.label = mp.labels.new(label, new mp.Vector3(x, y, z), {
      drawDistance: 5,
      los: true
    });
  }
};
