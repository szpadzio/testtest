/**
 *
 *
 * @class Timer
 */
class Timer {
  /**
   *Creates an instance of Timer.
   * @param {*} period
   * @param {*} callback
   * @param {boolean} [loop=false]
   * @memberof Timer
   */
  constructor (period, callback, loop = false, name = 'default') {
    this.name = name;
    this.period = parseInt(period);
    this.loop = loop;
    this.callback = callback;
    this.fired = false;
    this.set();
  }

  /**
   *
   *
   * @memberof Timer
   */
  set () {
    if (this.loop) {
      this.timer = setInterval(this.execute, this.period);
    } else {
      this.timer = setTimeout(this.execute, this.period);
    }
  }

  /**
   *
   *
   * @param {boolean} [newPeriod=false]
   * @param {*} newLoop
   * @memberof Timer
   */
  reset (newPeriod = false, newLoop = false) {
    this.loop ? clearInterval(this.timer) : clearTimeout(this.timer);

    if (newPeriod) this.period = newPeriod;
    if (newLoop) this.loop = newLoop;
    this.fired = false;
    this.set();
  }

  /**
   *
   *
   * @memberof Timer
   */
  destroy () {
    this.loop ? clearInterval(this.timer) : clearTimeout(this.timer);
  }

  execute () {
    this.fired = true;

    return this.callback();
  }
}

module.exports = Timer;
