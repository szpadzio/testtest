const Timer = require('./Timer');

class PlayerTimer extends Timer {
  constructor (player, ...args) {
    super(...args);
    this.entity = player;
  }

  execute () {
    if (!mp.players.exists(this.entity)) {
      this.destroy();
      return 0;
    }
  }
}
