const CODES = {
  // general codes 1000 - something has gone wrong
  'UnknownError': 1000,
  // 11** player codes
  // 11** player/auth codes
  'PlayerAuthError': 1100,
  'PlayerAuthError_WrongCredentials': 1101,
  // 112* player/other codes
  'PlayerAsyncError': 1120,
  'PlayerNotExistingError': 1121,
  // 113* gamemode things
  'OfferTypeNull': 1130,
  'OfferEntityNotExist': 1131,
  'OfferPriceInvalid': 1132,
  'OfferEntityFrozen': 1133,
  'OfferEmpty': 1134,
  'OfferTooFar': 1136,
  'OfferPlayerNotAllowed': 1137,
  // 115* inventoy erors
  'ItemFrozen': 1150
};

class GamemodeError extends Error {
  constructor (code = null, msg = null) {
    super(msg, code); // (1)
    this.name = 'UnknownError';
    if (code === null) this.code = CODES[this.name];
    else this.code = code;
  }
};

class PlayerError extends GamemodeError {
  constructor (...args) {
    super(...args);
    this.name = 'PlayerError';
  }
}

class OfferError extends GamemodeError {
  constructor (...args) {
    super(...args);
    this.name = 'OfferError';
  }
}

class InventoryError extends GamemodeError {
  constructor (...args) {
    super(...args);
    this.name = 'InventoryError';
  }
}
module.exports = {
  GamemodeError, PlayerError, OfferError, InventoryError
};
