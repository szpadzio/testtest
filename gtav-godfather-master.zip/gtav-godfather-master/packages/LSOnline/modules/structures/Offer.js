const { PlayerError, OfferError } = require('./Errors');

class Offer {
  constructor (sender, recipient, entity, price = 0) {
    this.sender = sender;
    this.recipient = recipient;
    this.price = parseInt(price);
    this.entity = entity;

    this.check();
  }

  check () {
    if (!mp.players.exists(this.sender) || !mp.players.exists(this.recipient)) {
      throw new PlayerError(1121, 'The sender or recipient in offer does not exist or left');
    }

    if (isNaN(this.price)) {
      throw new OfferError(1132, 'Price is invalid');
    }

    return 1;
  }
};

class ItemOffer extends Offer {
  getEntityName () {
    return this.entity.getFormattedName();
  }
}

module.exports = { ItemOffer, Offer };
