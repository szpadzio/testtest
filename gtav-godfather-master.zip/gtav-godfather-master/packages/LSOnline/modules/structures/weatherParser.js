class ParseWeather {
  constructor (apiResponse) {
    this.weather = apiResponse.weather[0];
    this.temperature = apiResponse.main.temperature;
    this.pressure = apiResponse.main.pressure;
    this.humidity = apiResponse.main.humidity;
  }

  getGameWeather () {
    let id = 'EXTRASUNNY';
    switch (this.weather.id) {
      case 800:
        id = 'EXTRASUNNY';
        break;
      case 801:
        id = 'CLEAR';
        break;
      case 802: case 803:
        id = 'CLOUDS';
        break;
      case 804:
        id = 'OVERCAST';
        break;
      case 711: case 731: case 751: case 761: case 762:
        id = 'SMOG';
        break;
      case 701: case 721: case 741:
        id = 'FOGGY';
        break;
      case 500: case 501:
        id = 'CLEARING';
        break;
      case 502: case 503: case 504: case 520: case 521: case 531:
        id = 'RAIN';
        break;
      case 300: case 301: case 302:
        id = 'THUNDER';
        break;
      case 310: case 311: case 312: case 313: case 314: case 321:
        id = 'RAIN';
        break;
      case 200: case 201: case 202: case 210: case 211: case 212: case 221: case 230: case 231: case 232:
        id = 'THUNDER';
        break;
      case 600:
        id = 'SNOWLIGHT';
        break;
      case 601:
        id = 'BLIZZARD';
        break;
      default:
        id = 'EXTRASUNNY';
        break;
    }
    return { id, temperature: this.temperature };
  }
}

module.exports = ParseWeather;
