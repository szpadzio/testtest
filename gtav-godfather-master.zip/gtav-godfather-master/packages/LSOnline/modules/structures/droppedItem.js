const Items = require('./Items');
const itemList = require('../items/itemList.json');
const raycastProps = require('../items/raycastProps.json');

/**
 * A class representing dropped item in game world. A item is added to rp.droppedItems pool.
 *
 * @class DroppedItem
 * @extends {Item}
 */
class DroppedItem extends Items.Item {
  /**
   * Creates an instance of DroppedItem.
   * @param {integer} uid
   * @param {string} [name='']
   * @param {string} [type=null]
   * @param {string|null} [subtype=null]
   * @param {object} [extra={}]
   * @param {string} model
   * @param {mp.Vector3} position
   * @param {integer} dimension
   * @param {float} rotation
   * @memberof DroppedItem
   */
  constructor (uid, name = '', type = null, subtype = null, extra = {}, position, dimension, rotation) {
    super(...arguments);
    this.prop = subtype ? itemList[this.type][this.subtype].prop : itemList[this.type].prop;
    this.raycast = subtype ? itemList[this.type][this.subtype].raycast : itemList[this.type].raycast;
    this.position = position;
    this.dimension = dimension;
    this.rotation = rotation;

    if (!this.prop) this.prop = 'ng_proc_food_bag02a';

    this._object = mp.objects.new(
      typeof this.prop === 'string' ? this.prop : this.prop.name,
      new mp.Vector3(position.x, position.y, position.z), {
        dimension,
        rotation: new mp.Vector3(this.prop.offsetX || 0, this.prop.offsetY || 0, rotation + this.prop.offsetZ)
      }
    );

    this._object.itemId = uid;

    if (this.raycast) {
      const hash = mp.joaat(raycastProps[this.raycast].name);

      this._raycastObject = mp.objects.new(
        hash,
        new mp.Vector3(position.x, position.y, position.z), {
          dimension,
          alpha: 0,
          rotation: new mp.Vector3(0, 0, rotation)
        }
      );

      this._raycastObject.itemId = uid;
    }

    this.raycast
      ? this._raycastObject.setVariable('item', { name: this.getFormattedName(), id: this.id, type: this.type })
      : this._object.setVariable('item', { name: this.getFormattedName(), id: this.id, type: this.type });
  }

  /**
   * Destroy a dropped item
   *
   * @memberof DroppedItem
   */
  destroy () {
    this._object.destroy();
    if (this._raycastObject) this._raycastObject.destroy();
  }
};

module.exports = DroppedItem;
