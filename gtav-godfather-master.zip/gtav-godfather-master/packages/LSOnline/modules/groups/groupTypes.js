const types = {
  police: {
    name: 'Policja',
    permissions: {
      emergency: true,
      radio: true,
      departamentRadio: true,
      ooc: true,
      offer: true,
      markedWeapons: true,
      carBlock: true,
      breaching: true,
      orderCall: 'public'
    }
  },
  hospital: {
    name: 'Szpital',
    permissions: {
      emergency: true,
      radio: true,
      departamentRadio: true,
      ooc: true,
      offer: true,
      markedWeapons: false,
      medic: true,
      orderCall: 'public'
    }
  },
  family: {
    name: 'Rodzina',
    permissions: {}
  },
  crime: {
    name: 'Przestępcza',
    permissions: {
      crime: true,
      ooc: true,
      orderCall: 'crime'
    }
  }
  /* gastronomy, taxi, etc. */
};

exports.getType = (type) => {
  return types[type] || { type, name: 'Brak', permissions: {} };
};

exports.getTypes = () => {
  return Object.keys(types).join(' | ');
};
