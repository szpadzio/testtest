'use strict';

const logger = require('../utils/logger');
const { loadAll } = require('./groupManager');

const boot = async () => {
  rp.groups = await loadAll();
  logger('server', `Successfully bootstrapped groups!`, 'info');
};

exports.boot = boot;
