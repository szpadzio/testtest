const permissions = {
  vehicles: false,
  chat: false,
  doors: false,
  leader: false,
  offer: false
};

module.exports = permissions;
