const groupManager = require('./groupManager');
const groupTypes = require('./groupTypes');
const { clearDuty } = require('../characters/characterService');

class Group {
  constructor (data) {
    Object.assign(this, data);
  }

  async updateDuty (memberId, duty) {
    duty.time = duty.end - duty.start;
    await groupManager.insertDutyForMember(this.id, memberId, duty);
  }

  async createRank (name, parameters) {
    const result = await groupManager.createRank(this.id, name, parameters);
    return result;
  }

  async deleteRank (rank) {
    rank = await groupManager.destroyRank(this.id, rank);
    return rank;
  }

  async kickMember (player) {
    const globalGroup = this.getGlobalGroup();
    const members = globalGroup.activeMembers;

    await clearDuty(player, this.id);

    const result = await groupManager.removeCharacterFromGroup(player.character.info.id, this.id);
    const playerGroup = player.character.groups.filter(_group => _group.id === this.id);

    if (result > 0) {
      globalGroup.activeMembers.splice(members.indexOf(player), 1);
      player.character.destroy(player.character.groups.indexOf(playerGroup[0]));
    }

    return result;
  }

  async edit (query) {
    const globalGroup = this.getGlobalGroup();
    const result = await groupManager.editGroup(this.id, query);

    if (result[0]) {
      Object.keys(query).forEach((prop) => {
        this[prop] = query[prop];
        globalGroup[prop] = query[prop];

        if (prop === 'type') {
          globalGroup['type'] = groupTypes.getType(query['type']);
          globalGroup['permissions'] = groupTypes.getType(query['type']).permissions;
        }
      });
    }

    rp.groups.set(this.id, globalGroup);
    return result[0];
  }

  getGlobalGroup () {
    return rp.groups.get(this.id);
  }
};

module.exports = Group;
