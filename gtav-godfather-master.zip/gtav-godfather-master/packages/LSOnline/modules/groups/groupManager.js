const logger = require('../utils/logger');
const database = require('../database/database');
const { parseGroup } = require('./groupService');

/**
 * Load all groups and create an object.
 */
exports.loadAll = async () => {
  return database.Group.findAll().then(result => {
    const map = new Map();

    result.forEach(element => {
      const group = parseGroup(element);
      group.chat = true;

      map.set(group.id, group);
    });

    return map;
  });
};

/**
 * Insert duty for member.
 */
exports.insertDutyForMember = async (group, member, duty) => {
  const result = await database.GroupInvite.findOne({ where: { groupId: group, characterId: member } });

  return database.GroupDutySession.create({
    inviteId: result.id,
    start: duty.start,
    end: duty.end,
    time: duty.time
  });
};

exports.createRank = async (group, name, permissions, salary = 0) => {
  try {
    const result = await database.GroupRank.create({ groupId: group, name, permissions, salary });
    return result;
  } catch (e) {
    logger('group', e);
    return e;
  }
};

exports.updateRank = async (groupId, rankId, rank) => {
  try {
    const result = await database.GroupRank.update(rank, { where: { groupId, id: rankId } });
    return result;
  } catch (e) {
    logger('group', e);
    return e;
  }
};

exports.destroyRank = async (group, rank) => {
  let query = {};

  if (Number.isInteger(rank)) {
    query.id = rank;
  } else {
    query.name = rank;
  }

  try {
    const result = database.GroupRank.destroy({ where: { ...query, groupId: group, deleteable: true } });
    return result;
  } catch (e) {
    logger('group', e);
    return e;
  }
};

exports.removeCharacterFromGroup = (characterId, groupId) => {
  try {
    const result = database.GroupInvite.destroy({ where: { characterId, groupId } });
    return result;
  } catch (e) {
    logger('group', e);
    return e;
  }
};

exports.addCharacterToGroup = (characterId, groupId, rankId = null) => {
  try {
    const result = database.GroupInvite.create({ characterId, groupId, rankId });
    return result;
  } catch (e) {
    logger('group', e);
    return e;
  }
};

exports.findRankInGroup = async (rank, groupId) => {
  try {
    return database.GroupRank.findOne({where: { name: rank, groupId }});
  } catch (e) {
    logger('group', e);
    return e;
  }
};

exports.editGroup = async (groupId, query) => {
  try {
    return database.Group.update({ ...query }, { where: { id: groupId } });
  } catch (e) {
    logger('group', e);
    return e;
  }
};

exports.create = async (name, tag, color = '#F0F0F0', money = 0, payday = 0, type = null) => {
  try {
    const group = await database.Group.create({ name, tag: tag.toUpperCase(), color, money, type, payday });
    const rank = await database.GroupRank.create({groupId: group.id, name: 'Lider', permissions: ['leader'], deleteable: false});

    rp.groups.set(group.id, parseGroup(group));
    return { group, rank };
  } catch (e) {
    logger('group', e);
    return e;
  }
};

exports.delete = async (groupId) => {
  try {
    await database.GroupInvite.destroy({ where: { groupId } });
    await database.GroupRank.destroy({ where: { groupId } });
    await database.Vehicle.destroy({ where: { ownerType: 'group', ownerId: groupId }, individualHooks: true });

    return database.Group.destroy({ where: { id: groupId } });
  } catch (e) {
    logger('group', e);
    return e;
  }
};

exports.getRankByName = (rankName, groupId) => {
  try {
    return database.GroupRank.findOne({ where: { name: rankName, groupId } });
  } catch (e) {
    logger('group', e);
    return e;
  }
};

exports.getRanks = (groupId) => {
  try {
    return database.GroupRank.findAll({ where: { groupId } });
  } catch (e) {
    logger('group', e);
    return e;
  }
};

exports.getMembers = (id) => {
  id = parseInt(id);
  
  return new Promise((resolve, reject) => {
    database.connection.query(`SELECT Characters.id as id, Characters.name, GroupRanks.name AS rank, GroupInvites.id as inviteId from Characters JOIN GroupInvites ON GroupInvites.characterId = Characters.id JOIN GroupRanks ON GroupRanks.id = GroupInvites.rankId WHERE GroupInvites.groupId = $id`, { bind: { id }, raw: true, type: database.Sequelize.QueryTypes.SELECT })
      .then(result => resolve(result));
  });
};
