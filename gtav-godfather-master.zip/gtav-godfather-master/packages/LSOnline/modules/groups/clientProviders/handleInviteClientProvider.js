const handleInviteCommand = require('../commands/handleInviteCommand');

mp.events.add({
  handleInvite: async (player, data) => {
    let [status, index, invite] = JSON.parse(data);

    handleInviteCommand.execute(player, status, index, invite);
  }
});
