
exports.execute = async (player, status, index, invite) => {
  if (!player.getVariable('invitations')) return;

  // Check amount of player groups.
  if (player.character.groups >= rp.constants.maxGroups) {
    return player.call('actionDone', ['Posiadasz za dużo grup.']);
  }

  // Get invitations.
  const invitations = player.getVariable('invitations');
  invite = invitations.splice(index, 1)[0];
  if (!invite) return;

  // Set invitations.
  player.setVariable('invitations', invitations);

  // Check status of invitation.
  if (status === 'deny' && mp.players.exists(invite.sender.poolId) && mp.players.at(invite.sender.poolId).name == invite.sender.name) {
    const sender = mp.players.at(invite.sender.poolId);
    return sender.call('actionDone', [`Gracz ${player.name} odrzucił twoje zaproszenie do grupy.`]);
  }

  // Check result code.
  const result = await player.character.addToGroup(invite.group, null, player);
  if (result.code === 'ERR_DUPLICATE') {
    return player.call('actionDone', [`Należysz już do tej grupy.`]);
  }

  // Return notification for player.
  player.call('actionDone', [`Należysz teraz do grupy ${invite.group.name}`]);

  // Set data for player.
  return player.call('setData', ['group', 'groups', JSON.stringify(player.character.getGroups())]);
};
