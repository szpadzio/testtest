const color = require('color');
const groupTypes = require('../groups/groupTypes');
const groupManager = require('../groups/groupManager');
const { clearDuty } = require('../characters/characterService');

class GlobalGroup {
  constructor (data) {
    Object.assign(this, data);
  }

  broadcastInCharacter (player, message) {
    rp.commands.get('say').run(player, { fullText: message }, true, 'group', this.id, true);
    this.activeMembers.forEach(member => {
      member.outputChatBox(`!{${this.color}}[${this.tag}] ${player.name}: ${message}`);
    });
  }

  broadcastOutOfCharacter (player, message) {
    this.activeMembers.forEach(member => {
      member.outputChatBox(`!{${color(this.color).darken(0.25).hex()}}(( [${this.tag}] ${player.name} (${player.id}): ${message} ))`);
    });
  }

  removeOnline (characterId) {
    this.activeMembers = this.activeMembers.filter(element => element.character.info.id !== characterId);
  }

  async edit (query) {
    const result = await groupManager.editGroup(this.id, query);

    if (result[0]) {
      Object.keys(query).forEach((prop) => {
        this[prop] = query[prop];
        if (prop === 'type') {
          this['type'] = groupTypes.getType(query['type']);
          this['permissions'] = groupTypes.getType(query['type']).permissions;
        }
      });
    }

    return result;
  }

  getRank (rank) {
    return groupManager.getRankByName(rank, this.id);
  }

  async delete () {
    this.activeMembers.forEach(member => {
      const groups = member.character.groups;
      clearDuty(member, this.id);

      const index = groups.findIndex(group => group.id === this.id);
      groups.splice(index, 1);
    });

    rp.groups.delete(this.id);
    return groupManager.delete(this.id);
  }
};

module.exports = GlobalGroup;
