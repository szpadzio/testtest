const groupTypes = require('./groupTypes');
const GlobalGroup = require('../groups/globalGroup');

exports.parseGroup = (group) => {
  group = JSON.parse(JSON.stringify(group));
  group.activeMembers = [];

  const groupType = groupTypes.getType(group.type);
  group.permissions = groupType.permissions;
  group.type = {
    type: group.type,
    name: groupType.name
  };

  group = new GlobalGroup(group);
  return group;
};
