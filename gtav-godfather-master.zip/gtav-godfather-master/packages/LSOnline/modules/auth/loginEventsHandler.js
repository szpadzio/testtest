'use strict';

const logger = require('../utils/logger');
const { loadAndSpawnCharacter } = require('../characters/characterManager');

mp.events.add({
  playerJoin: player => {
    if (!rp.ready) {
      player.notify('Serwer nie jest gotowy. Połącz się ponownie za chwilę.');
      return player.kick('Server is not ready.');
    }
    logger('join', `Player ${player.name} (SC: ${player.socialClub} / IP: ${player.ip}) joined to the server.`, 'info');
  },

  playerReady: player => {
    player.call('updateDiscord', ['W lobby']);
    player.call('playerReady');

    prepareBeforeJoin(player);
    showBrowser(player);
    player.kickTimer = setTimeout(() => {
      if (!mp.players.exists(player)) { return 0; }
      // player.kick(`Byłeś zbyt długo w lobby!`); // Kick == disconnect so for now we just commenting this because this ruins our playerQuit handler - we dont have enough data.
      logger('auth', `Player ${player.name} (SC: ${player.socialClub} / IP: ${player.ip}) has been in login lobby too long.`, 'info');
    }, 60000);
  },

  loginPlayer: (player, characterId) => {
    if (!characterId) return 0;

    if (player.kickTimer) clearTimeout(player.kickTimer);
    loadAndSpawnCharacter(player, characterId);
  },
  proceedToGame: player => proceedToGame(player)
});

const showBrowser = player => player.call(`showBrowser`);

const prepareBeforeJoin = player => {
  player.dimension = Math.floor(Math.random() * 1000);
  player.call(`chatActive`, [false]);
  player.call('hideHud', [true]);
  player.call('chatShow', [false]);
  player.call(`setInvincible`, [true]);
  player.call(`toggleFreeze`, [true]);
};

const proceedToGame = player => {
  player.call(`setInvincible`, [false]);
  player.call(`chatActive`, [true]);
  player.call(`toggleFreeze`, [false]);
  player.call('chatShow', [true]);
  player.call('hideHud', [false]);
  player.call(`cursorVisible`, [true]);

  player.outputChatBox(`Witaj ponownie, ${player.account.name}. Życzymy miłej rozgrywki na serwerze!`);
  player.call('updateDiscord', ['Prowadzi rozgrywkę']);
};
