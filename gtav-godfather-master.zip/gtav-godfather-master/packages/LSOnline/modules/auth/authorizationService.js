'use strict';

const logger = require('../utils/logger');
const forumDatabase = require('../database/forumDatabase');

/**
 * Authorize user by checking entered password.
 */
function ipbAuth (login, password) {
  return forumDatabase.account.findOne({ where: { name: login }, rejectOnEmpty: true }).then(async account => {
  // const passHash = account.members_pass_hash;
    return authorize(login, true, account.member_id);
  });
}

/**
 * Authorize user.
 */
function authorize (login, authorizeCondition = function () {}, id) {
  if (!authorizeCondition) {
    throw new Error(`WrongCredentialsError`);
  }
  logger('auth', `User with login "${login}" has been authorized.`, 'info');
  return id;
}

exports.ipbAuth = ipbAuth;
