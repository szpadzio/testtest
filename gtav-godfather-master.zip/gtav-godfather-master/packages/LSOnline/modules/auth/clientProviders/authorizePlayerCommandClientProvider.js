'use strict';

const authorizePlayerCommand = require('../commands/authorizePlayerCommand');

mp.events.add('server:authorizePlayer', async (player, data) => {
  const user = JSON.parse(data);

  try {
    const result = await authorizePlayerCommand.execute(player, user.username, user.password);

    player.call('response:server:authorizePlayer', [JSON.stringify(result)]);
  } catch (err) {
    switch (err.code) {
      case 1000:
        return { type: 'error', code: err.code };
      case 1101: case 1100:
        return { type: 'error', code: err.code };
      default:
        return { type: 'error', code: 1000 };
    }
  }
});
