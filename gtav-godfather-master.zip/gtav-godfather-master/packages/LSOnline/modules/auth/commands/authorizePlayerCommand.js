'use strict';

const service = require('../authorizationService');
const { loadAccountData } = require('../../account/accountManager');
const { findCharactersForAccount } = require('../../characters/characterManager');
const { PlayerAsyncError, PlayerAuthError, MyError } = require('../../structures/Errors');

exports.execute = async (player, login, password) => {
  try {
    if (!mp.players.exists(player)) throw new PlayerAsyncError(null, 'player does not exist during async');

    clearTimeout(player.kickTimer);
    const id = 1;

    loadAccountData(player, login, id);

    const characters = await findCharactersForAccount(1);
    if (!mp.players.exists(player)) throw new PlayerAsyncError(null, 'player does not exist during async');

    player.account.characters = characters.length;

    delete player.tries;

    return { type: 'characters',
      characters: characters.map(character => Object({
        name: character.name,
        money: character.money,
        bank: character.bank,
        id: character.id,
        played: character.played,
        outfit: character.Outfits[0]
      })) };
  } catch (err) {
    player.tries ? player.tries++ : player.tries = 1;

    if (err.name === 'SequelizeEmptyResultError') {
      return { type: 'error', code: 1001 };
    }
    if (err.message === 'WrongCredentialsError') {
      return { type: 'error', code: 1002 };
    }

    if (player.tries > 3) return player.kick('Zbyt dużo niepoprawnych logowań');
  }
};
