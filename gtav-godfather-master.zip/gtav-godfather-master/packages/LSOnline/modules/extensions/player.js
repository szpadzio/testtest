mp.Player.prototype.outputInfo = function (msg) {
  this.outputChatBox(`!{${rp.constants.colors.info}}>> ${msg}`);
};

mp.Player.prototype.outputError = function (msg) {
  this.outputChatBox(`!{${rp.constants.colors.error}}>> [${rp.__('ERROR')}] ${msg}`);
};

mp.Player.prototype.outputTooltip = mp.Player.prototype.outputTip = function (msg) {
  this.outputChatBox(`!{${rp.constants.colors.tooltip}}>> Tip: ${msg}`);
};

mp.Player.prototype.actionBubble = function (msg) {
  rp.commands.get('ame').run(this, { fullText: `${msg}` });
};
