const logger = require('../utils/logger');
const moduleName = 'offers';

module.exports = {
  'offer:sent': (type, player, target, entity, price, hash) => {
    log(`${player.name} wysłał ofertę sprzedaży (${type}) ${entity.name} (${entity.id}) do ${target.name} za ${price}. (${hash})`);
  },
  'offer:accepted': (type, player, sender, entity, price, hash) => {
    log(`${player.name} zaakceptował ofertę sprzedaży (${type}) ${entity.name} (${entity.id}) za ${price} od ${sender.name}. (${hash})`);
  },
  'offer:realized': (type, player, sender, entity, price, hash) => {
    log(`${player.name} zrealizował ofertę sprzedaży (${type}) ${entity.name} (${entity.id}) za ${price} od ${sender.name}. (${hash})`);
  },
  'offer:failed': (type, player, sender, entity, price, hash, err) => {
    log(`Wystąpił błąd podczas oferty sprzedaży (${type}) ${entity.name} (${entity.id}) za ${price} od ${sender.name} dla ${player.name} (GID: ${player.id}, UID ${player.character.info.id}). (${hash}) ${err.message}`, 'error');
  }
};

const log = (message, type = 'info') => {
  logger(moduleName, message, type);
};
