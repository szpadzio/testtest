const Outfit = require('../structures/Outfit');

// Move these random spawns to server config or something.
const randomSpawns = [
  new mp.Vector3(1839.6, 3672.93, 34.28),
  new mp.Vector3(-247.76, 6331.23, 32.43),
  new mp.Vector3(-449.67, -340.83, 34.50)
];

const { getVehicleById } = require('../vehicles/vehicleService');

const spawnCharacterOnPosition = async (player) => {
  if (player.character.info.position && await player.character.getDisconnectedTime() < rp.constants.disconnectTime) {
    const parsedData = JSON.parse(player.character.info.position);
    const position = parsedData.position;
    const heading = parsedData.heading;
    const interiorId = parsedData.door || null;
    let door = null;
    if (interiorId) {
      door = mp.markers.toArray().find(_m => _m.isDoor && _m.informations.id === interiorId);
    }
    player.position = new mp.Vector3(position.x, position.y, position.z);
    player.heading = heading;
    player.dimension = player.character.info.dimension;
    if (door) player.call('loadIpl', [door.informations.ipl]);
    player.door = door;
    if (player.character.info.lastVehicle) {
      putCharacterIntoLastVehicle(player, player.character.info);
      player.character.clearLastVehicleInfo();
    }
  } else {
    const houses = mp.markers.toArray().filter((door) => door.isDoor && door.informations.type === 0 && door.informations.ownerType === 'character' && door.informations.ownerId === player.character.info.id);
    let spawn = houses.length > 0 ? houses[0] : randomSpawns[Math.floor(Math.random() * randomSpawns.length)];
    let dimension = houses.length > 0 ? spawn.informations.insideDimension : 0;
    if (houses.length > 0) player.door = spawn;

    if (spawn.informations && spawn.informations.ipl) player.call('loadIpl', [spawn.informations.ipl]);

    player.position = houses.length > 0 ? new mp.Vector3(spawn.informations.insidePosition.x, spawn.informations.insidePosition.y, spawn.informations.insidePosition.z) : spawn;
    player.dimension = dimension;
  }

  changeOutfit(player, player.character.outfits[0], true);

  // Set variable - spawned on true.
  player.setVariable('spawned', true);
  player.call('client:playerReadyAndSpawned');
};

exports.spawnCharacterOnPosition = spawnCharacterOnPosition;

/**
 * Put character into last vehicle.
 *
 * @param {object} player Player object.
 * @param {object} character Character object.
 */
const putCharacterIntoLastVehicle = (player, character) => {
  const vehicle = JSON.parse(character.lastVehicle);
  let foundVehicle = getVehicleById(vehicle.id);

  // Found vehicle? Gucci. Make some checks and put character inside this car.
  if (foundVehicle) {
    if (player.distSquared(player.position) <= 100) {
      if (vehicle.seat === -1) {
        if (foundVehicle.locked) {
          return;
        }
      }

      // Set player position.
      player.position = foundVehicle.position;

      // Put player into vehicle.
      setTimeout(() => player.putIntoVehicle(foundVehicle, vehicle.seat), 1000);

      // Return notification for player.
      player.call('actionDone', ['Wróciłeś do pojazdu po ostatnim wyjściu z gry!']);
    }
  }
};

/**
 * Change player outfit.
 *
 * @param {object} player Player object.
 * @param {object} outfit Outfit object.
 * @param {Boolean} strip Make player naked first?
 */
const changeOutfit = (player, outfit, strip = false) => {
  if (!outfit) { return 0; }
  player.clearDecorations();

  if (outfit.clothes) {
    for (let i = 0; i < 13; i++) {
      const cloth = outfit.clothes[i];
      if (outfit.face) {
        const headOverlay = outfit.face.overlays[i];

        if (headOverlay) player.setHeadOverlay(i, [headOverlay.index, headOverlay.opacity, headOverlay.firstColor, headOverlay.secondColor]);
      }

      if (cloth) player.setClothes(i, cloth.id, cloth.textureId, 0);
    }
  }

  if (outfit.decorations) {
    for (let i = 0; i < outfit.decorations.length; i++) {
      const decoration = outfit.decorations[i];

      if (decoration) player.setDecoration(mp.joaat(decoration.collection), mp.joaat(decoration.overlay));
    }
  }

  if (outfit.props) {
    Object.entries(outfit.props).forEach(([key, value]) => {
      player.setProp(Number(key), value.id, value.textureId);
    });
  }
  const parents = outfit.parents;

  if (strip) player.setCustomization(Boolean(player.character.info.sex), parents[0].shape, parents[1].shape, 0, parents[0].skin, parents[1].skin, 0, outfit.mix.shape, outfit.mix.skin, 0, outfit.body.eyeColor, outfit.body.hairColor, outfit.body.highlightColor, outfit.face.features);
};

exports.changeOutfit = changeOutfit;

exports.inviteCharacterToGroup = (target, sender, group) => {
  target.call('actionDone', [`Zostałeś zaproszony przez ${sender.name} do grupy ${group.name}.`]);

  if (!target.getVariable('invitations')) {
    target.setVariable('invitations', []);
  }

  const invitations = target.getVariable('invitations');
  let globalGroup = group.getGlobalGroup();

  invitations.push({ sender: { ...sender.character.info, poolId: sender.id }, group: { ...group, permissions: globalGroup.permissions, online: globalGroup.activeMembers.length, type: globalGroup.type } });
  target.setVariable('invitations', invitations);
};

exports.clearDuty = async (player, groupId = null) => {
  player.character.groups.forEach(async _group => {
    if (player.character.duty && player.character.duty.group.id === _group.id) {
      if (groupId && groupId !== player.character.duty.group.id) return;
      await rp.commands.get('group-duty').run(player, {}, _group);
    }
  });
};
