const persistCharacterCommand = require('../commands/persistCharacterCommand');

mp.events.add({
  characterCreated: async (player, data) => {
    const character = JSON.parse(data);
    delete character.maxTextures;
    delete character.maxDrawables;

    await persistCharacterCommand.execute(player, character);
  }
});
