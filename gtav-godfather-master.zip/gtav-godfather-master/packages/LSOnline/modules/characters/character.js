const moment = require('moment');
const {
  saveCharacterBeforeQuit,
  clearLastVehicleInfo,
  leaveGroup,
  insertLoginSession,
  getLatestSession
} = require('./characterManager');
const { addCharacterToGroup } = require('../groups/groupManager');
const Group = require('../groups/group');
const Timer = require('../structures/Timer');

class Character {
  constructor (data) {
    this.info = data;
    this.groups = [];
    this.outfits = [];
    this.timers = {};
  }

  async saveBeforeQuit (player, lastVehicle = null, exitType) {
    const played = this.getOnlineTime();

    insertLoginSession(
      player.account.id,
      this.info.id,
      player.ip,
      player.socialClub,
      player.serial,
      player.character.joinedAt
    );

    this.inventory.save();
    return saveCharacterBeforeQuit(this.info.id, player.dimension, { position: player.position, heading: player.heading, door: player.door ? player.door.informations.id : null }, lastVehicle, this.info.lastLogin, exitType, player.health, played, player.getVariable('money'), player.getVariable('bank'));
  }

  updateLastLoginDate () {
    this.info.lastLogin = moment().format('YYYY-MM-DD HH:mm:ss');
  }

  async clearLastVehicleInfo () {
    this.info.lastVehicle = null;
    await clearLastVehicleInfo(this.info.id);
  }

  getOnlineTime () {
    let joined = moment(this.joinedAt);
    let played =
      this.info.played +
      moment.duration(moment().diff(joined)).asMilliseconds();

    return played;
  }

  initialize (player) {
    const fullHourInMs = 1000 * 60 * 60;
    const timeRemainingToFullHour =
      this.info.played > fullHourInMs
        ? fullHourInMs -
          ((fullHourInMs * (this.info.played / fullHourInMs)) % 1)
        : fullHourInMs - this.info.played;
    rp.timers.pushTimerForEntity(
      player,
      new Timer(
        timeRemainingToFullHour,
        () => mp.events.call('playedHour', player),
        false,
        'fullHour'
      )
    );

    this.groups.forEach(group =>
      rp.groups.get(group.id).activeMembers.push(player)
    );
  }

  async destroy (slot = null) {
    if (slot !== null) {
      const group = this.groups[slot].getGlobalGroup();
      group.removeOnline(this.info.id);
      this.groups.splice(slot, 1);
    } else {
      this.groups.forEach(group => {
        const globalGroup = rp.groups.get(group.id);
        globalGroup.removeOnline(this.info.id);
      });
      this.groups = [];
    }
  }

  getGroup (slot) {
    const group = this.groups[slot - 1];
    return group;
  }

  getGroups () {
    return this.groups.map(group => {
      const globalGroup = group.getGlobalGroup();
      return { ...group, online: globalGroup.activeMembers.length };
    });
  }

  async updateDuty () {
    await this.duty.group.updateDuty(this.info.id, this.duty);
    delete this.duty;
  }

  async leaveGroup (slot) {
    const group = this.groups[slot - 1];
    const result = await leaveGroup(this.info.id, group.id);

    if (result) {
      this.destroy(slot - 1);
    }

    return result;
  }

  async addToGroup (group, rank, player) {
    if (
      this.groups &&
      this.groups.length > 0 &&
      this.groups.filter(g => g.id === group.id).length > 0
    ) {
      return new Error(
        `GroupInvites cannot be duplicated amongst the same group.`,
        'ERR_DUPLICATE'
      );
    }

    const rankId = rank ? rank.id : null;
    const result = await addCharacterToGroup(this.info.id, group.id, rankId);

    if (!result.code) {
      group = new Group({
        id: group.id,
        name: group.name,
        type: group.type,
        color: group.color,
        permissions: group.permissions,
        rank: rank ? rank.get() : null
      });

      this.groups.push(group);
      rp.groups.get(group.id).activeMembers.push(player);
    }

    player.call('setData', ['group', 'groups', this.getGroups()]);
    return result;
  }

  getDisconnectedTime () {
    return new Promise(async (resolve, reject) => {
      const last = await getLatestSession();
      if (!last) resolve(undefined);
      resolve(Math.floor((Math.abs(last.get('exitedAt') - new Date()) / 1000) / 60));
    });
  }
}

module.exports = Character;
