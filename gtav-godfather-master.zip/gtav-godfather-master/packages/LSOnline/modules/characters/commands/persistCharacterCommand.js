const characterManager = require('../characterManager');

exports.execute = async (player, character) => {
  try {
    let result = await characterManager.persistCharacter(player, character);
    result = await result.getCharacter();

    // Login player, proceed to game next.
    mp.events.call('loginPlayer', player, result.get('id'));
    mp.events.call('proceedToGame', player);

    // Destroy creation.
    player.call('destroyCreation');
  } catch (e) {
    switch (e.name) {
      case 'SequelizeUniqueConstraintError': // Make excepion switcher - this should not be here. // TO:DO
        player.call('actionDone', ['Postać już istnieje.']);
        break;
      default:
        player.call('actionDone', ['Wystąpił nieznany błąd.']);
        break;
    }
  }
};
