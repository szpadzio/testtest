const { spawnCharacterOnPosition } = require('./characterService');
const ItemFactory = require('../items/itemFactory');
const Inventory = require('../structures/Inventory');
const Outfit = require('../structures/Outfit');

const Character = require('./character');
const Group = require('../groups/group');

mp.events.add({
  spawnCharacter: async (player, character) => {
    if (!character) return player.kick();
    if (player.account.member_id !== character.owner) return player.kick('Postać nie należy do gracza.');

    // Assign data to player.
    player.character = new Character(character.get({ plain: true }));
    player.character.outfits = character.Outfits.map(outfit => new Outfit(outfit.get()));
    player.character.vehicles = mp.vehicles.toArray().filter(v => v.informations.ownerType === 'character' && v.informations.ownerId === player.character.info.id);

    const items = character.Items.map(item => {
      item = item.get({ plain: true });
      return ItemFactory(item.id, item.type, item.subtype, item.name, JSON.parse(item.extra), item.Subitems.map(subitem => {
        return ItemFactory(subitem.id, subitem.type, subitem.subtype, subitem.name, JSON.parse(subitem.extra));
      }));
    });
    player.character.inventory = new Inventory(player, items);

    // Assing groups to player.
    player.character.groups = character.GroupInvites.map(element => new Group({
      ...element.Group.get({ plain: true }),
      rank: element.GroupRank ? { ...element.GroupRank.get({ plain: true }), permissions: JSON.parse(element.GroupRank.get('permissions')) } : null
    }));

    // Set name and other variables.
    player.name = character.get('name');
    player.data.money = character.get('money');

    player.setVariable('bank', character.get('bank'));
    player.character.joinedAt = new Date();
    player.setVariable('joinedAt', new Date());
    player.health = character.get('health');

    // We check for timers made after player's disconnect - example: vehicle cleanup.
    rp.timers.clearTimersForEntity(player);

    // Initialize player.
    player.character.initialize(player);

    // Spawn character on position, update last login date.
    spawnCharacterOnPosition(player, character);
    player.character.updateLastLoginDate();

    // Update discord status.
    player.call('updateDiscord', ['Prowadzi rozgrywkę']);

    player._items = [];
    // ?
    delete player.character.info.GroupInvites;
    delete player.character.info.Outfits;
    delete player.character.info.Vehicles;
  }
});
