'use strict';

const logger = require('../utils/logger');
const database = require('../database/database');
const { parseOutfit } = require('../utils/helpers');

exports.loadAndSpawnCharacter = (player, characterId) => {
  database.Character.findByPk(characterId, {
    include: [
      { model: database.GroupInvite,
        include:
        [
          database.GroupRank,
          database.Group
        ]
      }, {
        model: database.Outfit
      },
      {
        model: database.Vehicle
      },
      {
        model: database.Item,
        include: [{ model: database.Item, as: 'Subitems' }]
      }
    ]
  }).then(character => {
    mp.events.call('spawnCharacter', player, character);
    return logger('auth', `Loaded and spawned character ${player.character.info.name} (ID: ${player.character.info.id} / Player: ${player.name} / SC: ${player.socialClub} / IP: ${player.ip})!`, 'info');
  }).catch(e => logger('auth', `${e.message}`, 'error'));
};

exports.findCharactersForAccount = (accountId) => {
  return database.Character.findAll({
    where: { owner: accountId },
    include: [{ model: database.Outfit, limit: 1 }]
  });
};

exports.saveCharacterBeforeQuit = async (characterId,
  dimension, position, lastVehicle = false, lastLogin, exitType, health, played, money, bank) => {
  database.Character.findByPk(characterId)
    .then(character => {
      return character.update({
        position: position,
        dimension: dimension,
        lastLogin: lastLogin,
        lastExitType: exitType,
        played,
        bank,
        money,
        health });
    })
    .then((character) => {
      return logger('character', `Saved character "${character.name}" (ID: ${character.id} / Owner: ${character.owner}) data before quit.`, 'info');
    })
    .catch((err) => {
      return logger('character', `Error occurred when saving character ${characterId}) data before quit. (Message: ${err})`, 'error');
    });

  if (lastVehicle) {
    database.Character.findByPk(characterId).then(character =>
      character.update({ lastVehicle: JSON.stringify(lastVehicle) }))
      .then((character) => {
        return logger('character', `Character "${character.name}" (ID: ${character.id} / Owner: ${character.owner}) was in vehicle so i saved his last vehicle too.`, 'info');
      })
      .catch((err) => {
        return logger('character', `Error occurred when saving character (ID: ${characterId}) info about last vehicle. (Message: ${err})`, 'error');
      });
  }
};

exports.clearLastVehicleInfo = (characterId) => {
  return database.Character.findByPk(characterId).then(character => {
    return character
      .update({ lastVehicle: null });
  });
};

exports.saveCharacterOutfit = (characterId) => {
  return database.Character.findByPk(characterId).then(character => {
    return character.addOutfit();
  });
};

exports.persistCharacter = (player, data) => {
  return database.connection.transaction((t) => {
    return database.Character.create({
      name: data.identify.name + ' ' + data.identify.secondName,
      owner: player.account.member_id,
      age: data.identify.birthday,
      sex: data.gender === 'male' ? 1 : 0
    }, { transaction: t }).then((character) => {
      const outfit = parseOutfit(data, 'default');
      return database.Outfit.create({
        owner: character.id,
        name: outfit.name,
        model: outfit.model,
        data: { parents: outfit.parents, mix: outfit.mix, body: outfit.body, face: outfit.face, clothes: outfit.clothes, decorations: outfit.decorations }
      },
      { transaction: t,
        include: [{ model: database.Character }]
      });
    });
  });
};

exports.leaveGroup = (characterId, groupId) => {
  return database.GroupInvite.destroy({ where: { groupId, characterId } });
};

exports.changeRankForCharacter = (characterId, groupId, rankId) => {
  return database.GroupInvite.update(
    { rankId },
    { where: { groupId, characterId } }
  );
};

exports.insertLoginSession = (
  accountId,
  characterId,
  ip,
  socialClub,
  serial,
  joinedAt,
  exitedAt = new Date()
) => database.LoginSession.create({
  accountId,
  characterId,
  ip,
  socialClub,
  serial,
  joinedAt,
  exitedAt
});

exports.getLatestSession = (accountId = 1, characterId) =>
  database.LoginSession.findOne({
    limit: 1, order: [['id', 'DESC']], where: { accountId }
  })
    .then(r => r || null);
