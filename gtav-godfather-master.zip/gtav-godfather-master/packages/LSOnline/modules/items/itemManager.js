const db = require('../database/database');
const logger = require('../utils/logger');

/**
 * Save Item into database
 *
 * @param {Item} Item
 * @param {integer} ownerId
 * @param {string} ownerType
 * @returns {Promise<any>}
 */
exports.save = (Item, ownerId, ownerType) => {
  return db.Item.create({
    name: Item.name,
    type: Item.type,
    subtype: Item.subtype,
    ownerId,
    ownerType,
    extra: Item.getExtras()
  })
    .catch(err => {
      logger('item', `Podczas zapisywania wystąpił błąd: ${err.message}`, 'error');
      throw err;
    });
};

exports.update = (Item) => {
  return db.Item.update({
    name: Item.name,
    type: Item.type,
    subtype: Item.subtype,
    extra: Item.getExtras()
  }, { where: { id: Item.uid } })
    .catch(err => {
      logger('item', `Podczas aktualizacji wystąpił błąd: ${err.message}`, 'error');
      throw err;
    });
};

exports.pickupItem = (DroppedItem, ownerId) => {
  return Promise.all([
    db.Item.update({
      ownerId,
      ownerType: 'character'
    }, { where: { id: DroppedItem.id } }),
    db.ItemGround.destroy({ where: { itemId: DroppedItem.id } })
  ])
    .catch(err => {
      logger('item', `Podczas podnoszenia wystąpił błąd: ${err.message}`, 'error');
      throw err;
    });
};

exports.transferItem = (Item, ownerId, ownerType = 'character') => {
  return db.Item.update({
    ownerId,
    ownerType
  }, { where: { id: Item.id } })
    .catch(err => {
      logger('item', `Podczas przekazywania wystąpił błąd: ${err.message}`, 'error');
      throw err;
    });
};

exports.putOnGround = (Item) => {
  return db.ItemGround.create({
    itemId: Item.id,
    x: Item.position.x,
    y: Item.position.y,
    z: Item.position.z,
    dimension: Item.dimension,
    rotation: Item.rotation
  })
    .then(ground => {
      return db.Item.update({
        ownerId: ground.id,
        ownerType: 'ground'
      }, { where: { id: Item.id } });
    })
    .catch(err => {
      logger('item', `Podczas aktualizacji ownera (ground) wystąpił błąd: ${err.message}`, 'error');
      throw err;
    });
};

exports.putToVehicle = (Item, vehicle) => {
  return db.Item.update({
    ownerType: 'vehicle',
    ownerId: vehicle.informations.id
  }, { where: { id: Item.id } })
    .catch(err => {
      logger('item', `Podczas aktualizacji ownera (vehicle) wystąpił błąd: ${err.message}`, 'error');
      throw err;
    });
};

exports.putToContainer = (Item, container) => {
  return db.Item.update({
    ownerType: 'item',
    ownerId: container.id
  }, { where: { id: Item.id } })
    .catch(err => {
      logger('item', `Podczas aktualizacji ownera (container) wystąpił błąd: ${err.message}`, 'error');
      throw err;
    });
};

exports.bulkUpdate = (items) => {
  return db.Item.bulkCreate(items, { updateOnDuplicate: ['name', 'extra', 'ownerId', 'ownerType'] })
    .catch(err => {
      logger('item', `Podczas bulkCreate wystąpił błąd: ${err.message}`, 'error');
      throw err;
    });
};

exports.loadAll = () => {
  return db.Item.findAll({ where: { ownerType: 'ground' }, include: [db.ItemGround] })
    .then(items => {
      items.forEach(item => {
        item = item.get({ plain: true });
        item.extra = JSON.parse(item.extra);
      });
      return items;
    })
    .catch(err => {
      logger('item', `Podczas loadAll wystąpił błąd: ${err.message}`, 'error');
      throw err;
    });
};
