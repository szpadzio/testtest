mp.events.add({
  'server:player:useItem': (player, itemIndex) => {
    player.character.inventory.use(itemIndex);
  },
  'server:item:pickupItem': (player, item) => {
    if (typeof item === 'string') item = JSON.parse(item);
    if (player.vehicle && item.type === 'vehicle') {
      // check vehicle's trunk for ItemId

      const vehicle = player.vehicle;

      item = vehicle.trunk.find(_item => item.id === _item.id);
      if (!item) return;

      const index = vehicle.trunk.indexOf(item);
      vehicle.trunk.splice(index, 1);

      player.character.inventory.pickup(item);

      if (!item) return false;
    } else if (!player.vehicle && item.type === 'ground') {
      const object = mp.objects.at(item.id);

      if (!mp.objects.exists(object) || !object.itemId) return;
      if (object.dist(player.position) > 3) return;

      player.playAnimation('anim@amb@nightclub@mini@drinking@drinking_shots@ped_b@drunk', 'pickup', 1, 49);

      item = rp.droppedItems[object.itemId];

      delete rp.droppedItems[object.itemId];

      const newLength = player.character.inventory.pickup(item);
      mp.players.call('client:item:destroyItemInWorld', object.id);
      setTimeout(() => {
        if (!mp.players.exists(player)) return;
        player.stopAnimation();
        if (player.character.inventory._items[newLength - 1].type === 'weapon') {
          player.character.inventory.use(newLength - 1, false);
        }
      }, 1000);
    } else if (item.type === 'container') {
      const container = player.character.inventory._items.find(_item => _item.id === item.parent);

      if (!container) return player.call('actionDone', ['Coś poszło nie tak.']);

      const subItem = container.contains(item.id);

      if (!subItem) return;

      container.pickup(player, subItem);
    } else {
      const door = player.door;

      item = door.trunk.find(_item => item.id === _item.id);
      if (!item) return;

      const index = door.trunk.indexOf(item);
      door.trunk.splice(index, 1);

      player.character.inventory.pickup(item);
    }
  },
  'server:player:dropItem': (player, itemIndex) => {
    player.character.inventory.drop(itemIndex);
  }
});
