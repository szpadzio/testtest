const Items = require('../structures/Items');

module.exports = (id = null, type, subtype = null, name = null, extra = {}, subitems = []) => {
  return {
    weapon: () => new Items.Weapon(id, name, type, subtype, extra),
    watch: () => new Items.Watch(id, name, type, subtype, extra),
    mask: () => new Items.Mask(id, name, type, subtype, extra),
    drug: () => new Items.Drug(id, name, type, subtype, { amount: 2 }),
    container: () => new Items.Container(id, name, type, subtype, extra, subitems)

  }[type]();
};
