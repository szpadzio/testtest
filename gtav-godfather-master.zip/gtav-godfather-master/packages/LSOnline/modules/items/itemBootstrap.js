'use strict';

const logger = require('../utils/logger');
const { loadAll } = require('./itemManager');
const DroppedItem = require('../structures/DroppedItem');

const boot = async () => {
  try {
    const items = await loadAll();
    items.forEach(item => {
      rp.droppedItems[item.id] = new DroppedItem(item.id, item.name, item.type, item.subtype, JSON.parse(item.extra),
        { x: item.ItemGround.x, y: item.ItemGround.y, z: item.ItemGround.z },
        item.ItemGround.dimension, item.ItemGround.rotation);
    });
    return logger('server', `Successfully bootstrapped items!`, 'info');
  } catch (err) {
    logger('server', `Error bootstrapping items! ${err.message}`, 'error');
  }
};

exports.boot = boot;
