'use strict';

const fs = require('fs-nextra');
const path = require('path');
const dir = path.join(__dirname, '..');
const pattern = new RegExp('init', 'i');
const logger = require('../utils/logger');

exports.boot = async () => {
  try {
    const [size] = await fs.scan(dir, { filter: (stats, filepath) => stats.isFile() && path.extname(filepath) === '.js' && path.parse(filepath).name.search(pattern) >= 0 })
      .then(files => Promise.all([...files.keys()].map(file => {
        load(path.relative(dir, file));
        return files.size;
      })));

    logger('server', `Loaded successfully ${size} jobs!`, 'info');
  } catch (err) {
    logger('server', `Error while loading job (Error: ${err.message} / ${err.stack})!`, 'error');
  }
};

let load = async (file) => {
  const filepath = path.join(dir, file);
  await (require(filepath))();
};
