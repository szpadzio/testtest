const { randomInt } = require('../../utils/helpers');
const { changeOutfit } = require('../../characters/characterService');
const outfitList = require('../../utils/outfitList.json');

mp.events.add('playerEnterColshape', (player, colshape) => {
  if (!colshape.isJob || colshape.data.job !== 'lumberMill' || player.getVariable('job') !== 'lumberMill') return false;
  if (player._isCarryingWood) {
    player._jobPayout += colshape.payout + randomInt(0, 5);
    player.outputChatBox('!{yellow}> Tartak: Dostarczyłeś drewno!');
    player.addAttachment('carrying:wood', true);
    player._isCarryingWood = false;
    player._jobCounter += 1;
  }
});

mp.events.add('jobStarted:lumberMill', (player, colshape) => {
  player.outputChatBox('!{yellow}> Tartak: Twoja praca się zaczęła. Do roboty!');
  player._jobCounter = 0;
  player._jobPayout = 0;
  player.setVariable('job', 'lumberMill');
  changeOutfit(player, outfitList['lumber'][player.character.info.sex === 1 ? 'male' : 'female']);
  player.setVariable('job', 'lumberMill');
});

mp.events.add('jobFinished:lumberMill', (player, colshape) => {
  player.outputChatBox('!{yellow}> Tartak: Twoja praca zakończyła.');
  player.setVariable('job', null);
  player.data.money += player._jobPayout;

  player._jobCounter = undefined;
  player._jobPayout = undefined;
});

mp.events.add('jobInteraction', async (player, type, clientObjectId) => {
  if (player.getVariable('job') !== 'lumberMill' || player._isCarryingWood) return false;
  if (player._isDoingTask) return false;
  player._isDoingTask = true;
  player.addAttachment('job:lumbering', false);
  player.playAnimation('melee@unarmed@streamed_variations', 'plyr_takedown_rear_backhit', 1.0, 1);
  setTimeout(() => {
    player.stopAnimation();
    player.addAttachment('job:lumbering', true);
    player._isDoingTask = false;
    player._isCarryingWood = true;
  }, 5000);
});
