const VisibleMarker = require('../../structures/VisibleMarker');
const logger = require('../../utils/logger');
const { randomInt } = require('../../utils/helpers');

const lumberMill = {
  starterCheckpoint: {
    x: -469.88, y: 5357.14, z: 80.94
  },
  payPerItem: 5,
  markerType: 2,
  markerColor: [0, 0, 255, 150],
  welcomingLabel: '(( Zatrudnij się jako ~b~drwal~w~! /praca ))',
  positions: [
    { x: -481.784423828125,
      y: 5385.2490234375,
      z: 77.71086120605469 },
    { x: -474.6973571777344,
      y: 5393.19091796875,
      z: 77.81729888916016 },
    { x: -482.4863586425781,
      y: 5393.76904296875,
      z: 77.23268127441406 },
    { x: -490.55908203125,
      y: 5390.47802734375,
      z: 76.59211730957031 },
    { x: -498.4004821777344,
      y: 5389.57080078125,
      z: 75.68561553955078 },
    { x: -501.6758728027344,
      y: 5389.2333984375,
      z: 75.2362289428711 },
    { x: -496.7731628417969,
      y: 5399.28466796875,
      z: 75.13636779785156 },
    { x: -508.72589111328125,
      y: 5398.8759765625,
      z: 74.27076721191406 },
    { x: -511.0906066894531,
      y: 5404.54345703125,
      z: 73.7488021850586 },
    { x: -516.4401245117188,
      y: 5385.837890625,
      z: 70.23104095458984 },
    { x: -474.1816711425781, y: 5399.171875, z: 77.46283721923828 },
    { x: -478.9216003417969,
      y: 5399.7548828125,
      z: 77.2373275756836 },
    { x: -454.49224853515625,
      y: 5391.20361328125,
      z: 78.92366027832031 },
    { x: -449.625, y: 5400.41748046875, z: 78.47144317626953 },
    { x: -447.83331298828125,
      y: 5412.4306640625,
      z: 77.68033599853516 }
  ]
};

module.exports = async () => {
  try {
    const jobPlace = new VisibleMarker(lumberMill.starterCheckpoint.x, lumberMill.starterCheckpoint.y, lumberMill.starterCheckpoint.z,
      lumberMill.markerType, lumberMill.dimension || 0, lumberMill.markerColor, lumberMill.welcomingLabel, 2);
    jobPlace.colshape.isJob = true;
    jobPlace.colshape.data.job = 'lumberMill';
    jobPlace.colshape.payout = lumberMill.payPerItem;
    for (let i = 0; i < lumberMill.positions.length; i++) {
      mp.objects.new('test_tree_cedar_trunk_001', new mp.Vector3(lumberMill.positions[i].x, lumberMill.positions[i].y, lumberMill.positions[i].z), { rotation: new mp.Vector3(0, 0, randomInt(0, 270)) });
    }
    logger('JOB: Lumber Mill', 'Succesfully created marker for Lumber Mill.', 'info');
  } catch (e) {
    throw e;
  }
};
