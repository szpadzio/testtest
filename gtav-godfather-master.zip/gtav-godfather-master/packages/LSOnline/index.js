// Env config
require('dotenv').config(); // eslint-disable-line no-unused-vars

// Main API
require('./api/GameClient');
