'use strict';

const fs = require('fs-nextra');
const path = require('path');
const dir = path.join(__dirname, '../modules/extensions');
const logger = require('../modules/utils/logger');

module.exports = async () => {
  try {
    const [size] = await fs.scan(dir, { filter: (stats, filepath) => stats.isFile() && path.extname(filepath) === '.js' })
      .then(files => Promise.all([...files.keys()].map(file => {
        load(path.relative(dir, file));
        return files.size;
      })));

    logger('server', `Loaded successfully ${size} extensions!`, 'info');
  } catch (err) {
    logger('server', `Error while extensions! (Error: ${err.message} / ${err.stack})!`, 'error');
  }
};

let load = (file) => {
  const filepath = path.join(dir, file);
  require(filepath);
};
