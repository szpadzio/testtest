'use strict';

const logger = require('../modules/utils/logger');

module.exports = async () => {
  try {
    const vehicleBootstrap = require('../modules/vehicles/vehicleBootstrap');
    const groupBootstrap = require('../modules/groups/groupBootstrap');
    const doorBootstrap = require('../modules/doors/doorBootstrap');
    const jobsBootstrap = require('../modules/jobs/jobsBootstrap');
    const itemBootstrap = require('../modules/items/itemBootstrap');

    await vehicleBootstrap.boot();
    await groupBootstrap.boot();
    await doorBootstrap.boot();
    await jobsBootstrap.boot();
    await itemBootstrap.boot();
  } catch (err) {
    logger('server', `Error while bootstraping (Error: ${err.message} / ${err.stack})!`, 'error');
  }
};
