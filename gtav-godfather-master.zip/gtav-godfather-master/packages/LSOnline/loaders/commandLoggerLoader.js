'use strict';

const fs = require('fs-nextra');
const path = require('path');
const dir = path.join(__dirname, '..', './modules/loggers');
const logger = require('../modules/utils/logger');

module.exports = async () => {
  try {
    const [size] = await fs.scan(dir, { filter: (stats, filepath) => stats.isFile() && path.extname(filepath) === '.js' })
      .then(files => Promise.all([...files.keys()].map(file => {
        load(path.relative(dir, file));
        return files.size;
      })));

    logger('server', `Loaded successfully ${size} loggers!`, 'info');
  } catch (err) {
    logger('server', `Error while loading logger (Error: ${err.message} / ${err.stack})!`, 'error');
  }
};

let load = (file) => {
  const filepath = path.join(dir, file);
  const events = require(filepath);
  registerEvents(events);
};

let registerEvents = (eventsCallbacks = {}) => {
  for (let event in eventsCallbacks) {
    rp.logger.on(event, eventsCallbacks[event]);
  };
};
