'use strict';

const logger = require('../modules/utils/logger');
module.exports = async () => {
  try {
    const blocked = require('blocked-at');
    blocked((time, stack) => {
      logger('server', `Blocked for ${time}ms, operation started here: ${stack}`, 'error');
    });
    logger('server', `Successfully initiated check for an event loop block.`, 'info');
  } catch (err) {
    logger('server', `Error while module Event Loop Checker (Error: ${err.message} / ${err.stack})!`, 'error');
  }
};
