const axios = require('axios');

const url = 'https://api.openweathermap.org/data/2.5/';
const location = process.env.WEATHER_CITY;
const key = process.env.WEATHER_KEY;

class WeatherClient {
  constructor () {
    this.instance = axios.create({
      baseURL: url
    });
    this.city = location;

    if (!this.city || !key) {
      throw new Error('City or key is empty!');
    }
  }

  get (endpoint) {
    return this.instance.get(`${endpoint}&appid=${key}`);
  }

  getCurrentWeather () {
    return this.get(`weather?q=${this.city}&units=metric`)
      .then(response => response.data);
  }
}

module.exports = WeatherClient;
