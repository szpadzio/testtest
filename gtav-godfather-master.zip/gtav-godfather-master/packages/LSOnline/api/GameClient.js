const i18n = require('i18n');

const CommandCollection = require('../modules/structures/CommandCollection');
const WeatherClient = require('./WeatherClient');
const WeatherParser = require('../modules/structures/WeatherParser');
const logger = require('../modules/utils/logger');

class GameClient {
  constructor () {
    this.initialize();
  }

  /**
   * Initialize game client.
   */
  initialize () {
    this.loadGlobals();
    this.runLoaders();
    this.setLocale();
    this.initWorkers();
    this.initWeather();
  }

  /**
   * Assign commands collection and server config to global.
   */
  loadGlobals () {
    global.rp = {};

    /**
 * later in code configure
 */
    i18n.configure({
      objectNotation: true,
      locales: ['en', 'pl'],
      staticCatalog: {
        en: require('../locales/en.json')
      } });
    i18n.setLocale('en');
    rp.commands = new CommandCollection();
    rp.constants = require('../../../config/server.constants.json');
    rp.timers = new (require('../modules/structures/TimerPool'))();
    rp.droppedItems = {};
    rp.config = {
      ipbKey: process.env.IPB_KEY,
      ipbHost: process.env.IPB_HOST
    };
    rp.logger = new (require('events'))();
    rp.__ = i18n.__;
  }

  /**
   * Run loaders.
   */
  runLoaders () {
    (async () => {
      await require('../loaders/databaseLoader')();
      await require('../loaders/eventHandlersLoader')();
      await require('../loaders/commandsLoader')();
      await require('../loaders/clientProvidersLoader')();
      await require('../loaders/bootstrapLoader.js')();
      await require('../loaders/commandLoggerLoader.js')();
      await require('../loaders/eventLoopMonitorLoader.js')();
      await require('../loaders/extensionsLoader.js')();
      rp.ready = true;
    })();
  }
  setLocale () {
    require('moment').locale('pl');
  }

  initWorkers () {
    require('./queue/worker');
    require('./queue/logger');
  }

  initWeather () {
    const interval = parseInt(process.env.WEATHER_INTERVAL) * 60 * 1000 || 1000 * 60 * 30;
    rp.weather = 'realworld';

    this.setWorldWeather();
    setInterval(() => {
      if (rp.weather !== 'realworld') return;
      this.setWorldWeather();
    }, interval);
  }

  async setWorldWeather () {
    try {
      let api = new WeatherClient();
      let data = await api.getCurrentWeather();
      data = new WeatherParser(data);

      const weather = data.getGameWeather();
      mp.world.setWeatherTransition(weather.id);
    } catch (e) {
      logger('weatherApi', e.message + ' Omitting weather fetch...', 'warn');
    }
  }
}

module.exports = new GameClient();
