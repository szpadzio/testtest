const axios = require('axios');

module.exports = {
  instance: axios.create({
    baseURL: `http://${rp.config.ipbHost}/api/index.php?`
  }),
  key: rp.config.ipbKey,

  get (endpoint) {
    return this.instance.get(`${endpoint}&key=${this.key}`);
  },

  getUserInfo (id) {
    return this.get(`/core/members/${id}`);
  }
};
