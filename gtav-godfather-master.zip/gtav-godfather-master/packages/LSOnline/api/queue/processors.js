
module.exports = {
  payday: db => async job => {
    const player = job.data;
    let salaryAmount = 100;
    const result = {
      group: null,
      isGroupInDebt: false
    };
    if (player.groups.length > 0) {
      let groupWithHighestPayday = player.groups.reduce((prev, current) => {
        if (!prev.rank) return current;
        if (!current.rank) return prev;
        return (prev.rank.salary > current.rank.salary) ? prev : current;
      });
      if (groupWithHighestPayday && groupWithHighestPayday.rank) {
        const group = await db.Group.findOne({ where: { id: groupWithHighestPayday.id } });
        result.group = group;
        if (group.payday < groupWithHighestPayday.rank.salary) {
          salaryAmount += group.payday;
          let diff = groupWithHighestPayday.rank.salary - group.payday;
          if (group.money - diff > 0) {
            salaryAmount += diff;
            group.money -= diff;
          } else {
            result.isGroupInDebt = true;
            if (group.money > 0) {
              salaryAmount += group.money;
              group.money = 0;
            }
          }
          group.save();
        } else {
          salaryAmount += groupWithHighestPayday.rank.salary;
        }
      }
    }

    const character = await db.Character.findOne({ where: { id: player.character.id } });
    character.bank += salaryAmount;
    character.save();

    return { salaryAmount, ...result, xd: job.data.player };
  }
};
