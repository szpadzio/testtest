'use strict';

module.exports = (sequelize, DataTypes) => {
  let LoginSession = sequelize.define(
    'LoginSession',
    {
      accountId: DataTypes.INTEGER,
      characterId: DataTypes.INTEGER,
      ip: DataTypes.TEXT,
      socialClub: DataTypes.TEXT,
      serial: DataTypes.TEXT,
      joinedAt: DataTypes.DATE,
      exitedAt: DataTypes.DATE
    },
    { timestamps: false }
  );
  return LoginSession;
};
