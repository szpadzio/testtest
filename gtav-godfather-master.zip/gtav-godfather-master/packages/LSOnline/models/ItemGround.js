'use strict';
module.exports = (sequelize, DataTypes) => {
  let ItemGround = sequelize.define('ItemGround', {
    itemId: {
      type: DataTypes.INTEGER,
      allowNull: true,
      unique: true
    },
    x: {
      type: DataTypes.FLOAT(10, 6),
      allowNull: false
    },
    y: {
      type: DataTypes.FLOAT(10, 6),
      allowNull: false
    },
    z: {
      type: DataTypes.FLOAT(10, 6),
      allowNull: false
    },
    dimension: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    rotation: {
      type: DataTypes.FLOAT(6, 3)
    }

  }, {});
  ItemGround.associate = function (models) {
    ItemGround.hasOne(models.Item, { foreignKey: 'ownerId', constrains: false });
  };
  return ItemGround;
};
