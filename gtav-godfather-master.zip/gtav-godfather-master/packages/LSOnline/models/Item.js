'use strict';
module.exports = (sequelize, DataTypes) => {
  let Item = sequelize.define('Item', {
    name: {
      type: DataTypes.STRING(32),
      unique: false,
      validate: {
        len: [0, 32]
      },
      allowNull: true
    },
    type: {
      allowNull: false,
      type: DataTypes.STRING(9)
    },
    subtype: {
      type: DataTypes.STRING(32),
      allowNull: true
    },
    extra: {
      type: DataTypes.JSON,
      allowNull: true
    },
    ownerId: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    ownerType: {
      type: DataTypes.STRING(8),
      allowNull: false
    }

  }, { timestamps: true });
  Item.associate = function (models) {
    Item.belongsTo(models.Character, {
      foreignKey: 'ownerId',
      constraints: false
    });
    Item.belongsTo(models.ItemGround, {
      foreignKey: 'ownerId',
      constraints: false
    });
    Item.belongsTo(models.Vehicle, {
      foreignKey: 'ownerId',
      constraints: false,
      scope: {
        ownerType: 'vehicle'
      }
    });
    Item.belongsTo(models.Door, {
      foreignKey: 'ownerId',
      constraints: false,
      scope: {
        ownerType: 'door'
      }
    });
    Item.hasMany(models.Item, {
      foreignKey: 'ownerId',
      constraints: false,
      as: 'Subitems',
      scope: {
        ownerType: 'item'
      }
    });
  };
  return Item;
};
