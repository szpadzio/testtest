'use strict';
module.exports = (sequelize, DataTypes) => {
  let Outfit = sequelize.define('Outfit', {
    name: DataTypes.STRING,
    model: DataTypes.STRING,
    data: DataTypes.JSON
  }, {});
  Outfit.associate = function (models) {
    Outfit.belongsTo(models.Character, { foreignKey: 'owner' });
  };
  return Outfit;
};
