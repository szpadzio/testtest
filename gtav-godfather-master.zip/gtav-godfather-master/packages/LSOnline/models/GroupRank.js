'use strict';
module.exports = (sequelize, DataTypes) => {
  let GroupRank = sequelize.define('GroupRank', {
    groupId: DataTypes.INTEGER,
    name: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: 'groupname',
      validators: {
        len: [2, 16]
      }
    },
    permissions: DataTypes.JSON,
    deleteable: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      defaultValue: true
    },
    salary: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
      validators: {
        min: 0
      }
    }
  }, {
    hooks: {
      beforeCreate: async (model) => {
        const duplicates = await GroupRank.count({ where: {
          groupId: model.groupId,
          name: model.name
        } });

        if (duplicates > 0) {
          throw new Error(`Ranks cannot be duplicated amongst the same group.`, 'ERR_DUPLICATE');
        }
      }
    }
  });
  GroupRank.associate = function (models) {
    GroupRank.belongsTo(models.Group, { foreignKey: 'groupId' });
  };
  return GroupRank;
};
