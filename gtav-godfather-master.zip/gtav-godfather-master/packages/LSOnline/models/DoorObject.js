'use strict';

module.exports = (sequelize, DataTypes) => {
  let DoorPresetObject = sequelize.define(
    'DoorPresetObject',
    {
      doorId: DataTypes.INTEGER,
      hash: DataTypes.TEXT,
      rotation: DataTypes.FLOAT(6, 4),
      position: DataTypes.TEXT,
      alpha: DataTypes.INTEGER(3)
    },
    {}
  );
  DoorPresetObject.associate = models => {
    DoorPresetObject.belongsTo(models.Door, {
      foreignKey: 'presetId'
    });
  };
  return DoorPresetObject;
};
