'use strict';

module.exports = (sequelize, DataTypes) => {
  let Vehicle = sequelize.define('Vehicle', {
    name: DataTypes.STRING,
    model: DataTypes.STRING,
    fuel: DataTypes.FLOAT,
    fuelType: DataTypes.INTEGER,
    fuelRatio: DataTypes.FLOAT,
    tankCapacity: DataTypes.FLOAT,
    bodyHealth: {
      type: DataTypes.FLOAT(5, 3),
      allowNull: false,
      defaultValue: 1000
    },
    engineHealth: {
      type: DataTypes.FLOAT(5, 3),
      allowNull: false,
      defaultValue: 1000
    },
    ownerId: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: null
    },
    ownerType: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    primaryColor: DataTypes.JSON,
    secondaryColor: DataTypes.JSON,
    plate: DataTypes.STRING,
    plateType: DataTypes.INTEGER,
    dirtLevel: DataTypes.FLOAT,
    position: DataTypes.JSON,
    parkingPosition: {
      type: DataTypes.JSON,
      allowNull: true,
      defaultValue: null
    },
    dimension: DataTypes.INTEGER,
    lockedOnUnspawn: DataTypes.BOOLEAN,
    mileage: {
      defaultValue: 0,
      type: DataTypes.FLOAT
    }
  }, {
    hooks: {
      afterDestroy: (instance) => {
        mp.vehicles.toArray().find(vehicle => vehicle.informations.id === instance.id).destroy();
      }
    }
  });
  Vehicle.associate = (models) => {
    Vehicle.belongsTo(models.Group, {
      foreignKey: 'ownerId',
      constraints: false
    });
    Vehicle.belongsTo(models.Character, {
      foreignKey: 'ownerId',
      constraints: false
    });
    Vehicle.hasMany(models.Item, {
      foreignKey: 'ownerId',
      constraints: false,
      scope: {
        ownerType: 'vehicle'
      }
    });
  };
  return Vehicle;
};
