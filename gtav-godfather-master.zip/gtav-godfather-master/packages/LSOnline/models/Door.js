'use strict';

module.exports = (sequelize, DataTypes) => {
  let Door = sequelize.define(
    'Door',
    {
      name: DataTypes.STRING,
      type: DataTypes.INTEGER,
      ownerId: {
        type: DataTypes.INTEGER,
        defaultValue: null
      },
      ownerType: DataTypes.TEXT,
      ipl: DataTypes.TEXT,
      position: DataTypes.TEXT,
      insidePosition: DataTypes.TEXT,
      heading: DataTypes.FLOAT,
      dimension: DataTypes.INTEGER,
      insideDimension: DataTypes.INTEGER,
      marker: DataTypes.INTEGER,
      locked: DataTypes.BOOLEAN,
      price: DataTypes.INTEGER,
      enterPrice: DataTypes.INTEGER,
      blip: DataTypes.BOOLEAN,
      blipSprite: DataTypes.INTEGER,
      blipColor: DataTypes.INTEGER,
      audioStream: {
        type: DataTypes.JSON,
        defaultValue: null
      }
    },
    {}
  );
  Door.associate = models => {
    Door.belongsTo(models.Group, {
      foreignKey: 'ownerId',
      constraints: false
    });
    Door.belongsTo(models.Character, {
      foreignKey: 'ownerId',
      constraints: false
    });
    Door.hasMany(models.Item, {
      foreignKey: 'ownerId',
      constraints: false,
      scope: {
        ownerType: 'door'
      }
    });
  };
  return Door;
};
