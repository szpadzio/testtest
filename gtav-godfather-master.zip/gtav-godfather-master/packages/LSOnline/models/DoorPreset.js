'use strict';

module.exports = (sequelize, DataTypes) => {
  let DoorPreset = sequelize.define(
    'DoorPreset',
    {
      name: DataTypes.TEXT(64),
      ipl: DataTypes.TEXT(32),
      insidePosition: DataTypes.TEXT(128)
    },
    {}
  );
  DoorPreset.associate = models => {};
  return DoorPreset;
};
