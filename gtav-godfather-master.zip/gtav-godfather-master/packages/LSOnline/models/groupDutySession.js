'use strict';
module.exports = (sequelize, DataTypes) => {
  let GroupDutySession = sequelize.define('GroupDutySession', {
    inviteId: DataTypes.INTEGER,
    start: DataTypes.DATE,
    end: DataTypes.DATE,
    time: DataTypes.INTEGER
  }, {});
  GroupDutySession.associate = function (models) {
    GroupDutySession.belongsTo(models.GroupInvite, { foreignKey: 'inviteId' });
    GroupDutySession.belongsTo(models.Group, { foreignKey: 'groupId' });
    GroupDutySession.belongsTo(models.Character, { foreignKey: 'characterId' });
  };
  return GroupDutySession;
};
