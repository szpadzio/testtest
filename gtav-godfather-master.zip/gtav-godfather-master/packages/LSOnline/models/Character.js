'use strict';

module.exports = (sequelize, DataTypes) => {
  let Character = sequelize.define('Character', {
    uuid: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4
    },
    name: DataTypes.STRING,
    owner: DataTypes.INTEGER,
    age: DataTypes.DATE,
    sex: DataTypes.INTEGER,
    health: DataTypes.INTEGER,
    money: DataTypes.INTEGER,
    bank: DataTypes.INTEGER,
    position: DataTypes.JSON,
    played: DataTypes.INTEGER,
    dimension: DataTypes.STRING,
    lastLogin: DataTypes.DATE,
    lastVehicle: DataTypes.TEXT,
    lastExitType: DataTypes.STRING
  }, {});
  Character.associate = (models) => {
    Character.hasMany(models.Outfit, { foreignKey: 'owner' });
    Character.hasMany(models.GroupInvite, { foreignKey: 'characterId' });
    Character.hasMany(models.Vehicle, {
      foreignKey: 'ownerId',
      constraints: false,
      scope: {
        ownerType: 'character'
      }
    });
    Character.hasMany(models.Door, {
      foreignKey: 'ownerId',
      constraints: false,
      scope: {
        ownerType: 'character'
      }
    });
    Character.hasMany(models.Item, {
      foreignKey: 'ownerId',
      constraints: false,
      scope: {
        ownerType: 'character'
      }
    });
  };

  return Character;
};
