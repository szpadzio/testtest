'use strict';
module.exports = (sequelize, DataTypes) => {
  let Group = sequelize.define('Group', {
    name: {
      type: DataTypes.STRING(32),
      unique: true,
      validate: {
        len: [3, 32]
      }
    },
    type: {
      allowNull: true,
      type: DataTypes.STRING(8)
    },
    tag: {
      type: DataTypes.STRING(4),
      validate: {
        len: [3, 4]
      }
    },
    color: DataTypes.STRING(8),
    money: DataTypes.INTEGER,
    payday: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      allowNull: true
    },
    image: DataTypes.BLOB,
    motd: DataTypes.STRING,
    motdDate: DataTypes.DATE

  }, {});
  Group.associate = function (models) {
    Group.hasMany(models.GroupInvite, { foreignKey: 'groupId', onDelete: 'CASCADE' });
    Group.hasMany(models.GroupRank, { foreignKey: 'groupId', onDelete: 'CASCADE' });
    Group.hasMany(models.Vehicle, {
      foreignKey: 'ownerId',
      constraints: false,
      scope: {
        ownerType: 'group'
      },
      onDelete: 'CASCADE'
    });
    Group.hasMany(models.Door, {
      foreignKey: 'ownerId',
      constraints: false,
      scope: {
        ownerType: 'door'
      },
      onDelete: 'CASCADE'
    });
  };
  return Group;
};
