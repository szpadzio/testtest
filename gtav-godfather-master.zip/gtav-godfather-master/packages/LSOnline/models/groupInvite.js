'use strict';
module.exports = (sequelize, DataTypes) => {
  let GroupInvite = sequelize.define('GroupInvite', {
    rankId: DataTypes.INTEGER
  }, {
    hooks: {
      beforeCreate: async (model) => {
        const duplicates = await GroupInvite.count({ where: {
          groupId: model.groupId,
          characterId: model.characterId
        } });

        if (duplicates > 0) {
          throw new Error(`GroupInvites cannot be duplicated amongst the same group.`, 'ERR_DUPLICATE');
        }
      }
    }
  });
  GroupInvite.associate = function (models) {
    GroupInvite.belongsTo(models.Character, { foreignKey: 'characterId' });
    GroupInvite.belongsTo(models.Group, { foreignKey: 'groupId' });
    GroupInvite.belongsTo(models.GroupRank, { foreignKey: 'rankId' });
    GroupInvite.hasMany(models.GroupDutySession, { foreignKey: 'inviteId' });
  };
  return GroupInvite;
};
