'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([queryInterface.addColumn('Groups', 'image', {
      type: Sequelize.BLOB(),
      allowNull: true,
      defaultValue: null
    }),
    queryInterface.addColumn('Groups', 'motd', {
      type: Sequelize.STRING(),
      allowNull: true,
      defaultValue: null
    }),
    queryInterface.addColumn('Groups', 'motdDate', {
      type: Sequelize.DATE(),
      allowNull: true,
      defaultValue: null
    })]);
  },

  down: (queryInterface, Sequelize) => {
    queryInterface.removeColumn('Groups', 'image');
    queryInterface.removeColumn('Groups', 'motd');
    return queryInterface.removeColumn('Groups', 'motdDate');
  }
};
