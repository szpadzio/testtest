'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('Vehicles', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      name: {
        type: Sequelize.STRING,
        allowNull: false
      },
      model: {
        type: Sequelize.STRING
      },
      fuel: {
        type: Sequelize.FLOAT,
        defaultValue: '10.0'
      },
      fuelType: {
        type: Sequelize.INTEGER
      },
      fuelRatio: {
        type: Sequelize.FLOAT
      },
      tankCapacity: {
        type: Sequelize.FLOAT,
        defaultValue: '20.0'
      },
      ownerId: {
        type: Sequelize.INTEGER,
        defaultValue: null
      },
      ownerType: {
        type: Sequelize.STRING,
        defaultValue: null
      },
      primaryColor: {
        type: Sequelize.JSON
      },
      secondaryColor: {
        type: Sequelize.JSON
      },
      plate: {
        type: Sequelize.STRING(8),
        defaultValue: null
      },
      plateType: {
        type: Sequelize.INTEGER,
        defaultValue: 0
      },
      dirtLevel: {
        type: Sequelize.FLOAT,
        defaultValue: 0
      },
      position: {
        type: Sequelize.JSON
      },
      dimension: {
        type: Sequelize.INTEGER
      },
      lockedOnUnspawn: {
        type: Sequelize.BOOLEAN
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => queryInterface.dropTable('Vehicles')
};
