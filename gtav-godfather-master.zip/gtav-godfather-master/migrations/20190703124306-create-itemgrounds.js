'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('ItemGrounds', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      itemId: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      x: {
        type: Sequelize.FLOAT(10, 6)
      },
      y: {
        type: Sequelize.FLOAT(10, 6)
      },
      z: {
        type: Sequelize.FLOAT(10, 6)
      },
      dimension: {
        type: Sequelize.INTEGER
      },
      rotation: {
        type: Sequelize.FLOAT(6, 3)
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }

    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('ItemGrounds');
  }
};
