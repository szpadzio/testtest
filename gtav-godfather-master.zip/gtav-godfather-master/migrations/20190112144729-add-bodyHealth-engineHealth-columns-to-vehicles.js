'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    queryInterface.addColumn('Vehicles', 'engineHealth', {
      type: Sequelize.FLOAT(8, 3),
      allowNull: false,
      defaultValue: 1000
    });
    return queryInterface.addColumn('Vehicles', 'bodyHealth', {
      type: Sequelize.FLOAT(8, 3),
      allowNull: false,
      defaultValue: 1000
    });
  },

  down: (queryInterface, Sequelize) => {
    queryInterface.removeColumn('Vehicles', 'engineHealth');
    return queryInterface.removeColumn('Vehicles', 'bodyHealth');
  }
};
