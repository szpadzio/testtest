'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('Items', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      name: {
        type: Sequelize.STRING(32),
        allowNull: true
      },
      type: {
        type: Sequelize.STRING(16),
        allowNull: false
      },
      subtype: {
        type: Sequelize.STRING(32),
        allowNull: true
      },
      extra: {
        type: Sequelize.JSON,
        allowNull: true
      },
      ownerId: {
        allowNull: false,
        type: Sequelize.INTEGER
      },
      ownerType: {
        allowNull: false,
        type: Sequelize.STRING(16)
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }

    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('Items');
  }
};
