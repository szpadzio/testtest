'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('LoginSessions', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      accountId: {
        allowNull: false,
        type: Sequelize.INTEGER
      },
      characterId: {
        allowNull: false,
        type: Sequelize.INTEGER
      },
      ip: {
        allowNull: false,
        type: Sequelize.STRING(45)
      },
      socialClub: {
        allowNull: false,
        type: Sequelize.STRING(16)
      },
      serial: {
        allowNull: false,
        type: Sequelize.STRING(128)
      },
      joinedAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      exitedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('LoginSessions');
  }
};
