'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('Groups', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      name: {
        type: Sequelize.STRING(32),
        unique: true,
        allowNull: false
      },
      tag: {
        type: Sequelize.STRING(4),
        allowNull: false
      },
      color: {
        type: Sequelize.STRING(8),
        allowNull: false,
        defaultValue: '#FFFFF'
      },
      type: {
        type: Sequelize.STRING(8),
        defaultValue: null
      },
      payday: {
        type: Sequelize.INTEGER,
        defaultValue: 0
      },
      money: {
        type: Sequelize.INTEGER,
        defaultValue: 0
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('Groups');
  }
};
