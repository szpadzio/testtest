'use strict';
const faker = require('faker');

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.bulkInsert(
      'DoorPresets',
      [
        {
          name: 'Modern 1 Apartment',
          ipl: 'apa_v_mp_h_01_a',
          insidePosition: JSON.stringify({
            x: -786.8663,
            y: 315.7642,
            z: 217.6385
          }),
          createdAt: faker.date.past(),
          updatedAt: faker.date.past()
        },
        {
          name: 'Modern 2 Apartment',
          ipl: 'apa_v_mp_h_01_c',
          insidePosition: JSON.stringify({
            x: -786.9563,
            y: 315.6229,
            z: 187.9136
          }),
          createdAt: faker.date.past(),
          updatedAt: faker.date.past()
        },
        {
          name: 'Modern 3 Apartment',
          ipl: 'apa_v_mp_h_01_b',
          insidePosition: JSON.stringify({
            x: -774.0126,
            y: 342.0428,
            z: 196.6864
          }),
          createdAt: faker.date.past(),
          updatedAt: faker.date.past()
        },
        {
          name: 'Seductive 1 Apartment',
          ipl: 'apa_v_mp_h_06_a',
          insidePosition: JSON.stringify({
            x: -787.1423,
            y: 315.6943,
            z: 217.6384
          }),
          createdAt: faker.date.past(),
          updatedAt: faker.date.past()
        }
      ],
      {}
    );
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.bulkDelete('People', null, {});
    */
  }
};
