'use strict';

const faker = require('faker');

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.bulkInsert('Groups', [{
      name: faker.company.companyName(),
      tag: 'POL',
      type: 'police',
      color: faker.internet.color(),
      money: 1400,
      createdAt: faker.date.past(),
      updatedAt: faker.date.past()
    }], {});
  },

  down: (queryInterface, Sequelize) => queryInterface.bulkDelete('Groups', null, {})
};
